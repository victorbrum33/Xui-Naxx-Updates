/* Melhorias progressivas: não altera contas, URLs, autenticação ou dados do XUI. */
(function () {
  'use strict';
  var overlayScript=document.currentScript;
  var overlayRevision=window.naxxAssetRevision||'5722a2666358';
  var overlayAssetBase=overlayScript&&overlayScript.src?new URL('../css/',overlayScript.src):new URL('assets/css/',location.href);
  function loadOverlayStyles(){
    if(overlayScript&&overlayScript.src&&!/\/(?:naxx-overlay|app\.min)\.js(?:\?|$)/.test(overlayScript.src))return;
    var nativeStyle=document.querySelector('link[rel~="stylesheet"][href*="/app.css"],link[rel~="stylesheet"][href*="/app.dark.css"]');
    if(!nativeStyle)return;
    var light=!/\/app\.dark\.css(?:\?|$)/.test(nativeStyle.href);
    var href=new URL(light?'naxx-overlay.light.css':'naxx-overlay.css',overlayAssetBase);
    href.searchParams.set('v',overlayRevision);
    var link=document.querySelector('link[data-naxx-overlay]');
    if(!link){link=document.createElement('link');link.rel='stylesheet';link.dataset.naxxOverlay='';document.head.appendChild(link);}
    if(link.href!==href.href)link.href=href.href;
  }
  loadOverlayStyles();
  // Os gráficos também inserem estilos no head. Só mudanças nos links de CSS
  // precisam conferir o tema, sem reexaminar o painel a cada animação.
  new MutationObserver(function(mutations){
    if(mutations.some(function(mutation){
      if(mutation.type==='attributes')return mutation.target.matches('link[rel~="stylesheet"]');
      return Array.from(mutation.addedNodes).concat(Array.from(mutation.removedNodes)).some(function(node){return node.nodeType===1&&node.matches('link[rel~="stylesheet"]');});
    })){versionBrandStylesheets();loadOverlayStyles();}
  }).observe(document.head,{childList:true,subtree:true,attributes:true,attributeFilter:['href']});
  document.documentElement.lang = 'pt-BR';
  var viewport = document.querySelector('meta[name="viewport"]');
  if (!viewport) {
    viewport = document.createElement('meta');
    viewport.name = 'viewport';
    document.head.appendChild(viewport);
  }
  viewport.content = 'width=device-width, initial-scale=1, viewport-fit=cover';
  var jqTables=window.jQuery;
  if(jqTables&&jqTables.fn&&jqTables.fn.dataTable){
    jqTables.extend(true,jqTables.fn.dataTable.defaults,{language:{emptyTable:'Nenhum registro disponível.',info:'Mostrando _START_ a _END_ de _TOTAL_ registros',infoEmpty:'Nenhum registro disponível.',infoFiltered:'(filtrado de _MAX_ registros)',lengthMenu:'Mostrar _MENU_ registros',loadingRecords:'Carregando…',processing:'Processando…',search:'Pesquisar:',zeroRecords:'Nenhum resultado encontrado.',paginate:{first:'Primeira',last:'Última',next:'Próxima',previous:'Anterior'},aria:{sortAscending:': ordenar em ordem crescente',sortDescending:': ordenar em ordem decrescente'}}});
  }
  var translations = {'Dashboard':'Visão geral','All Servers':'Todos os servidores','Main Server':'Servidor principal','Online Connections':'Conexões ativas','Active Lines':'Contas ativas','Live Streams':'Canais ao vivo','Down Streams':'Canais indisponíveis','Network Output':'Saída de rede','Network Input':'Entrada de rede','Service Status':'Estado dos serviços','CPU & Memory':'CPU e memória','Network Traffic':'Tráfego de rede','Connections':'Conexões','Database Incomplete':'Atualização do banco pendente','Root Crons Missing':'Rotinas do servidor pendentes','Server Order':'Ordem dos servidores','Service Setup':'Configuração dos serviços','Access Control':'Controle de acesso','Stream Providers':'Provedores de conteúdo','Plex Sync':'Sincronização Plex','Access Codes':'Códigos de acesso','Blocked ASN\'s':'ASNs bloqueados','HMAC Keys':'Chaves HMAC','RTMP Monitor':'Monitor RTMP','Created Channels':'Canais criados','Stream Review':'Revisar transmissões','Recordings':'Gravações','TV Guide':'Guia de programação','Import Multiple':'Importar lista','Import & Review':'Importar e revisar','Import':'Importar','Review':'Revisar','Save':'Salvar','Add':'Adicionar','Light':'Claro','Dark':'Escuro','Default':'Padrão','Blue':'Azul','Light Blue':'Azul claro','Green':'Verde','Red':'Vermelho','Orange':'Laranja','Purple':'Roxo','Pink':'Rosa','Dark Grey':'Cinza escuro','Light Grey':'Cinza claro','Search...':'Pesquisar…','Search:':'Pesquisar:','Next':'Próximo','Previous':'Anterior','Data':'Dados','Advanced':'Opções avançadas','Servers':'Servidores','Source':'Fonte','Sources':'Fontes','Online':'Ativo','Offline':'Inativo','Transcoding Disabled':'Transcodificação desativada','Disabled':'Desativado'};
  // Estes nomes também podem ser títulos e categorias cadastrados pelo usuário.
  // Traduza-os somente nos controles e cabeçalhos da interface.
  var interfaceTranslations = {
    'Mass Edit Streams':'Editar canais em massa','Mass Edit Movies':'Editar filmes em massa','Mass Edit Series':'Editar séries em massa',
    'Auto Restart':'Reinício automático','Mass Edit':'Editar em massa',
    'No Servers':'Sem servidores','No Categories':'Sem categorias',
    'Topbar Theme':'Tema da barra superior','System Theme':'Tema do sistema','API Key':'Chave da API',
    'Manage Bouquets':'Gerenciar listas de canais','Add Bouquet':'Adicionar lista de canais','Edit Bouquet':'Editar lista de canais',
    'Manage Streams':'Gerenciar canais','Manage Movies':'Gerenciar filmes','Add Movie':'Adicionar filme',
    'Manage Series':'Gerenciar séries','Add Series':'Adicionar série','Manage Episodes':'Gerenciar episódios','Add Episode':'Adicionar episódio',
    'Category Name':'Nome da categoria','Search for a movie...':'Pesquisar filme…','Search for a series...':'Pesquisar série…',
    'Select All':'Selecionar todos','Deselect All':'Desmarcar todos','Clear All':'Limpar tudo','Refresh':'Atualizar',
    'Close':'Fechar','Confirm':'Confirmar','Cancel':'Cancelar','Apply':'Aplicar','Back':'Voltar','Finish':'Concluir',
    'Save Changes':'Salvar alterações','Save changes':'Salvar alterações'
  };
  var columnTranslations = {
    icon:'Ícone',name:'Nome',clients:'Clientes',uptime:'Tempo ativo',player:'Reprodutor',server:'Servidor',
    type:'Tipo',time:'Horário',title:'Título',description:'Descrição',line:'Conta',duration:'Duração',restreamer:'Retransmissor',
    provider:'Provedor',geolocation:'Geolocalização',continent:'Continente',country:'País',city:'Cidade',postcode:'Código postal',
    'lat lng':'Latitude / longitude','isp name':'Nome do provedor',organisation:'Organização','as number':'Número do AS',
    locale:'Localidade',timezone:'Fuso horário','local time':'Hora local','type / reseller':'Tipo / revendedor',
    'domain name':'Nome de domínio','call sign':'Identificação',language:'Idioma',action:'Ação',date:'Data',
    'server ip':'IP do servidor',image:'Imagem',category:'Categoria',seasons:'Temporadas',episodes:'Episódios',
    'first aired':'Estreia','last updated':'Última atualização'
  };
  var filterTranslations = {
    'No Filter':'Sem filtro',Audio:'Áudio',Video:'Vídeo',Down:'Indisponíveis',Stopped:'Parados',Starting:'Iniciando',Timeshift:'Replay',
    Looping:'Em repetição','Has EPG':'Com EPG','Title Sync':'Título sincronizado','No Audio':'Sem áudio','No Video':'Sem vídeo'
  };
  var interfaceLabelSelector='button,label,.navigation-menu a,.topnav-menu a,.dropdown-item,.dropdown-item span,.nav-link,.nav-tabs a,.nav-tabs a span,.nav-pills a,.nav-pills a span,.next a,.previous a,.nextb a,.prevb a,.page-title,.header-title,.jBox-title';
  function nativeFilterLabel(element) {
    var id=element.id||'';
    if(element.tagName==='OPTION'){
      var select=element.closest('select');
      return Boolean(select&&/^(?:stream|movies|episodes)_(?:filter|audio|video|resolution)$/.test(select.id));
    }
    return /^select2-(?:stream|movies|episodes)_(?:filter|audio|video|resolution)-(?:container|result-)/.test(id);
  }
  function labelTranslation(element,key) {
    var normalized=key.replace(/\s+/g,' '),column=columnTranslations[normalized.toLowerCase()],filter=filterTranslations[normalized],label=interfaceTranslations[normalized];
    if(element.matches('#datatable-streampage tbody td:last-child > div'))return normalized==='No information available'?'Nenhuma informação disponível':null;
    if(element.tagName==='TH'&&typeof column==='string')return column;
    if(nativeFilterLabel(element)&&typeof filter==='string')return filter;
    if(element.tagName==='OPTION'&&/\/(?:streams|stream_mass)(?:\.php)?$/.test(location.pathname)&&element.closest('select')&&/^(?:stream_server_id|stream_category_id|category_search)$/.test(element.closest('select').id)&&/^-1$/.test(element.value)&&typeof label==='string')return label;
    if(!element.closest('.nav-user,.pro-user-name')&&(element.matches(interfaceLabelSelector)||element.matches('input[type="submit"],input[type="button"]'))&&typeof label==='string')return label;
    return typeof translations[key]==='string'?translations[key]:null;
  }
  function attributeTranslation(element,attribute,value) {
    if(element.tagName==='TH'&&attribute==='aria-label'){
      var sort=value.match(/^(.+?):\s*(?:activate to sort column (ascending|descending)|ordenar em ordem (crescente|decrescente))$/);
      if(sort)return (labelTranslation(element,sort[1].trim())||sort[1].trim())+': ordenar em ordem '+(sort[2]==='descending'||sort[3]==='decrescente'?'decrescente':'crescente');
    }
    return labelTranslation(element,value);
  }
  function enhanceTopbarTheme() {
    if(!/\/edit_profile(?:\.php)?$/.test(location.pathname))return;
    var select=document.getElementById('hue'),topbar=document.getElementById('topnav');
    if(!select||!topbar)return;
    var preview=select.naxxTopbarPreview;
    if(!preview){
      var help=document.createElement('small');help.className='form-text text-muted';
      help.textContent='Escolha uma cor para visualizar. Salve o perfil para manter a preferência.';
      select.parentElement.appendChild(help);
      var previous=select.value;
      preview=function(){
        var value=select.value;
        if(!['','primary','info','success','danger','warning','purple','pink','dark','secondary'].includes(value)||value===previous)return;
        previous=value;var theme='bg-animate'+(value?'-'+value:'');
        topbar.querySelectorAll('[class*="bg-animate"],[data-theme]').forEach(function(element){
          var classes=Array.from(element.classList).filter(function(name){return /^bg-animate(?:-|$)/.test(name);});
          if(classes.length){classes.forEach(function(name){element.classList.remove(name);});element.classList.add(theme);}
          if(/^bg-animate(?:-|$)/.test(element.getAttribute('data-theme')||'')){
            element.setAttribute('data-theme',theme);
            if(window.jQuery)window.jQuery(element).data('theme',theme);
          }
        });
      };
      select.naxxTopbarPreview=preview;select.addEventListener('change',preview);
    }
    if(window.jQuery&&!preview.jqBound){window.jQuery(select).on('change.naxxTopbarTheme',preview);preview.jqBound=true;}
  }
  function translate(element) {
    Array.from(element.childNodes).forEach(function(node){if(node.nodeType!==3)return;var key=node.textContent.trim(),value=labelTranslation(element,key),duration=key.match(/^(\d+) (Hours?|Days?)$/);if(!value&&duration)value=duration[1]+' '+(duration[2].startsWith('Hour')?(duration[1]==='1'?'hora':'horas'):(duration[1]==='1'?'dia':'dias'));if(value)node.textContent=node.textContent.replace(key,value);});
  }
  function translateInput(input) {
    var placeholder=translations[input.placeholder]||interfaceTranslations[input.placeholder];
    if(typeof placeholder==='string')input.placeholder=placeholder;
    // O valor de uma caixa de texto é dado do usuário, mesmo que seja "Default".
    if(/^(?:submit|button)$/i.test(input.type)){
      var value=labelTranslation(input,input.value);
      if(value)input.value=value;
    }
  }
  var translationSelector='.navigation-menu a,.page-title,.header-title,.cta-box p,.card h1,.card h2,.card h3,.card h4,.card h5,.card h6,.card p,.topnav-menu a,.dropdown-item,.dropdown-item span,.nav-tabs a,.nav-tabs a span,.nav-pills a,.nav-pills a span,.nav-link,.next a,.previous a,button,label,th,option,.jstree-anchor,.select2-selection__placeholder,.apexcharts-legend-text,.timeline-item-info strong,.bootstrap-select .filter-option-inner-inner,.bootstrap-select .text,.select2-selection__rendered,.jBox-content,.jBox-title,.tooltip-inner,.popover-body';
  var translatedAttributes=['placeholder','title','data-original-title','data-content','aria-label'];
  translationSelector+=',.table a[href*="server_view"],.table small';
  translationSelector+=',#datatable-streampage tbody td:last-child > div';
  ['stream','movies','episodes'].forEach(function(page){['filter','audio','video','resolution'].forEach(function(control){translationSelector+=',[id^="select2-'+page+'_'+control+'-result-"]';});});
  Object.assign(translations,{'No Category':'Sem categoria','Add Source as Backup':'Adicionar fonte como reserva','Update Existing':'Atualizar existentes','Search for a stream...':'Pesquisar canal…','Clear':'Limpar'});
  translationSelector+=',.nextb a,.prevb a';
  function within(root,selector){
    var elements=Array.from(root.querySelectorAll(selector));
    if(root.nodeType===1&&root.matches(selector))elements.unshift(root);
    return elements;
  }
  function containsFeature(root,selector){return root===document||(root.nodeType===1&&root.matches(selector))||Boolean(root.querySelector(selector));}
  Object.assign(translations,{'Encoding Queue':'Fila de codificação','Login Logs':'Registros de acesso','On-Demand Scanner':'Verificador sob demanda','Panel Errors':'Erros do painel','Restream Detection':'Detecção de retransmissão','Stream Rank':'Classificação de canais','System Logs':'Registros do sistema','VOD Theft Detection':'Detecção de cópia de VOD','Stream Review':'Revisão de canais'});
  Object.assign(translations,{'No potential issues have been detected!':'Nenhum problema foi detectado.','Online Streams':'Canais ativos','EPG Files':'Guias de programação','Quick Tools':'Ferramentas rápidas','Quality':'Qualidade','Search Streams...':'Pesquisar canais…','All Categories':'Todas as categorias','All Statuses':'Todos os estados','No information available':'Nenhuma informação disponível'});
  Object.assign(translations,{'Channel Order':'Ordem dos canais',"EPG's":'Guias de programação','Fingerprint':'Marca de identificação','Mass Delete':'Excluir em lote','Mass Edit':'Editar em lote','Stream Tools':'Ferramentas de canais','Export as CSV':'Exportar CSV','Actions':'Ações','ACTIONS':'AÇÕES','Start':'Iniciar','Stop':'Parar','Restart':'Reiniciar','Kill Connections':'Encerrar conexões','Edit':'Editar','Delete':'Excluir'});
  Object.assign(translations,{'CPU Usage':'Uso de CPU','Memory Usage':'Uso de memória','IO Usage':'Uso de disco','Input':'Entrada','Output':'Saída','Unique Users':'Usuários únicos','Total Connections':'Total de conexões','Streams Live':'Canais ativos','Down':'Indisponíveis','Requests/sec':'Requisições/s','User Profile':'Meu perfil','General Settings':'Configurações gerais','Backup Settings':'Configurações de backup','Plex Settings':'Configurações Plex','Watch Settings':'Pastas monitoradas','License Info':'Informações da licença','Logout':'Sair'});
  Object.assign(translations,{'Cache & Redis Settings':'Configurações de cache e Redis','Good Performance':'Bom desempenho','Redis Connection Handler is disabled on your service, if you have a lot of throughput you will see better performance with Redis enabled.':'O Redis está desativado neste servidor. Ativá-lo pode melhorar o desempenho quando há muitas requisições.','If you maintain active connections of over 10,000 for example you should consider this. Below this amount you\'re unlikely to see any benefit.':'Considere ativar o Redis se mantiver mais de 10.000 conexões simultâneas. Abaixo disso, provavelmente não haverá ganho.','XUI Caching System':'Sistema de cache do XUI','Redis Connection Handler':'Gerenciador de conexões Redis','Cache Cron Execution':'Execução da rotina de cache','The default is to run the cron every 5 minutes, but when your Streams and Lines tables grow larger it can take a fair amount of time to grab and cache this data. You can change the time to achieve a better balance between performance and data accuracy.':'Por padrão, a rotina é executada a cada 5 minutos. Quando as tabelas de canais e contas crescem, buscar e armazenar esses dados pode levar mais tempo. Ajuste o intervalo para equilibrar desempenho e precisão.','Please ensure the cron format is correct, otherwise it won\'t run.':'Confira se o formato da rotina está correto; caso contrário, ela não será executada.','Minute':'Minuto','Hour':'Hora','Thread Count':'Quantidade de threads','Update Changes Only':'Atualizar somente alterações','Streams':'Canais','Lines':'Contas','Series':'Séries','Time Taken':'Tempo decorrido','Add EPG':'Adicionar EPG'});
  Object.assign(translations,{'Details':'Detalhes','Sources':'Fontes','Categories':'Categorias','Bouquets':'Listas de canais','Fallback Categories':'Categorias padrão','Fallback Bouquets':'Listas de canais padrão','New Categories:':'Novas categorias:','New Bouquets:':'Novas listas:','Transcoding':'Transcodificação','Options':'Opções','Add Stream':'Adicionar canal','Stream Name':'Nome do canal','Stream Logo':'Logo do canal','Notes':'Observações','Capture Server':'Servidor de captura','Video Input':'Entrada de vídeo','Audio Input':'Entrada de áudio','Generate PTS':'Gerar PTS','Native Frames':'Quadros nativos','Stream All Codecs':'Transmitir todos os codecs','Allow Recording':'Permitir gravação','Direct Source':'Fonte direta','Direct Stream':'Transmissão direta','Restart on FPS Drop':'Reiniciar ao cair o FPS','FPS Threshold %':'Limite de FPS (%)','Custom Channel SID':'SID personalizado do canal','On Demand Probesize':'Tamanho da análise sob demanda','Minute Delay':'Atraso (minutos)','User Agent':'Identificação do cliente','HTTP Proxy':'Proxy HTTP','Cookie':'Cookie HTTP','Headers':'Cabeçalhos','Transcoding Profile':'Perfil de transcodificação','Auto-Restart':'Reinício automático','Adaptive Link':'Link adaptável','Sync Title':'Sincronizar título','Map':'Mapeamento','RTMP Push':'Publicação RTMP','Search EPG':'Buscar EPG','Channel Name':'Nome do canal','EPG Source':'Fonte da EPG','No EPG':'Sem EPG','EPG Channel ID':'ID do canal na EPG','EPG Language':'Idioma da EPG','Minute Offset':'Deslocamento (minutos)','Output RTMP':'Saída RTMP','Server Tree':'Servidores de transmissão','On-Demand Servers':'Servidores sob demanda','Low Latency On-Demand':'Sob demanda com baixa latência','Timeshift Server':'Servidor de replay','Timeshift Days':'Dias de replay','Thumbnail Server':'Servidor de miniaturas','Start Stream Now':'Iniciar canal agora','Quick Search':'Busca rápida','XUI EPG':'EPG do XUI','XMLTV EPG':'EPG XMLTV','Advanced Options':'Opções avançadas','Choose...':'Escolha...','Search':'Pesquisar','M3U':'Lista M3U','Import Streams':'Importar canais','Add Single':'Adicionar canal','Manage Streams':'Gerenciar canais','Stream Info':'Informações do canal','Not scanned':'Ainda não analisado','On Demand':'Sob demanda','Direct':'Direto','Stream':'Canal'});
  var streamHelpTranslations = {
    gen_timestamps:'Permite que o FFmpeg gere os timestamps de apresentação para sincronizar áudio e vídeo. Em algumas fontes, isso pode causar dessincronização.',
    read_native:'Para canais ao vivo, mantenha a leitura de quadros nativos desativada. Ative para arquivos de vídeo estáticos quando a codificação exigir esse formato.',
    stream_all:'Transmite todos os codecs da fonte. Use quando a fonte tiver várias faixas de áudio, vídeo ou legendas.',
    direct_source:'Entrega a fonte diretamente ao usuário, sem retransmiti-la pelo XUI. O endereço de origem pode ficar visível para quem reproduzir o canal.',
    direct_proxy:'Com Fonte direta ativada, retransmite pelo servidor para ocultar o endereço original. Aceita MPEG-TS e HLS como entrada, mas a saída para clientes usa MPEG-TS. Recurso experimental.',
    fps_restart:'Reinicia o canal quando a taxa de quadros cair abaixo do limite definido.',
    fps_threshold:'O canal será reiniciado se a taxa de quadros ficar abaixo desta porcentagem da taxa original. O máximo é 100%.',
    custom_sid:'Informe o SID do canal para compatibilidade com EPG em dispositivos Enigma2. Use o código com dois-pontos inicial, sem o primeiro número.',
    probesize_ondemand:'Ajusta o tamanho da análise de fontes sob demanda. Aumente o valor se o canal iniciar sem áudio.',
    delay_minutes:'Atrasa a transmissão pelo número de minutos informado. Não funciona em canais sob demanda.',
    http_proxy:'Formato esperado: IP:porta.',
    cookie:'Informe os cookies HTTP da fonte no formato chave=valor;.',
    headers:'Cabeçalhos HTTP adicionais no formato aceito pelo FFmpeg.',
    transcode_profile_id:'Use transcodificação quando for necessário ampliar a compatibilidade com dispositivos. Ela só ocorre no servidor conectado diretamente à fonte.',
    adaptive_link:'Agrupa canais para que o cliente escolha uma fonte adequada à largura de banda ao solicitar HLS. A seleção não depende das listas do usuário; MPEG-TS reproduz o canal normalmente.',
    title_sync:'Sincroniza o título com um provedor de canais configurado no XUI. O título é atualizado pela rotina automática do painel.',
    rtmp_output:'Envia o canal ao servidor RTMP para distribuição a clientes RTMP.',
    llod:'NAXX Automático analisa as fontes ao salvar e escolhe um modo compatível validado. A decisão aparece abaixo do campo. Após alterar a fonte, analise novamente. Os modos manuais continuam disponíveis.'
  };
  var brandAssetVersion = 'dc7f713aa259';
  var stylesheetVersion = '5722a2666358';
  Object.assign(translations,{"Settings": "Configurações gerais", "Save Changes": "Salvar alterações", "General": "Geral", "Security": "Segurança", "Streaming": "Transmissão", "Web Player": "Player web", "Logs": "Registros", "Preferences": "Preferências", "Server Name": "Nome do servidor", "Server Timezone": "Fuso horário do servidor", "Message of the Day": "Mensagem do dia", "Show Entries": "Itens por página", "Fails Per Time": "Falhas por período", "Date Format": "Formato da data", "Datetime Format": "Formato de data e hora", "Group Streams Table": "Agrupar transmissões na tabela", "Seamless Navigation": "Navegação sem recarregar a página", "Show Tickets Icon": "Exibir ícone de chamados", "Disable Restart Counter": "Desativar contador de reinicializações", "Auto-Cleanup Files": "Limpar arquivos automaticamente", "Check VOD Cron": "Verificar rotina de VOD", "Show Images & Picons": "Exibir imagens e ícones de canais", "Group Buttons": "Agrupar botões", "Quick Edit Modal": "Janela de edição rápida", "MySQL Sleep Timeout": "Tempo limite de conexões ociosas no MySQL", "Show Graphs": "Exibir gráficos", "Show Connections Map": "Exibir mapa de conexões", "Alternate Server View": "Visualização alternativa de servidores", "Show Header Stats": "Exibir estatísticas no cabeçalho", "Show Service Status": "Exibir estado dos serviços", "CPU Threshold %": "Limite de CPU (%)", "Memory Threshold %": "Limite de memória (%)", "Disk Threshold %": "Limite de disco (%)", "Network Threshold %": "Limite de rede (%)", "Clients Threshold %": "Limite de clientes (%)", "Search": "Pesquisa", "Enable Search": "Ativar pesquisa", "Number of Items": "Quantidade de itens", "Reseller": "Revendedor", "Disable Trials": "Desativar testes", "SSL Custom DNS": "DNS personalizado com SSL", "Debug": "Diagnóstico", "Debug Mode": "Modo de diagnóstico", "Auto-Send Logs to XUI": "Enviar registros automaticamente ao XUI", "Enable reCAPTCHA": "Ativar reCAPTCHA", "reCAPTCHA V2 - Site Key": "reCAPTCHA V2 — chave do site", "reCAPTCHA V2 - Secret Key": "reCAPTCHA V2 — chave secreta", "Default Arguments": "Parâmetros padrão", "User Agent": "Agente de usuário", "HTTP Proxy": "Proxy HTTP", "Headers": "Cabeçalhos", "On Demand Probesize": "Tamanho da análise sob demanda", "IP Security": "Segurança de IP", "Match Subnet of IP": "Verificar sub-rede do IP", "Logout On IP Change": "Encerrar sessão ao mudar de IP", "Restrict to Same IP": "Restringir ao mesmo IP", "Random RTMP IP": "IP RTMP aleatório", "Disallow 2nd IP": "Bloquear segundo IP", "Disallow if Connections <=": "Bloquear se as conexões forem menores ou iguais a", "Restream Prevention": "Prevenção de retransmissão", "XUI Detect - Deny": "Detecção de XUI — negar acesso", "XUI Detect - Ban Lines": "Detecção de XUI — banir contas", "Block Hosting Servers": "Bloquear servidores de hospedagem", "Block Proxies / VPN's": "Bloquear proxies e VPNs", "Spam Prevention": "Prevenção de abuso", "Flood Limit": "Limite de requisições", "Per Seconds": "Período em segundos", "Auth Flood Limit": "Limite de requisições de autenticação", "Auth Flood Seconds": "Período de autenticação em segundos", "Auth Flood Sleep": "Pausa após excesso de autenticações", "Flood IP Exclusions": "IPs isentos do limite de requisições", "Detect MAC Bruteforce": "Detectar tentativas de força bruta por MAC", "Detect Username Bruteforce": "Detectar tentativas de força bruta por usuário", "Bruteforce Frequency": "Intervalo de verificação de força bruta", "Maximum Login Attempts": "Máximo de tentativas de login", "Max Simultaneous Downloads": "Máximo de downloads simultâneos", "TMDb Key": "Chave do TMDb", "TMDb Language": "Idioma do TMDb", "Download Images": "Baixar imagens", "API Redirect": "Redirecionamento da API", "Append Movie Year": "Adicionar ano ao título do filme", "API Container": "Formato de saída da API", "Cache Playlists for": "Manter listas em cache por", "Grab Playlists from MySQL": "Obter listas diretamente do MySQL", "Force EPG to UTC Timezone": "Forçar EPG no fuso UTC", "Keep Request Protocol": "Manter protocolo da requisição", "VOD Parser": "Analisador de títulos de VOD", "Enable Cloudflare": "Ativar Cloudflare", "Legacy Support": "Compatibilidade com aplicativos antigos", "Legacy Playlist URL": "URL de lista para aplicativos antigos", "Legacy XMLTV URL": "URL XMLTV para aplicativos antigos", "Legacy Panel API": "API do painel para aplicativos antigos", "Duplicate Streams in Legacy Apps": "Duplicar transmissões em aplicativos antigos", "EPG API": "API do guia de programação", "Enable EPG API": "Ativar API do guia de programação", "Append Extra Data": "Incluir dados adicionais", "Days to Fetch": "Dias para buscar", "Days to Keep": "Dias para manter", "API Services": "Serviços da API", "Admin Streaming IP's": "IPs de transmissão dos administradores", "API IP's": "IPs autorizados na API", "API Password": "Senha da API", "Disable EPG Download - Line": "Desativar download de EPG para contas", "Disable EPG Download - Restreamer": "Desativar download de EPG para retransmissores", "Disable Playlist Download - Line": "Desativar download de listas para contas", "Disable Playlist Download - Restreamer": "Desativar download de listas para retransmissores", "Disable Player API": "Desativar API do player", "Disable Enigma2 API": "Desativar API Enigma2", "Disable Ministra API": "Desativar API Ministra", "Verify Hosts": "Verificar servidores de origem", "Streaming Password": "Senha de transmissão", "Enable ISP Lock": "Ativar bloqueio por provedor", "Enable ASN Lock": "Ativar bloqueio por ASN", "Disable MPEG-TS Output": "Desativar saída MPEG-TS", "Allow Restreamers - MPEG-TS": "Permitir retransmissores em MPEG-TS", "Disable HLS Output": "Desativar saída HLS", "Allow Restreamers - HLS": "Permitir retransmissores em HLS", "Disable RTMP Output": "Desativar saída RTMP", "Allow Restreamers - RTMP": "Permitir retransmissores em RTMP", "Case Sensitive Lines": "Diferenciar maiúsculas e minúsculas nas contas", "Override Country with First": "Usar país da primeira conexão", "Encrypt HLS Segments": "Criptografar segmentos HLS", "Disallow Empty UA": "Bloquear agente de usuário vazio", "VOD Bitrate Buffer": "Buffer de taxa de bits do VOD", "VOD Limit At %": "Limitar VOD a (%)", "Auto-Kick Hours": "Desconectar automaticamente após horas", "Use Domain Name in API": "Usar nome de domínio na API", "Encrypt Playlists": "Criptografar listas", "Encrypt Restreamer Playlists": "Criptografar listas de retransmissores", "Restrictions on Playlists & EPG": "Aplicar restrições às listas e ao EPG", "Ignore Invalid Credentials": "Ignorar credenciais inválidas", "Client Prebuffer": "Buffer inicial do cliente", "Restreamer Prebuffer": "Buffer inicial do retransmissor", "Load Balancing": "Balanceamento de carga", "Restreamer Bypass Proxy": "Permitir que retransmissores ignorem o proxy", "Channel Sorting Type": "Tipo de ordenação dos canais", "Sort VOD by Date": "Ordenar VOD por data", "Use Nginx Buffer": "Usar buffer do Nginx", "Log Client ISP's": "Registrar provedor dos clientes", "Online Capacity Interval": "Intervalo de atualização da capacidade", "Monitor Connection Status": "Monitorar estado das conexões", "Auto-Restart Crashed PHP-FPM": "Reiniciar PHP-FPM automaticamente após falhas", "Kill Rogue FFMPEG PID's": "Encerrar processos FFMPEG órfãos", "Redirect Expiration": "Validade do redirecionamento", "HLS Read Native": "Leitura nativa de HLS", "Read Buffer Size": "Tamanho do buffer de leitura", "Redis Connection Sync Timer": "Intervalo de sincronização de conexões do Redis", "Allow CDN / Forwarding": "Permitir CDN e encaminhamento", "Max Failures": "Máximo de falhas", "On-Demand Settings": "Configurações sob demanda", "Instant Off": "Desligamento imediato", "Exit on Failure": "Encerrar em caso de falha", "Wait Timeout": "Tempo limite de espera", "Request Prebuffer": "Solicitar buffer inicial", "Balance As Live": "Balancear como transmissão ao vivo", "On-Demand Scanner": "Verificador de conteúdo sob demanda", "Enable Scanner": "Ativar verificador", "Scan Time": "Intervalo de verificação", "Max Probe Time": "Tempo máximo de análise", "Keep Logs For": "Manter registros por", "Encoding Queue Settings": "Configurações da fila de codificação", "Max Movie Encodes": "Máximo de filmes em codificação", "Max Channel Encodes": "Máximo de canais em codificação", "Queue Loop Timer": "Intervalo da fila", "Segment Settings": "Configurações de segmentos", "Segment Duration": "Duração do segmento", "List Size": "Tamanho da lista", "Delete Threshold": "Limite para exclusão", "Max Segment Wait Time": "Tempo máximo de espera por segmento", "Analysis Duration": "Duração da análise", "Probe Size": "Tamanho da análise", "FFMPEG Version": "Versão do FFMPEG", "FFMPEG Segment Type": "Tipo de segmento do FFMPEG", "FFMPEG Show Warnings": "Exibir avisos do FFMPEG", "Ignore Keyframes": "Ignorar quadros-chave", "DTS - Use FFMPEG v4.0": "DTS — usar FFMPEG v4.0", "Loopback Streams via PHP": "Retornar transmissões pelo PHP", "Stream Monitor Settings": "Configurações do monitor de transmissões", "Restart on Audio Loss": "Reiniciar ao perder o áudio", "Priority Backup": "Prioridade da fonte reserva", "Probe Duration": "Duração da análise inicial", "Stream Failure Sleep": "Pausa após falha de transmissão", "FPS Start Delay": "Atraso inicial da verificação de FPS", "FPS Check Type": "Tipo de verificação de FPS", "Probe via API": "Analisar pela API", "Off Air Videos": "Vídeos para conteúdo fora do ar", "Stream Down Video": "Vídeo de transmissão indisponível", "Banned Video": "Vídeo de conta banida", "Expired Video": "Vídeo de conta expirada", "Expiring Video": "Vídeo de aviso de vencimento", "2nd IP Connected Video": "Vídeo de segundo IP conectado", "Allowed Countries": "Países permitidos", "Show All Categories": "Exibir todas as categorias", "Default Container": "Formato padrão", "Always Enabled Subtitles": "Manter legendas ativadas", "Connection Problem Indiciation": "Indicar problemas de conexão", "Show Channel Logos": "Exibir logos dos canais", "Show Preview Channel Logos": "Exibir prévia dos logos dos canais", "Playback Limit": "Limite de reprodução", "Default Aspect Ratio": "Proporção de imagem padrão", "Default Theme Type": "Tipo de tema padrão", "Legacy Theme": "Tema para modelos antigos", "Legacy URL Redirect": "Redirecionar URLs antigas", "Keep URL Extension": "Manter extensão da URL", "Disable SSL": "Desativar SSL", "Load Channels on Startup": "Carregar canais ao iniciar", "Disable MAG Token": "Desativar token MAG", "Allowed STB Types": "Tipos de aparelhos permitidos", "Allowed STB Recording": "Aparelhos autorizados a gravar", "Speedtest URL": "URL do teste de velocidade", "Information Message": "Mensagem informativa", "Allow Playlist Download": "Permitir download de listas", "Allow Bouquet Ordering": "Permitir ordenar listas de canais", "Hide Incompatible Streams": "Ocultar transmissões incompatíveis", "Mark HEVC as Compatible": "Marcar HEVC como compatível", "Background Blur px": "Desfoque do fundo (px)", "Background Opacity %": "Opacidade do fundo (%)", "Extract Subtitles": "Extrair legendas", "Activity Logs": "Registros de atividade", "Client Logs": "Registros de clientes", "Login Logs": "Registros de login", "Stream Error Logs": "Registros de erros de transmissão", "Stream Restart Logs": "Registros de reinicialização de transmissões", "Brackets": "Parênteses", "Hyphen": "Hífen", "Default Format": "Formato padrão", "Extended Title": "Título ampliado", "Extended Description": "Descrição ampliada", "Max Clients": "Máximo de clientes", "Network Speed": "Velocidade da rede", "Detected Network Speed": "Velocidade de rede detectada", "Bouquet": "Lista de canais", "Legacy": "Antigo", "Progress Info": "Informações de progresso", "Modern": "Moderno", "Forever": "Para sempre", "All Countries": "Todos os países", "Remove item": "Remover item", "Choose...": "Selecione…", "Default - EN": "Padrão — inglês", "Leave blank to use default XUI video.": "Deixe em branco para usar o vídeo padrão do XUI.", "Cancel": "Cancelar", "Use Icon": "Usar ícone", "Adjust Credits": "Ajustar créditos", "Reason for Adjustment...": "Motivo do ajuste…", "Record": "Gravar", "Clear Stream Logs": "Limpar registros da transmissão", "Reinstall Server": "Reinstalar servidor", "Restart Services": "Reiniciar serviços", "Reboot Server": "Reiniciar servidor", "Update Binaries": "Atualizar binários", "Update Server": "Atualizar servidor"});
  var settingsHelpTranslations = {};
  Object.assign(settingsHelpTranslations,{"server_name": "Nome do seu serviço de transmissão.", "default_timezone": "Fuso horário padrão das interfaces de administração e revenda. É usado por todos os usuários até que escolham outro fuso no próprio perfil.", "message_of_day": "Mensagem exibida na API do player. Alguns aplicativos Android usam essa informação.", "default_entries": "Quantidade de itens exibidos por página nas tabelas das interfaces de administração e revenda.", "fails_per_time": "Período, em segundos, usado para contar as falhas na página de transmissões: falhas a cada X segundos.", "date_format": "Formato padrão das datas. Consulte os códigos de formatação de datas do PHP antes de alterar.", "datetime_format": "Formato padrão de data e hora. Consulte os códigos de formatação de datas do PHP antes de alterar.", "streams_grouped": "Agrupa os servidores de uma mesma transmissão em uma única linha, reduzindo a quantidade de linhas da tabela.", "js_navigate": "Usa JavaScript para carregar páginas sem recarregar toda a interface. Esse recurso fica desativado em dispositivos móveis.", "show_tickets": "Exibe o ícone de chamados no canto superior direito do menu. Ao desativar, os chamados ficam no menu de gerenciamento.", "hide_failures": "Oculta o contador de reinicializações ao lado do tempo de atividade da transmissão.", "cleanup": "Remove automaticamente arquivos desnecessários em segundo plano. Opção recomendada.", "check_vod": "Verifica periodicamente se os arquivos de VOD existem. Se não existirem, marca o conteúdo como não codificado. Não é recomendado para acervos muito grandes.", "show_images": "Exibe os logos dos canais e as imagens de VOD nas páginas de gerenciamento.", "group_buttons": "Agrupa os botões de ação em um menu nas páginas compatíveis.", "modal_edit": "Abre a edição em uma janela sobre a página atual, sem sair dela.", "mysql_sleep_kill": "Tempo permitido para uma conexão MySQL permanecer ociosa, no estado Sleep, antes de ser encerrada. Use 0 para desativar.", "dashboard_stats": "Exibe gráficos de recursos do sistema, rede e conexões na visão geral.", "dashboard_map": "Exibe o mapa das conexões na visão geral.", "dashboard_display_alt": "Troca os cartões dos servidores entre os formatos largo e quadrado na visão geral.", "header_stats_sh": "Exibe as estatísticas dos servidores no menu do cabeçalho.", "dashboard_status": "Exibe avisos conforme as estatísticas dos servidores.", "threshold_cpu": "Quando o uso de CPU ultrapassar esta porcentagem, será exibido um aviso no quadro de estado dos serviços.", "threshold_mem": "Quando o uso de memória ultrapassar esta porcentagem, será exibido um aviso no quadro de estado dos serviços.", "threshold_disk": "Quando o uso de disco ultrapassar esta porcentagem, será exibido um aviso no quadro de estado dos serviços.", "threshold_network": "Quando o uso da rede ultrapassar esta porcentagem, será exibido um aviso no quadro de estado dos serviços.", "threshold_clients": "Exibe um aviso quando a quantidade de clientes, em relação ao máximo permitido pelo servidor, ultrapassar esta porcentagem.", "enable_search": "Exibe a pesquisa no canto superior direito do cabeçalho e permite que o mecanismo de cache grave as consultas de pesquisa no banco de dados.", "search_items": "Quantidade de resultados exibidos na pesquisa. O máximo é 100.", "disable_trial": "Desativa temporariamente a criação de testes para todas as contas.", "reseller_ssl_domain": "Usa HTTPS nos downloads de listas quando o servidor principal tem SSL ativo e o revendedor usa um DNS personalizado.", "debug_show_errors": "Ativa a exibição de erros para diagnosticar problemas no painel. As mensagens podem incluir detalhes técnicos do sistema.", "auto_send_logs": "Envia automaticamente os registros de erros do painel para análise e verificação pela equipe do XUI.", "recaptcha_v2_site_key": "Acesse https://google.com/recaptcha/admin para obter as chaves do reCAPTCHA.", "recaptcha_v2_secret_key": "Acesse https://google.com/recaptcha/admin para obter as chaves do reCAPTCHA.", "http_proxy": "Formato: IP:porta.", "cookie": "Formato: chave=valor;", "headers": "Cabeçalhos enviados pelo parâmetro -headers do FFmpeg.", "probesize_ondemand": "Tamanho da análise inicial das transmissões sob demanda. Ajuste se houver problemas de ausência de áudio.", "ip_subnet_match": "Aceita mudanças de IP dentro da mesma sub-rede /24, mantendo a verificação de segurança menos restritiva. Por exemplo, 159.55.26.0 e 159.55.26.255 serão considerados equivalentes.", "ip_logout": "Encerra a sessão se o IP mudar durante o uso, ajudando a proteger contra o uso indevido de cookies.", "restrict_same_ip": "Vincula as conexões HLS ao endereço IP de origem. Desative se isso causar problemas com IPs dinâmicos.", "rtmp_random": "Usa um IP aleatório nas conexões RTMP.", "disallow_2nd_ip_con": "Impede uma conexão de outro IP enquanto a conta já estiver em uso.", "disallow_2nd_ip_max": "A restrição ao segundo IP só se aplica às contas cujo limite de conexões seja menor ou igual a este valor. Por exemplo, com 3, contas com limite de até 3 conexões serão desconectadas ao conectar por outro IP.", "restream_deny_unauthorised": "Nega conexões de contas sem permissão de retransmissão que tentem usar o XUI para retransmitir conteúdo.", "detect_restream_block_user": "Bane contas sem permissão de retransmissão que tentem usar o XUI para retransmitir conteúdo.", "block_streaming_servers": "Bloqueia automaticamente servidores identificados como pertencentes a provedores de hospedagem. Não afeta retransmissores autorizados.", "block_proxies": "Bloqueia automaticamente proxies e VPNs conforme o ASN. Não afeta retransmissores autorizados.", "flood_limit": "Quantidade de tentativas antes de bloquear o IP. Use 0 para desativar a detecção de excesso de requisições.", "flood_seconds": "Período, em segundos, usado para contar as requisições.", "auth_flood_limit": "Quantidade de requisições válidas antes de aplicar uma pausa. Use 0 para desativar.<br/><br/>Este limite se aplica apenas a clientes autenticados. Por exemplo, após 30 conexões em 10 segundos, as próximas requisições podem aguardar 1 segundo durante o período de controle.", "auth_flood_seconds": "Período, em segundos, usado para contar as requisições autenticadas.", "auth_flood_sleep": "Tempo de espera aplicado ao atingir o limite de requisições autenticadas. A requisição continua após a pausa.", "flood_ips_exclude": "Separe os endereços IP por vírgulas.", "bruteforce_mac_attempts": "Detecta e bloqueia automaticamente IPs com tentativas de força bruta contra dispositivos MAG ou Enigma. Use 0 tentativas para desativar.", "bruteforce_username_attempts": "Detecta e bloqueia automaticamente IPs com tentativas de força bruta contra contas. Use 0 tentativas para desativar.", "bruteforce_frequency": "Período usado para contar as tentativas de força bruta por MAC e usuário: X tentativas a cada X segundos.", "login_flood": "Quantidade de tentativas de login permitidas antes de bloquear o IP. Use 0 para não limitar, por exemplo, ao utilizar reCAPTCHA ou código de acesso como proteção.", "max_simultaneous_downloads": "Máximo de downloads simultâneos de EPG e listas por usuário. Não afeta retransmissores. Requisições excedentes recebem o erro HTTP 429. Use 0 para desativar o limite.", "tmdb_api_key": "Obtenha sua chave de API em <a href='https://www.themoviedb.org/settings/api'>https://www.themoviedb.org/settings/api</a>.", "tmdb_language": "Idioma padrão das consultas ao TMDb. Pode ser alterado individualmente em cada filme ou série.", "download_images": "Baixa para o servidor principal as imagens obtidas de serviços como o TMDb.", "api_redirect": "Redireciona as requisições de transmissão da API usando tokens criptografados com AES, em vez de URLs com usuário e senha. Pode permanecer desativado se seus aplicativos não utilizarem esse recurso.", "movie_year_append": "Adiciona automaticamente o ano ao título do filme ao usar o TMDb ou as pastas monitoradas.", "api_container": "Formato de saída padrão usado em aplicativos Android e Smart TVs.", "cache_playlists": "Quando maior que 0, mantém as listas baixadas pelos clientes em cache por esta quantidade de segundos. Reduz o processamento, mas pode ocupar bastante disco com muitos clientes.", "playlist_from_mysql": "Lê as transmissões diretamente do MySQL em vez do cache local. Pode ser mais rápido quando há uma grande quantidade de transmissões.", "force_epg_timezone": "Gera o EPG e os horários das APIs em UTC. Também informa UTC como fuso na API do player para sincronizar os aplicativos.", "keep_protocol": "Mantém nas listas e transmissões o protocolo solicitado pelo cliente: HTTP ou HTTPS.", "parse_type": "Escolhe entre GuessIt e PTN para interpretar nomes de arquivos nas pastas monitoradas e em outros recursos. O GuessIt costuma ser mais preciso, mas usa mais recursos.", "cloudflare": "Permite conexões dos IPs da Cloudflare e o encaminhamento do IP real do cliente para o XUI.", "legacy_get": "Redireciona requisições de get.php para a nova URL de listas.", "legacy_xmltv": "Redireciona requisições de xmltv.php para a nova URL do EPG.", "legacy_panel_api": "Redireciona requisições de panel_api.php para a nova API do player do XUI.", "show_category_duplicates": "Repete o conteúdo em cada categoria à qual ele pertence para melhorar a compatibilidade com aplicativos antigos. Como consequência, o mesmo item pode aparecer várias vezes na pesquisa ou na categoria Todos.", "enable_epg_api": "Ativa a API do guia de programação na interface de administração.", "epg_api_extended": "Acrescenta informações aos dados de EPG recebidos, como o nome do programa.", "epg_api_days_fetch": "Quantidade de dias buscados ao obter os dados de EPG.", "epg_api_days_keep": "Quantidade de dias de EPG mantidos no armazenamento.", "allowed_ips_admin": "IPs autorizados a acessar transmissões com a senha de transmissão administrativa. Separe os IPs por vírgulas.", "api_ips": "IPs autorizados a acessar a API administrativa do XUI. Separe os IPs por vírgulas.", "api_password": "Senha necessária para acessar a API administrativa do XUI. Deixe em branco para usar somente a lista de IPs autorizados.", "disable_xmltv": "Impede o download do guia de programação no formato XMLTV para contas comuns.", "disable_xmltv_restreamer": "Impede o download do guia de programação no formato XMLTV para retransmissores.", "disable_playlist": "Impede que contas comuns baixem listas HLS ou listas para dispositivos.", "disable_playlist_restreamer": "Impede que retransmissores baixem listas HLS ou listas para dispositivos.", "disable_player_api": "Impede o acesso à API por aplicativos Android e Smart TVs.", "disable_enigma2": "Impede a conexão de dispositivos Enigma.", "disable_ministra": "Impede a conexão de dispositivos MAG pela API Ministra.", "verify_host": "Confere os domínios e IPs com os endereços autorizados no banco de dados, incluindo IPs de servidores, domínios e DNS dos revendedores.", "enable_isp_lock": "Ativa ou desativa globalmente o bloqueio por provedor de internet.", "block_svp": "Ativa ou desativa globalmente o bloqueio por ASN.", "disable_ts": "Desativa a saída MPEG-TS para todos os clientes e dispositivos.", "disable_ts_allow_restream": "Permite que retransmissores continuem usando MPEG-TS mesmo com essa saída desativada.", "disable_hls": "Desativa a saída HLS para todos os clientes e dispositivos.", "disable_hls_allow_restream": "Permite que retransmissores continuem usando HLS mesmo com essa saída desativada.", "disable_rtmp": "Desativa a saída RTMP para todos os clientes e dispositivos.", "disable_rtmp_allow_restream": "Permite que retransmissores continuem usando RTMP mesmo com essa saída desativada.", "case_sensitive_line": "Diferencia letras maiúsculas e minúsculas no usuário e na senha das contas.", "county_override_1st": "Usa o país identificado na primeira conexão da conta.", "encrypt_hls": "Criptografa as transmissões HLS com AES-256 durante a reprodução. Aumenta o uso de CPU e protege o conteúdo dos pacotes.", "disallow_empty_user_agents": "Bloqueia conexões de clientes que não informam o agente de usuário.", "vod_bitrate_plus": "Buffer adicional usado na transmissão de VOD.", "vod_limit_perc": "Aplica o limite de velocidade após transmitir esta porcentagem do VOD. Use 0 para limitar desde o início ou 100 para desativar a limitação.", "user_auto_kick_hours": "Desconecta automaticamente clientes que permanecerem conectados por mais que esta quantidade de horas.", "use_mdomain_in_lists": "Usa o nome de domínio nas listas.", "encrypt_playlist": "Criptografa as credenciais das contas nos arquivos de listas.", "encrypt_playlist_restreamer": "Criptografa as credenciais nos arquivos de listas dos retransmissores.", "restrict_playlists": "Verifica agente de usuário, IP, provedor e país antes de permitir downloads de listas ou EPG. Ao desativar, os downloads podem ser feitos de qualquer IP; as restrições das transmissões continuam valendo.", "ignore_invalid_users": "Encerra rapidamente conexões com usuário ou senha incorretos, sem carregar as funções do XUI nem acionar o limite de requisições. Pode reduzir o uso de CPU em servidores com muitas requisições.", "client_prebuffer": "Quantidade de dados, em segundos de reprodução, enviada inicialmente ao cliente quando ele se conecta à transmissão. Valores maiores aumentam o buffer inicial.", "restreamer_prebuffer": "Quantidade de dados, em segundos de reprodução, enviada inicialmente ao retransmissor quando ele se conecta à transmissão. Valores maiores aumentam o buffer inicial.", "split_by": "Critério preferido para distribuir conexões entre os servidores.", "restreamer_bypass_proxy": "Encaminha retransmissores diretamente aos balanceadores, sem passar pelos proxies quando o serviço de proxy estiver ativo.", "channel_number_type": "Critério preferido para ordenar os canais nas listas e nos aplicativos.", "vod_sort_newest": "Ordena o VOD pela data de inclusão, do mais recente para o mais antigo. Para funcionar corretamente, o tipo de ordenação dos canais deve estar definido como Lista de canais.", "use_buffer": "Ativa o buffer do proxy para a conexão. Ao desativar, as respostas são enviadas sem esse buffer; ao ativar, a resposta pode ser armazenada temporariamente pelo proxy.", "show_isps": "Obtém o provedor de internet de cada cliente conectado e armazena essa informação no banco de dados.", "online_capacity_interval": "Intervalo de verificação da atividade dos servidores para calcular os limites de conexões.", "monitor_connection_status": "Verifica connection_status() do PHP durante a transmissão de canais e VOD. Encerra a conexão quando o estado retornado deixa de ser CONNECTION_NORMAL.", "restart_php_fpm": "Executa uma rotina que reinicia o PHP-FPM quando ele falha e são encontrados erros.", "kill_rogue_ffmpeg": "Verifica a cada minuto os processos FFmpeg de transmissões que deveriam estar paradas e os encerra. Também faz essa limpeza antes de iniciar uma transmissão.", "create_expiration": "Validade, em segundos, do redirecionamento do servidor principal para um balanceador. Aumente se houver muitos erros TOKEN_EXPIRED nos registros.", "read_native_hls": "Ativa a leitura nativa em todas as transmissões HLS. Desative para configurar individualmente em cada transmissão compatível.", "read_buffer_size": "Tamanho do buffer usado para ler arquivos em blocos.", "connection_sync_timer": "Intervalo entre execuções da rotina de sincronização das conexões do Redis.", "allow_cdn_access": "Aceita o IP real encaminhado pelo cabeçalho X-Forwarded-For e usa tokens no lugar da criptografia do caminho das transmissões.<br/>Exige configurar os IPs autorizados para encaminhamento. Recurso de uso avançado.", "stop_failures": "Quantidade de falhas antes de encerrar o monitor da transmissão. Com 3, o monitor para após três falhas e pode ser reiniciado pela rotina de transmissões no minuto seguinte. Use 0 para continuar tentando indefinidamente.", "on_demand_instant_off": "Ao desconectar um cliente de uma transmissão sob demanda, verifica se ainda há espectadores e desliga a transmissão se não houver nenhum.", "on_demand_failure_exit": "Se a transmissão sob demanda falhar ao iniciar, encerra a tentativa e desconecta o cliente. Uma nova conexão fará outra tentativa, evitando tentativas contínuas que ocupem a fonte.", "on_demand_wait_time": "Tempo de espera para iniciar uma transmissão sob demanda. Ao esgotar esse tempo, a conexão é encerrada. Também se aplica a transmissões comuns enquanto iniciam ou estão indisponíveis.", "request_prebuffer": "Solicita um buffer inicial ao provedor para iniciar a reprodução mais rapidamente. Requer um provedor XUI e pode deixar o conteúdo cerca de 10 segundos atrasado.<br/><br/>Pela URL: adiciona ?prebuffer=1. Pelo cabeçalho: envia a solicitação em um cabeçalho, aceito pelo XUI a partir da versão 1.4.4.", "ondemand_balance_equal": "Trata servidores sob demanda como servidores já ativos no balanceamento. Assim, um servidor sob demanda pode ser iniciado mesmo que outro servidor já transmita o mesmo conteúdo.", "on_demand_checker": "Analisa periodicamente o estado, a resolução, os codecs, o FPS e o tempo de resposta das transmissões sob demanda. Registra os erros no banco e verifica uma transmissão por vez em cada servidor.", "on_demand_scan_time": "Intervalo, em segundos, entre as verificações de uma transmissão.", "on_demand_max_probe": "Tempo máximo, em segundos, de análise da transmissão antes de cancelar.", "on_demand_scan_keep": "Tempo de retenção dos registros, em segundos. Afeta as estatísticas de disponibilidade da página de registros. O padrão é 604800 segundos, equivalente a uma semana.", "max_encode_movies": "Máximo de filmes codificados simultaneamente por servidor. Use um valor compatível com a capacidade do servidor; valores maiores são adequados quando todo o conteúdo usa links simbólicos.", "max_encode_cc": "Máximo de canais criados codificados simultaneamente por servidor. Recomenda-se 1, exceto quando todos usam links simbólicos.", "queue_loop": "Intervalo entre as verificações da fila. Se o conteúdo usar links simbólicos, recomenda-se 1 segundo.", "seg_time": "Duração de cada segmento HLS. Os quadros-chave podem impedir a duração exata, mas o valor deve funcionar na maioria das transmissões.", "seg_list_size": "Quantidade de segmentos mantidos na lista HLS.", "seg_delete_threshold": "Quantidade de segmentos antigos mantidos ao gerar a lista HLS. Valores menores economizam RAM, mas mantenha um buffer suficiente para novos clientes. Por exemplo, 30 segundos de buffer precisam de três segmentos de 10 segundos.", "segment_wait_time": "Tempo máximo, em segundos, de espera por um novo segmento. Ao esgotar esse tempo sem novos dados, a conexão do cliente é encerrada.", "stream_max_analyze": "Tempo de análise da transmissão. Um tempo maior melhora a precisão da amostra. 5.000.000 de microssegundos equivalem a 5 segundos.", "probesize": "Quantidade de dados analisados, em bytes.", "ffmpeg_cpu": "Versão do FFmpeg usada para filmes, canais criados e transmissões comuns.<br/><br/>v4.0: versão antiga, de 2018, fornecida originalmente com o XUI.<br/>v4.3.2 e v4.4: versões compiladas pelo XUI com mais bibliotecas e suporte a DASH e NVENC.", "segment_type": "Escolhe -f segment ou -f hls no processamento. A opção hls foi criada para HLS e tende a funcionar melhor. A opção segment desativa o limite de exclusão e é usada por padrão nas transmissões sob demanda para agilizar o início.", "ffmpeg_warnings": "Grava também os avisos do FFmpeg na tabela de erros das transmissões. Ao desativar, grava somente erros.", "ignore_keyframes": "Permite iniciar segmentos fora dos quadros-chave. Pode ajudar alguns players quando o intervalo entre quadros-chave varia, mas prejudicar outros ou causar tela preta no início até o vídeo começar.", "dts_legacy_ffmpeg": "Usa automaticamente o FFmpeg v4.0 em transmissões com áudio DTS. Pode corrigir falhas de sincronização do áudio. A opção de gerar PTS deve estar desativada.", "php_loopback": "Usa o PHP para ler diretamente as transmissões de retorno e gerar HLS, sem passar pelo FFmpeg.", "audio_restart_loss": "Reinicia periodicamente a transmissão se não houver áudio detectado.", "priority_backup": "Retorna à primeira fonte quando ela voltar a funcionar.", "probe_extra_wait": "Tempo de espera adicional após a duração de análise antes de cancelar a verificação da transmissão.", "stream_fail_sleep": "Tempo de espera, em segundos, após uma falha ao iniciar a transmissão antes de tentar novamente.", "fps_delay": "Tempo de espera, em segundos, antes de verificar se o FPS caiu abaixo do limite.", "fps_check_type": "Escolhe entre usar as informações de progresso após o atraso inicial ou analisar um segmento e usar avg_frame_rate para determinar o FPS.", "api_probe": "Usa chamadas de API para analisar as fontes a partir dos servidores XUI.", "show_not_on_air_video": "Exibe este vídeo quando a transmissão estiver fora do ar.", "show_banned_video": "Exibe este vídeo quando uma conta banida tentar acessar uma transmissão.", "show_expired_video": "Exibe este vídeo quando uma conta expirada tentar acessar uma transmissão.", "show_expiring_video": "Exibe este vídeo uma vez por dia durante os sete dias anteriores ao vencimento da conta.", "show_connected_video": "Exibe este vídeo quando o cliente for bloqueado por já estar conectado por outro IP.", "show_all_category_mag": "Exibe a categoria Todos nos dispositivos MAG.", "always_enabled_subtitles": "Mantém as legendas sempre ativadas.", "playback_limit": "Exibe um aviso e interrompe a transmissão após esta quantidade de horas de reprodução contínua.", "tv_channel_default_aspect": "Define a proporção de imagem padrão das transmissões. A opção Ajustar é recomendada.", "mag_default_type": "Define se novos dispositivos usam o tema moderno ou o tema antigo por padrão.", "stalker_theme": "Tema padrão do Ministra usado pelos dispositivos MAG.", "mag_legacy_redirect": "Redireciona /c para a pasta do Ministra com links simbólicos, permitindo o endereço antigo em dispositivos legados. Exige acesso de administrador do servidor e é aplicado pela rotina do minuto seguinte. Não é recomendado por segurança.", "mag_keep_extension": "Mantém a extensão nas URLs de canais ao vivo, conteúdo com deslocamento de tempo e VOD. Alguns dispositivos antigos dependem dela para escolher como reproduzir.", "mag_disable_ssl": "Força os dispositivos MAG a usarem URLs sem SSL. Considere a compatibilidade dos aparelhos antigos antes de desativar a proteção das conexões.", "mag_load_all_channels": "Carrega todos os canais ao iniciar, em vez de aguardar a seleção de uma categoria. Pode ajudar dispositivos antigos que não seguem os padrões do Ministra.", "disable_mag_token": "Desativa a verificação do token MAG durante a reprodução. Pode melhorar a compatibilidade, mas reduz a segurança.", "test_download_url": "URL do arquivo baixado durante o teste de velocidade dos dispositivos MAG.", "mag_message": "Mensagem exibida em Informações, na aba Minha conta. Aceita HTML; quebras de linha são convertidas em &lt;br/&gt;.", "player_allow_playlist": "Permite que os clientes gerem URLs de listas pelo player web.", "player_allow_bouquet": "Permite que os clientes alterem a ordem das suas listas de canais pelo player web.", "player_hide_incompatible": "Oculta transmissões incompatíveis com a maioria dos navegadores, priorizando formatos como H.264 e AV1. Também oculta canais e filmes indisponíveis.", "player_allow_hevc": "Considera HEVC compatível no player web. O suporte depende do navegador, do sistema e dos codecs disponíveis no dispositivo.", "player_blur": "Intensidade do desfoque das imagens de fundo, em pixels.", "player_opacity": "Opacidade das imagens de fundo. O padrão é 10%.", "extract_subtitles": "Extrai automaticamente as legendas de filmes e episódios durante o processamento, permitindo seu uso no player web.", "save_closed_connection": "Tempo de retenção dos registros de atividade, gravados quando uma conexão ativa é encerrada. Eles ajudam no acompanhamento do serviço, mas podem ocupar bastante espaço com muitas conexões.", "client_logs_save": "Tempo de retenção dos registros de clientes. Manter o histórico ajuda a investigar problemas, mas aumenta o espaço usado no banco.", "save_login_logs": "Tempo de retenção dos registros de login. Manter o histórico ajuda a acompanhar os acessos, mas aumenta o espaço usado no banco.", "stream_logs_save": "Tempo de retenção dos registros de erros das transmissões. Manter o histórico ajuda no diagnóstico, mas aumenta o espaço usado no banco.", "save_restart_logs": "Tempo de retenção dos registros de reinicialização das transmissões. Manter o histórico ajuda no diagnóstico, mas aumenta o espaço usado no banco."});
  translations['Importing Series using this method will parse your M3U or folder and push the individual episodes through Watch Folder. If you have category and bouquet allocation set up in Watch Folder Settings then they will be used here too.']='O painel processa a lista M3U ou a pasta e encaminha os episódios pela rotina de pastas monitoradas. As categorias e listas configuradas nessa rotina também serão usadas.';
  function translateSettingsHelp(root) {
    if (!/\/settings(?:\.php)?$/.test(location.pathname)) return;
    var jq = window.jQuery;
    within(root,'label[for]').forEach(function (label) {
      var key = label.getAttribute('for');
      // O formulário original repete for="api_ips" no campo de senha.
      if (key === 'api_ips' && /^(Senha da API|API Password)$/.test(label.textContent.trim())) key = 'api_password';
      var help = settingsHelpTranslations[key];
      if (!help) return;
      label.querySelectorAll('.tooltip,.tooltip-left,.tooltip-right').forEach(function (icon) {
        icon.naxxSettingsHelp = help;
        ['title', 'data-original-title', 'data-content'].forEach(function (attribute) {
          if (icon.hasAttribute(attribute) && icon.getAttribute(attribute) !== help) icon.setAttribute(attribute, help);
        });
        // jBox retira title e mantém o conteúdo neste cache do jQuery.
        if (jq && jq(icon).data('jBox-getContent') !== help) jq(icon).data('jBox-getContent', help);
      });
    });
    Array.from(window.jBoxes || []).forEach(function (box) {
      if (!box || !box.wrapper || !box.options || box.options.getContent !== 'title' || typeof box.setContent !== 'function') return;
      var source = box.source && box.source[0];
      var help = source && source.naxxSettingsHelp;
      if (!help) {
        var attached = Array.from(box.attachedElements || []);
        var icon = attached.find(function (element) { return element.naxxSettingsHelp; });
        help = icon && icon.naxxSettingsHelp;
      }
      // Só reescreve uma instância criada quando o conteúdo realmente mudou.
      if (help && box.naxxSettingsHelp !== help) {
        box.naxxSettingsHelp = help;
        box.setContent(help);
      }
    });
  }
  function translateStreamHelp(root) {
    if (!/\/stream(?:\.php)?$/.test(location.pathname) || new URLSearchParams(location.search).has('import')) return;
    var jq = window.jQuery;
    within(root,'label[for]').forEach(function (label) {
      var help = streamHelpTranslations[label.getAttribute('for')];
      if (!help) return;
      label.querySelectorAll('.tooltip,.tooltip-left,.tooltip-right').forEach(function (icon) {
        icon.naxxStreamHelp = help;
        ['title','data-original-title','data-content'].forEach(function (attribute) {
          if (icon.hasAttribute(attribute) && icon.getAttribute(attribute) !== help) icon.setAttribute(attribute, help);
        });
        if (jq && jq(icon).data('jBox-getContent') !== help) jq(icon).data('jBox-getContent', help);
      });
    });
    Array.from(window.jBoxes || []).forEach(function (box) {
      if (!box || !box.wrapper || !box.options || box.options.getContent !== 'title' || typeof box.setContent !== 'function') return;
      var source = box.source && box.source[0], help = source && source.naxxStreamHelp;
      if (!help) help = Array.from(box.attachedElements || []).map(function (element) { return element.naxxStreamHelp; }).find(Boolean);
      if (help && box.naxxStreamHelp !== help) { box.naxxStreamHelp = help; box.setContent(help); }
    });
  }
  function setBrandFavicon() {
    var icon = document.querySelector('link[rel~="icon"]');
    if (!icon) { icon = document.createElement('link'); icon.rel = 'icon'; document.head.appendChild(icon); }
    icon.type = 'image/svg+xml';
    var href = 'assets/images/naxx-favicon.svg?v=' + brandAssetVersion;
    if (icon.getAttribute('href') !== href) icon.href = href;
  }
  function versionBrandStylesheets() {
    if (!stylesheetVersion || stylesheetVersion.indexOf('/*') === 0) return;
    document.querySelectorAll('link[rel~="stylesheet"][href]').forEach(function (link) {
      try {
        var asset = new URL(link.href, location.href);
        if (!/\/assets\/css\/app(?:\.dark)?\.css$/.test(asset.pathname)) return;
        if (asset.searchParams.get('naxx') === stylesheetVersion) return;
        asset.searchParams.set('naxx', stylesheetVersion);
        link.href = asset.href;
      } catch (error) {}
    });
  }
  function replaceLegacyLogos(root) {
    within(root,'img[src="assets/images/logo.png"],img[src$="/assets/images/logo.png"]').forEach(function (image) {
      var brand = image.parentElement;
      if (!brand) return;
      brand.classList.add('logo');
      brand.setAttribute('aria-label', 'XUI NAXX');
      image.remove();
    });
  }
  function modernImageURL(value) {
    if(!value)return '';
    try{
      var url=new URL(value,location.href);
      if(url.origin===location.origin&&/\/resize(?:\.php)?$/.test(url.pathname)&&url.searchParams.has('url'))url=new URL(url.searchParams.get('url'),location.href);
      return /^(https?:)$/.test(url.protocol)&&/\.(?:svg|webp|avif)$/i.test(url.pathname)?url.href:'';
    }catch(error){return '';}
  }
  function enhanceModernImages(root) {
    var contentList=/\/(?:streams|movies|series|stream_mass)(?:\.php)?$/.test(location.pathname);
    document.body.classList.toggle('naxx-content-list',contentList);
    document.body.classList.toggle('naxx-streams-page',/\/(?:streams|stream_mass)(?:\.php)?$/.test(location.pathname));
    within(root,'img[src]').forEach(function(image){
      if(contentList&&image.closest('table tbody'))image.classList.add('naxx-content-logo');
      var source=modernImageURL(image.getAttribute('src'));
      if(!source)return;
      if(image.src!==source){image.removeAttribute('srcset');image.src=source;}
      image.decoding='async';
      if(image.closest('table'))image.loading='lazy';
    });
    if(typeof window.openImage==='function'&&!window.openImage.naxxModern){
      var original=window.openImage;
      var openModernImage=function(element){
        var node=typeof element==='string'?document.querySelector(element):element;
        var input=node&&node.parentElement&&node.parentElement.parentElement&&node.parentElement.parentElement.querySelector('input');
        var source=modernImageURL(node&&(node.getAttribute('data-src')||(input&&input.value)));
        var jq=window.jQuery;
        if(source&&jq&&jq.magnificPopup){jq.magnificPopup.open({items:{src:source,type:'image'},mainClass:'naxx-image-popup',image:{titleSrc:function(){return 'Prévia da imagem';}}});return;}
        return original.apply(this,arguments);
      };
      openModernImage.naxxModern=true;window.openImage=openModernImage;
    }
  }
  function removeKnowledgebaseLinks(root) {
    within(root,'a').forEach(function (link) {
      var label = (link.textContent || '').replace(/\s+/g, ' ').trim().toLowerCase();
      var href = (link.getAttribute('href') || '').toLowerCase();
      if (label !== 'xui knowledgebase' && label !== 'documentação xui' && !/knowledgebase|docs\.xui/.test(href)) return;
      var item = link.closest('li');
      if (item && item.querySelectorAll('a').length === 1) item.remove();
      else link.remove();
    });
  }
  function addUpdateMenuLink(){
    var settings=document.querySelector('.dropdown-menu a[href="settings"],.dropdown-menu a[href="settings.php"]');
    var license=Array.from(document.querySelectorAll('.dropdown-menu a')).find(function(link){
      return /(?:^|\/)license(?:\.php)?(?:\?|$)/i.test(link.getAttribute('href')||'')||/^(?:license information|informa[çc][õo]es (?:da |de )?licen[çc]a)$/i.test(link.textContent.trim());
    });
    var existing=document.querySelector('[data-naxx-update-link]');
    if(license){
      if(existing&&existing!==license)existing.remove();
    }else if(existing||!settings)return;
    var link=license||document.createElement('a');
    link.className=link.className||(settings&&settings.className)||'dropdown-item';
    link.href='naxx-update-page.php';link.dataset.naxxUpdateLink='';
    link.removeAttribute('onclick');link.replaceChildren();
    var icon=document.createElement('i');icon.className='mdi mdi-update mr-1';icon.setAttribute('aria-hidden','true');
    link.append(icon,document.createTextNode('Atualização'));
    if(!license)settings.after(link);
  }
  function translateCacheSettings(root) {
    if (!/\/cache(?:\.php)?$/.test(location.pathname)) return;
    within(root,'.container-fluid p,.card p').forEach(function (paragraph) {
      var text = (paragraph.textContent || '').replace(/\s+/g, ' ').trim();
      var match = text.match(/^Your last cron execution was at (.+?)\. If it takes longer to run a cron than the time between executions, you will have issues as the caching will be cut off before completion\.$/);
      if (!match) return;
      var date = document.createElement('strong');
      date.textContent = match[1];
      paragraph.replaceChildren(
        document.createTextNode('A última execução da rotina ocorreu em '),
        date,
        document.createTextNode('. Se a execução demorar mais do que o intervalo entre as execuções, o cache será interrompido antes de terminar.')
      );
    });
  }
  function addEpgSyncButton() {
    if (!/\/epgs?(?:\.php)?$/.test(location.pathname) || document.querySelector('[data-naxx-epg-sync]')) return;
    var addButton = Array.from(document.querySelectorAll('.page-title-box a,.page-title-box button,.page-title-box .btn')).find(function (element) {
      return /^(add epg|adicionar epg)$/i.test((element.textContent || '').replace(/\s+/g, ' ').trim());
    });
    if (!addButton) return;
    var group = addButton.closest('.btn-group') || addButton;
    var refreshButton = document.createElement('button');
    refreshButton.type = 'button';
    refreshButton.className = 'btn btn-outline-primary naxx-epg-refresh-button';
    refreshButton.textContent = '↻ Atualizar fontes';
    refreshButton.title = 'Atualizar as fontes EPG cadastradas';
    var button = document.createElement('button');
    button.type = 'button';
    button.className = 'btn btn-primary naxx-epg-sync-button';
    button.dataset.naxxEpgSync = '1';
    button.textContent = '↔ Sincronizar canais';
    button.title = 'Associar automaticamente os canais às IDs XMLTV correspondentes';
    var refreshStatus = document.createElement('span');
    refreshStatus.className = 'naxx-epg-sync-status naxx-epg-refresh-status';
    refreshStatus.setAttribute('role', 'status');
    refreshStatus.setAttribute('aria-live', 'polite');
    var status = document.createElement('span');
    status.className = 'naxx-epg-sync-status';
    status.setAttribute('role', 'status');
    status.setAttribute('aria-live', 'polite');
    group.parentNode.insertBefore(refreshButton, group.nextSibling);
    group.parentNode.insertBefore(button, refreshButton.nextSibling);
    group.parentNode.insertBefore(refreshStatus, button.nextSibling);
    group.parentNode.insertBefore(status, refreshStatus.nextSibling);
    refreshButton.addEventListener('click', function () {
      var table = document.querySelector('.dataTable,table');
      var jq = window.jQuery;
      var dataTable = table && jq && jq.fn && jq.fn.dataTable && jq.fn.dataTable.isDataTable(table) ? jq(table).DataTable() : null;
      var pageInfo = dataTable && dataTable.page && dataTable.page.info ? dataTable.page.info() : null;
      var firstPage = pageInfo ? pageInfo.page : 0;
      var pageCount = pageInfo ? pageInfo.pages : 1;
      var page = firstPage;
      var sent = 0;
      function actionsOnCurrentPage() {
        var actions = [];
        table.querySelectorAll('tbody tr').forEach(function (row) {
          if (!row.querySelector('td')) return;
          var cells = row.querySelectorAll('td');
          var actionCell = cells[cells.length - 1];
          if (!actionCell) return;
          var controls = Array.from(actionCell.querySelectorAll('a,button'));
          var action = controls.find(function (control) {
            var icon = control.querySelector('i,svg');
            var details = [control.textContent, control.title, control.getAttribute('aria-label'), control.getAttribute('data-original-title'), control.getAttribute('href'), control.getAttribute('onclick'), control.className, icon && icon.getAttribute('class')].join(' ').toLowerCase();
            return /sync|refresh|reload|update|rotate|redo/.test(details);
          });
          if (!action && controls.length === 3) action = controls[1];
          if (action) actions.push(action);
        });
        return actions;
      }
      if (!table) { refreshStatus.textContent = 'A tabela de fontes EPG não foi encontrada.'; return; }
      refreshButton.disabled = true;
      refreshStatus.textContent = 'Preparando atualização das fontes EPG…';
      function finish() {
        function report() {
          refreshStatus.textContent = sent
            ? 'Atualização solicitada para ' + sent + ' fonte(s) EPG.'
            : 'Nenhum botão de atualização foi encontrado nas fontes EPG.';
          refreshButton.disabled = false;
        }
        if (dataTable && page !== firstPage) {
          jq(table).one('draw.dt', report);
          dataTable.page(firstPage).draw('page');
        } else report();
      }
      function processPage() {
        var actions = actionsOnCurrentPage();
        var current = 0;
        function sendNext() {
          if (current >= actions.length) {
            if (dataTable && page + 1 < pageCount) {
              page += 1;
              refreshStatus.textContent = 'Verificando página ' + (page + 1) + ' de ' + pageCount + '…';
              jq(table).one('draw.dt', function () { window.setTimeout(processPage, 50); });
              dataTable.page(page).draw('page');
            } else finish();
            return;
          }
          refreshStatus.textContent = 'Atualizando fontes EPG: ' + (sent + 1) + '…';
          var action = actions[current++];
          try { action.click(); sent += 1; }
          catch (error) { /* Continue a sincronização das demais fontes. */ }
          window.setTimeout(sendNext, 1500);
        }
        sendNext();
      }
      processPage();
    });
    button.addEventListener('click', function () {
      button.disabled = true;
      status.textContent = 'Associando canais aos identificadores XMLTV…';
      fetch('./naxx-epg-sync.php', {
        method: 'POST',
        credentials: 'same-origin',
        headers: {'Content-Type': 'application/json', 'X-Requested-With': 'XMLHttpRequest'},
        body: '{}'
      }).then(function (response) {
        return response.text().then(function (text) {
          var data;
          try { data = JSON.parse(text); } catch (error) { data = null; }
          if (response.redirected && /\/login(?:\.php)?$/.test(new URL(response.url).pathname)) throw new Error('Sua sessão expirou. Entre novamente no painel.');
          if (!response.ok || !data || !data.ok) throw new Error(data && data.message ? data.message : 'Não foi possível sincronizar os canais.');
          return data;
        });
      }).then(function (data) {
        var stats = data.stats || {};
        status.textContent = 'Vinculados: ' + (stats.linked || 0) + '. Mantidos: ' + (stats.preserved || 0) + '. Sem correspondência: ' + (stats.unmatched || 0) + '. Ambíguos: ' + (stats.ambiguous || 0) + '.';
        status.dataset.state = 'success';
      }).catch(function (error) {
        status.textContent = error && error.message ? error.message : 'Falha ao sincronizar os canais.';
        status.dataset.state = 'error';
      }).finally(function () { button.disabled = false; });
    });
  }
  function monitorChannelPlayer(frame) {
    if (!frame || frame.dataset.naxxErrorMonitor) return;
    frame.dataset.naxxErrorMonitor = '1';
    function showPlayerError(message) {
      var card=frame.closest('.naxx-player-card'),overlay=card&&card.querySelector('.naxx-player-error');
      if(!overlay)return;
      overlay.querySelector('[data-naxx-player-error]').textContent=message;
      overlay.hidden=false;
      var state=card.querySelector('.naxx-player-state');if(state)state.textContent='Indisponível';
    }
    var bindTimer=0,bindGeneration=0,controlsObserver=null,controlsFrame=0,controlsDocument=null,escapeHandler=null,bindings=[];
    frame.__naxxStopMonitor=function(){
      bindGeneration+=1;window.clearTimeout(bindTimer);bindTimer=0;
      if(controlsObserver)controlsObserver.disconnect();controlsObserver=null;
      if(controlsFrame)cancelAnimationFrame(controlsFrame);controlsFrame=0;
      if(controlsDocument&&escapeHandler)controlsDocument.removeEventListener('keydown',escapeHandler,true);
      controlsDocument=null;escapeHandler=null;
      bindings.forEach(function(binding){if(typeof binding[0].off==='function')binding[0].off(binding[1],binding[2]);});bindings=[];
    };
    var bindEvents = function () {
      frame.__naxxStopMonitor();
      var generation=bindGeneration;
      var attempts = 0;
      frame.__naxxRepairAttempted=false;
      var bind = function () {
        bindTimer=0;
        if(generation!==bindGeneration||!frame.isConnected||attempts++>=40)return;
        try {
          var playerWindow = frame.contentWindow;
          var jwplayer = playerWindow && playerWindow.jwplayer;
          if(playerWindow&&playerWindow.document.querySelector('#login_button')){showPlayerError('Sua sessão expirou. Entre novamente no painel para reproduzir o canal.');return;}
          if (typeof jwplayer === 'function') {
            var instance = jwplayer();
            var config=instance&&typeof instance.getConfig==='function'&&instance.getConfig();
            if (instance && typeof instance.on === 'function' && config && config.playlist && config.playlist.length) {
              frame.__naxxPlayerInstance = instance;
              var card=frame.closest('.naxx-player-card'),overlay=card&&card.querySelector('.naxx-player-error');
              var state=card&&card.querySelector('.naxx-player-state');
              var originRepairVersion=0,originRepairInProgress=false;
              function playerState(){try{return instance.getState&&instance.getState();}catch(error){return '';}}
              function repairOrigin(){
                if(frame.__naxxRepairAttempted||generation!==bindGeneration||!frame.isConnected)return Promise.resolve(false);
                try{
                  var currentState=playerState();
                  if(currentState==='playing'||currentState==='paused')return Promise.resolve(false);
                  var item=instance.getPlaylistItem&&instance.getPlaylistItem();
                  var source=item&&item.sources&&item.sources[0]&&item.sources[0].file;
                  if(!source)source=config.playlist[0].sources&&config.playlist[0].sources[0]&&config.playlist[0].sources[0].file;
                  if(typeof source!=='string'||!source)return Promise.resolve(false);
                  var original=new URL(source,frame.src),target=new URL(original.href),origin=new URL(frame.src);
                  // Só recupera a rota autenticada de prévia do próprio painel.
                  if(!/^\/admin\/live(?:\.php)?$/.test(original.pathname)||!original.searchParams.has('uitoken')||original.origin===origin.origin)return Promise.resolve(false);
                  target.protocol=origin.protocol;target.host=origin.host;
                  frame.__naxxRepairAttempted=true;originRepairVersion+=1;originRepairInProgress=true;
                  if(state)state.textContent='Conectando…';
                  if(overlay)overlay.hidden=true;
                  // O JWPlayer busca o manifesto; uma consulta prévia duplicava essa espera.
                  instance.load([{file:target.href,type:'hls'}]);instance.play();
                  return Promise.resolve(true);
                }catch(error){return Promise.resolve(false);}
                finally{originRepairInProgress=false;}
              }
              function reportError(error){
                if(originRepairInProgress)return;
                var repairVersion=originRepairVersion;
                repairOrigin().then(function(repaired){
                  if(generation!==bindGeneration||!frame.isConnected||repaired||repairVersion!==originRepairVersion)return;
                  var currentState=playerState();
                  // Um erro da tentativa anterior pode chegar depois da troca de origem.
                  if(currentState==='playing'||currentState==='paused'||(frame.__naxxRepairAttempted&&currentState&&currentState!=='error'))return;
                  showPlayerError(Number(error&&error.code)===232404?'O canal não respondeu. Verifique a fonte ou tente novamente.':'Não foi possível reproduzir este canal. Confira a conexão e tente novamente.');
                });
              }
              function on(name,handler){instance.on(name,handler);bindings.push([instance,name,handler]);}
              on('error',reportError);
              on('setupError',reportError);
              on('play',function(){if(overlay)overlay.hidden=true;if(state)state.textContent='Reproduzindo';});
              on('buffer',function(){if(state)state.textContent='Carregando…';});
              on('pause',function(){if(state)state.textContent='Pausado';});
              on('autostartNotAllowed',function(){if(state)state.textContent='Toque para reproduzir';});
              var playerDocument=playerWindow.document;
              playerDocument.documentElement.lang='pt-BR';
              if(!playerDocument.getElementById('naxx-player-style')){
                var style=playerDocument.createElement('style');style.id='naxx-player-style';style.textContent='html,body{margin:0!important;background:#05080d!important}body .jwplayer{font-family:system-ui,sans-serif}body .jw-progress,body .jw-knob{background:#4b8df7}body .jw-button-color:hover{color:#79b8ff}body .jw-controlbar{background:linear-gradient(transparent,#070e1deb)}';playerDocument.head.appendChild(style);
              }
              var labels={'Play':'Reproduzir','Pause':'Pausar','Mute':'Silenciar','Unmute':'Ativar som','Fullscreen':'Tela cheia','Exit Fullscreen':'Sair da tela cheia','Settings':'Configurações','Volume':'Volume','Live':'Ao vivo','Playback rate':'Velocidade','Playback Rate':'Velocidade','Quality':'Qualidade','Closed Captions':'Legendas','Audio Tracks':'Faixas de áudio','Off':'Desativado','Stop':'Parar'};
              function translateControls(){controlsFrame=0;if(generation!==bindGeneration)return;playerDocument.querySelectorAll('.jw-text,.jw-text-live,[aria-label],[title]').forEach(function(element){['aria-label','title'].forEach(function(attribute){var value=element.getAttribute(attribute);if(labels[value])element.setAttribute(attribute,labels[value]);});if((element.classList.contains('jw-text')||element.classList.contains('jw-text-live'))&&labels[element.textContent.trim()])element.textContent=labels[element.textContent.trim()];});}
              translateControls();on('ready',translateControls);on('play',translateControls);
              controlsObserver=new MutationObserver(function(changes){if(controlsFrame)return;var changed=changes.some(function(change){if(change.type==='attributes')return !!labels[change.target.getAttribute(change.attributeName)];if(change.type==='characterData')return !!labels[change.target.nodeValue.trim()];return Array.from(change.addedNodes).some(function(node){return node.nodeType===1&&node.namespaceURI==='http://www.w3.org/1999/xhtml'||node.nodeType===3&&labels[node.nodeValue.trim()];});});if(changed)controlsFrame=requestAnimationFrame(translateControls);});
              controlsObserver.observe(playerDocument.body,{childList:true,subtree:true,characterData:true,attributes:true,attributeFilter:['aria-label','title']});
              controlsDocument=playerDocument;escapeHandler=function(event){if(event.key==='Escape'&&!playerDocument.fullscreenElement&&!playerDocument.webkitFullscreenElement&&frame.isConnected){event.preventDefault();event.stopImmediatePropagation();window.jQuery.magnificPopup.close();}};playerDocument.addEventListener('keydown',escapeHandler,true);
              repairOrigin();
              var currentState=playerState();if(currentState==='error')reportError({code:232404});else if(state)state.textContent={playing:'Reproduzindo',paused:'Pausado',buffering:'Carregando…',idle:'Toque para reproduzir',complete:'Reprodução encerrada'}[currentState]||'Conectando…';
              return;
            }
          }
        } catch (error) { return; }
        bindTimer=window.setTimeout(bind, 250);
      };
      bindTimer=window.setTimeout(bind, 0);
    };
    frame.addEventListener('load', bindEvents);
    bindEvents();
  }
  function enhanceChannelPlayer() {
    if (!/\/streams(?:\.php)?$/.test(location.pathname) || typeof window.player !== 'function' || window.player.naxxEnhanced) return;
    var openPlayer = function (streamId) {
      var source = new URL('./player?type=live&id=' + encodeURIComponent(streamId), location.href).href;
      var jq = window.jQuery;
      if (!jq || !jq.magnificPopup) { window.location.assign(source); return; }
      jq.magnificPopup.open({
        items: {src: source, type: 'iframe'},
        mainClass: 'naxx-player-popup',
        closeOnBgClick: true,
        fixedContentPos: true,
        iframe: {
          markup: '<div class="naxx-player-card"><div class="naxx-player-bar"><span class="naxx-player-brand"><span class="naxx-player-mark"></span>NAXX</span><span class="naxx-player-live">AO VIVO</span><span class="naxx-player-state" role="status" aria-live="polite">Conectando…</span><span class="naxx-player-label">Prévia do canal</span><button title="Fechar player" aria-label="Fechar player" type="button" class="mfp-close">×</button></div><div class="mfp-iframe-scaler"><iframe class="mfp-iframe" frameborder="0" allow="autoplay; fullscreen; picture-in-picture; encrypted-media" allowfullscreen></iframe></div><div class="naxx-player-error" role="alert" aria-live="assertive" hidden><div class="naxx-player-error-card"><span class="naxx-player-error-symbol">!</span><h2>Transmissão indisponível</h2><p data-naxx-player-error>Não foi possível carregar o canal.</p><button class="naxx-player-retry" data-naxx-player-retry type="button">Tentar novamente</button></div></div></div>',
          srcAction: 'iframe_src'
        },
        callbacks: {
          open: function () {
            var frame = this.content && this.content.find('iframe.mfp-iframe')[0];
            if (!frame) return;
            frame.title='Player do canal ao vivo';
            monitorChannelPlayer(frame);
            var retry = this.content.find('[data-naxx-player-retry]')[0];
            if (retry && !retry.dataset.naxxBound) {
              retry.dataset.naxxBound = '1';
              retry.addEventListener('click', function () {
                var overlay = frame.closest('.naxx-player-card').querySelector('.naxx-player-error');
                if (overlay) overlay.hidden = true;
                try { frame.contentWindow.location.reload(); }
                catch (error) { frame.src = frame.src; }
              });
            }
          },
          beforeClose:function(){var frame=this.content&&this.content.find('iframe.mfp-iframe')[0];if(frame&&frame.__naxxStopMonitor)frame.__naxxStopMonitor();if(frame&&frame.__naxxPlayerInstance){try{frame.__naxxPlayerInstance.stop();}catch(error){}}}
        }
      });
    };
    openPlayer.naxxEnhanced = true;
    window.player = openPlayer;
  }
  function organizeMenu(){
    var nav=document.querySelector('.navigation-menu');if(!nav||nav.dataset.naxxOrganized||document.querySelector('[data-nav]'))return;
    nav.dataset.naxxOrganized='1';
    // Remove apenas os atalhos duplicados. Os formulários continuam no importador unificado.
    nav.querySelectorAll('a[href]').forEach(function(a){var route=a.getAttribute('href').replace(/^\.\//,'');if(/^(stream|movie|serie)\?import|^review\?type=/.test(route))a.closest('li').remove();});
    function setMenuLabel(anchor,label){if(!anchor)return;var changed=false;Array.from(anchor.childNodes).forEach(function(node){if(node.nodeType===3&&node.textContent.trim()){node.textContent=' '+label+' ';changed=true;}});if(!changed)anchor.prepend(document.createTextNode(label+' '));}
    function topItem(link){var item=link&&link.closest('li');while(item&&item.parentElement!==nav)item=item.parentElement;return item;}
    var team=topItem(nav.querySelector('a[href="users"]'));
    if(team){var teamLink=team.querySelector(':scope > a');setMenuLabel(teamLink,'Equipe');teamLink.title='Administradores e revendedores';}
    var clients=topItem(nav.querySelector('a[href="lines"]'));
    if(clients){
      var clientLink=clients.querySelector(':scope > a');setMenuLabel(clientLink,'Clientes');clientLink.title='Contas de acesso e dispositivos';
      clients.classList.add('naxx-clients-nav');
      var clientMenu=clients.querySelector(':scope > ul');
      if(clientMenu)Array.from(clientMenu.children).forEach(function(item){
        var link=item.querySelector(':scope > a'),list=item.querySelector(':scope > ul');
        if(!link||!list)return;
        var heading=document.createElement('span');heading.className='naxx-menu-heading';heading.textContent=list.querySelector('a[href="lines"]')?'Contas de acesso':link.textContent.replace(/\s+/g,' ').trim();
        link.replaceWith(heading);item.classList.remove('has-submenu');item.classList.add('naxx-client-group');list.className='naxx-client-links';
      });
    }
    var management=nav.querySelector('a[href="quick_tools"],a[href="codes"],a[href="stream_categories"],a[href="user_mass"]');
    if(management){var group=management.closest('ul').closest('ul.submenu').parentElement;while(group.parentElement!==nav&&group.parentElement)group=group.parentElement;var anchor=group.querySelector(':scope > a');if(anchor){group.classList.add('naxx-advanced-nav');Array.from(anchor.childNodes).forEach(function(n){if(n.nodeType===3&&n.textContent.trim())n.textContent=' Avançado ';});}}
    var advanced=nav.querySelector(':scope > li.naxx-advanced-nav');
    var advancedMenu=advanced&&advanced.querySelector(':scope > ul.submenu');
    if(advancedMenu&&!advancedMenu.dataset.naxxGrouped){
      var labels={'service setup':'Serviços e configuração','configuração dos serviços':'Serviços e configuração','access control':'Acesso e segurança','controle de acesso':'Acesso e segurança','ferramentas':'Ferramentas','editar em lote':'Edição em lote','registros':'Registros e monitoramento'};
      var sections=[];
      Array.from(advancedMenu.children).forEach(function(source){
        var sourceLink=source.querySelector(':scope > a');
        var sourceName=(sourceLink&&sourceLink.textContent||'').replace(/\s+/g,' ').trim().toLowerCase();
        var sectionName=labels[sourceName]||(/tickets|chamados/.test(sourceName)?'Suporte':'Outras opções');
        var links=source.querySelectorAll(':scope > ul a[href]');
        if(!links.length&&sourceLink&&sourceLink.getAttribute('href')!=='#')links=[sourceLink];
        var items=[];
        Array.from(links).forEach(function(link){
          var href=(link.getAttribute('href')||'').trim();
          var item=link.closest('li');
          if(!href||href==='#'||!item)return;
          items.push(item);
        });
        if(items.length)sections.push({name:sectionName,items:items});
      });
      if(sections.length){
        advancedMenu.replaceChildren();
        advancedMenu.classList.add('naxx-advanced-panel');
        advancedMenu.dataset.naxxGrouped='1';
        var searchRow=document.createElement('li');searchRow.className='naxx-advanced-search-row';
        var search=document.createElement('input');search.type='search';search.className='naxx-advanced-search';search.placeholder='Buscar ferramenta…';search.setAttribute('aria-label','Buscar em ferramentas avançadas');search.autocomplete='off';searchRow.appendChild(search);advancedMenu.appendChild(searchRow);
        sections.forEach(function(section){
          var groupItem=document.createElement('li');groupItem.className='naxx-advanced-group';
          var heading=document.createElement('h6');heading.textContent=section.name;groupItem.appendChild(heading);
          var list=document.createElement('ul');list.className='naxx-advanced-links';
          section.items.forEach(function(item){list.appendChild(item);});groupItem.appendChild(list);advancedMenu.appendChild(groupItem);
        });
        function normalizeSearch(value){return String(value||'').toLocaleLowerCase('pt-BR').normalize('NFD').replace(/[\u0300-\u036f]/g,'').trim();}
        var empty=document.createElement('li');empty.className='naxx-advanced-empty';empty.textContent='Nenhuma ferramenta encontrada.';empty.hidden=true;advancedMenu.appendChild(empty);
        search.addEventListener('input',function(){
          var query=normalizeSearch(search.value);
          var visibleSections=0;
          advancedMenu.querySelectorAll('.naxx-advanced-group').forEach(function(section){
            var heading=normalizeSearch(section.querySelector('h6').textContent);var visible=0;
            section.querySelectorAll('.naxx-advanced-links > li').forEach(function(item){var link=item.querySelector('a');var matches=!query||heading.indexOf(query)!==-1||normalizeSearch(link&&(link.textContent+' '+link.getAttribute('href'))).indexOf(query)!==-1;item.hidden=!matches;if(matches)visible+=1;});
            section.hidden=visible===0;if(!section.hidden)visibleSections+=1;
          });
          empty.hidden=!query||visibleSections>0;
        });
        search.addEventListener('keydown',function(event){if(event.key==='Escape'){search.value='';search.dispatchEvent(new Event('input'));search.blur();}});
        function positionAdvancedPanel(){
          if(window.innerWidth<992){advancedMenu.style.left='';advancedMenu.style.width='';return;}
          var rect=advanced.getBoundingClientRect();var width=Math.min(900,window.innerWidth-24);var left=Math.max(12,Math.min(rect.left,window.innerWidth-width-12));
          advancedMenu.style.left=(left-rect.left)+'px';advancedMenu.style.width=width+'px';
        }
        advanced.addEventListener('mouseenter',positionAdvancedPanel);
        advanced.addEventListener('focusin',positionAdvancedPanel);
        window.addEventListener('resize',positionAdvancedPanel,{passive:true});
        positionAdvancedPanel();
      }
    }
    var bouquet=nav.querySelector('a[href="bouquets"]'),content=nav.querySelector('a[href="streams"],a[href="movies"],a[href="series"]'),menu=null;
    if(content){var contentTop=content.closest('li');while(contentTop.parentElement!==nav)contentTop=contentTop.parentElement;menu=contentTop.querySelector(':scope > ul');}
    if(bouquet&&menu){var bouquetItem=bouquet.closest('ul').parentElement;if(bouquetItem.parentElement===nav)menu.appendChild(bouquetItem);}
    if(menu){var item=document.createElement('li'),link=document.createElement('a');link.href='naxx-importador.php';link.textContent='Importador';link.dataset.naxxImportLink='';item.appendChild(link);menu.appendChild(item);}
    nav.querySelectorAll(':scope > li').forEach(function(li){li.classList.remove('last-elements');});Array.from(nav.children).slice(-2).forEach(function(li){li.classList.add('last-elements');});
  }
  function enhance(root) {
    root=root||document;
    if(window.NaxxPanelTranslations)window.NaxxPanelTranslations.enhance(root);
    if(window.NaxxPerformance&&typeof window.NaxxPerformance.enhance==='function')window.NaxxPerformance.enhance();
    var full=root===document;
    if(full||containsFeature(root,'#hue'))enhanceTopbarTheme();
    var navigation=containsFeature(root,'.navigation-menu,.topnav-menu,.dropdown-menu');
    var pageTools=containsFeature(root,'.page-title-box,table');
    var dashboard=containsFeature(root,'.card-body.active-connections,.card-body.online-users,.card-body.active-streams,.card-body.offline-streams,.card-body.input-flow,.card-body.output-flow,[id^="s_"][id$="_conns"]');
    removeKnowledgebaseLinks(root);
    if(navigation){addUpdateMenuLink();organizeMenu();}
    replaceLegacyLogos(root);
    enhanceModernImages(root);
    if(window.NaxxMenus&&(navigation||pageTools))window.NaxxMenus.enhance();
    if(window.NaxxStreamPageSize&&(full||containsFeature(root,'#stream_show_entries,#show_entries,#datatable-streampage,#datatable-mass,select[name="datatable-streampage_length"],select[name="datatable-mass_length"]')))window.NaxxStreamPageSize.enhance();
    if(window.NaxxStreamSources&&(full||pageTools||containsFeature(root,'#collapse_filters,#stream-selection')))window.NaxxStreamSources.enhance();
    if(window.NaxxStreamMass&&(full||pageTools||containsFeature(root,'#stream-selection,#datatable-mass')))window.NaxxStreamMass.enhance();
    if(window.NaxxPublicPage&&(full||pageTools||containsFeature(root,'#logs,#naxx-public-page,.form-wizard-header')))window.NaxxPublicPage.enhance();
    if(window.NaxxBouquetSelection&&(full||pageTools||containsFeature(root,'#bouquet_form')))window.NaxxBouquetSelection.enhance();
    if(window.NaxxBouquetOrder&&(full||pageTools||containsFeature(root,'#stream_order_array')))window.NaxxBouquetOrder.enhance();
    if(window.NaxxDashboard&&dashboard)window.NaxxDashboard.enhance();
    if(full||containsFeature(root,'.page-title-box'))addEpgSyncButton();
    if(containsFeature(root,'#login_button')&&document.getElementById('login_button')){
      document.body.classList.add('naxx-login');
      if(!document.querySelector('.naxx-login-version')){var note=document.createElement('p');note.className='naxx-login-version text-muted text-center';note.textContent='© 2026 XUI NAXX · v1.15';document.querySelector('#login_button').after(note);}
    }
    within(root,translationSelector).forEach(translate);
    within(root,'[placeholder],[title],[data-original-title],[data-content],[aria-label]').forEach(function(element){translatedAttributes.forEach(function(attribute){var value=element.getAttribute(attribute),translated=value&&attributeTranslation(element,attribute,value);if(translated&&translated!==value)element.setAttribute(attribute,translated);});});
    translateSettingsHelp(root);
    translateStreamHelp(root);
    translateCacheSettings(root);
    if(window.NaxxCache&&(full||containsFeature(root,'.page-title-box,#datatable-cache,#minute,.jBox-container,.jq-toast-wrap')||(root.nodeType===1&&root.closest('.jBox-container,.jq-toast-wrap'))))window.NaxxCache.enhance();
    if(window.NaxxAccessibility)window.NaxxAccessibility.enhance(root);
    if(full){versionBrandStylesheets();setBrandFavicon();}
    enhanceChannelPlayer();
    var pageTitle=document.title;
    if(/\/settings(?:\.php)?$/.test(location.pathname))pageTitle=pageTitle.replace(/\|\s*Settings$/,'| Configurações gerais');
    if(/\/stream(?:\.php)?$/.test(location.pathname) && !new URLSearchParams(location.search).has('import'))pageTitle=pageTitle.replace(/\|\s*Stream$/,'| Adicionar canal');
    within(root,'input[placeholder],input[type="submit"],input[type="button"]').forEach(translateInput);
    within(root,'.copyright').forEach(function(footer){if(footer.dataset.naxxVersion)return;footer.dataset.naxxVersion='1';footer.textContent='© 2026 XUI NAXX · v1.15';});
    pageTitle=pageTitle.replace(/^XUI(?:\.one)?\s*\|/, 'XUI NAXX |');
    var titleParts=pageTitle.split('|');if(titleParts.length===2){var titleLabel=titleParts[1].trim(),titleTranslation=translations[titleLabel]||interfaceTranslations[titleLabel];if(titleTranslation)pageTitle=titleParts[0].trim()+' | '+titleTranslation;}
    if(document.title!==pageTitle)document.title=pageTitle;
    if(location.search.includes('naxx_embed=1'))document.body.classList.add('naxx-embedded');
    within(root,'.logo').forEach(function (logo) {
      if(logo.getAttribute('aria-label')!=='XUI NAXX — página inicial')logo.setAttribute('aria-label', 'XUI NAXX — página inicial');
    });
    within(root,'table.table').forEach(function (table) {
      // DataTables com scroll próprio conserva seus contêineres e alinhamento.
      if (table.closest('.table-responsive, .xui-table-scroll, .dataTables_scroll')) return;
      var wrapper = document.createElement('div');
      wrapper.className = 'xui-table-scroll';
      wrapper.tabIndex = 0;
      wrapper.setAttribute('role', 'region');
      wrapper.setAttribute('aria-label', 'Tabela com rolagem horizontal');
      table.parentNode.insertBefore(wrapper, table);
      wrapper.appendChild(table);
    });
    within(root,'.navbar-toggle').forEach(function (toggle) {
      toggle.setAttribute('aria-label', 'Abrir ou fechar menu');
      toggle.setAttribute('aria-controls', 'navigation');
      toggle.setAttribute('aria-expanded', String(toggle.classList.contains('open')));
    });
  }
  function ready() {
    enhance();
    document.documentElement.classList.add('naxx-ready');
    var pendingRoots=new Set(),frame=0,hiddenDirty=false;
    function enqueue(root){
      if(!root||root.nodeType!==1||root.namespaceURI!=='http://www.w3.org/1999/xhtml'||!root.isConnected)return;
      pendingRoots.add(root);
      if(!frame&&!document.hidden)frame=window.requestAnimationFrame(flush);
    }
    function flush(){
      frame=0;
      if(document.hidden)return;
      var roots=Array.from(pendingRoots).filter(function(root){return root.isConnected;});pendingRoots.clear();
      // O DataTables adiciona muitas linhas de uma vez. Cada trecho só passa
      // pelas melhorias uma vez, sem voltar a procurar no documento inteiro.
      var rootSet=new Set(roots);
      roots.filter(function(root){var parent=root.parentElement;while(parent){if(rootSet.has(parent))return false;parent=parent.parentElement;}return true;}).forEach(enhance);
    }
    function textChanged(node){
      var parent=node.parentElement;if(!parent)return;
      var key=(node.nodeValue||'').trim();
      var message=parent.closest('.jBox-Confirm,.jq-toast-single');
      if(message){enqueue(message);return;}
      if((labelTranslation(parent,key)||/^\d+ (?:Hours?|Days?)$/.test(key))&&parent.matches(translationSelector)){enqueue(parent);return;}
      // Os textos extensos e avisos do cache têm tradução própria no módulo.
      if(/\/cache(?:\.php)?$/.test(location.pathname)&&parent.closest('.jBox-container,.jq-toast-wrap'))enqueue(parent);
      else if(/^Your last cron execution was at /.test(key))enqueue(parent);
    }
    var bodyObserver=new MutationObserver(function(mutations){
      if(document.hidden){hiddenDirty=true;return;}
      mutations.forEach(function(mutation){
        if(mutation.type==='characterData'){textChanged(mutation.target);return;}
        if(mutation.type==='attributes'){
          if(mutation.attributeName==='src'){if(mutation.target.matches('img'))enqueue(mutation.target);}
          else {var attributeValue=mutation.target.getAttribute(mutation.attributeName),attributeLabel=attributeValue&&attributeTranslation(mutation.target,mutation.attributeName,attributeValue);if(attributeLabel&&attributeLabel!==attributeValue)enqueue(mutation.target);}
          return;
        }
        var elements=[];
        Array.from(mutation.addedNodes).forEach(function(node){
          if(node.nodeType===3)textChanged(node);
          else if(node.nodeType===1&&node.namespaceURI==='http://www.w3.org/1999/xhtml')elements.push(node);
        });
        if(elements.length>8)enqueue(mutation.target);else elements.forEach(enqueue);
      });
    });
    bodyObserver.observe(document.body,{childList:true,subtree:true,characterData:true,attributes:true,attributeFilter:['src','placeholder','title','data-original-title','data-content','aria-label']});
    document.addEventListener('visibilitychange',function(){
      if(document.hidden){if(frame)window.cancelAnimationFrame(frame);frame=0;}
      else{if(hiddenDirty){hiddenDirty=false;pendingRoots.clear();enqueue(document.body);}else if(pendingRoots.size&&!frame)frame=window.requestAnimationFrame(flush);}
    });
    document.addEventListener('click', function (event) {
      var importer=event.target.closest('[data-naxx-import-link],[data-naxx-update-link]');
      if(importer&&!event.ctrlKey&&!event.metaKey){event.preventDefault();event.stopImmediatePropagation();window.location.assign(importer.href);return;}
      var toggle = event.target.closest('.navbar-toggle');
      if (toggle) window.setTimeout(function () {
        toggle.setAttribute('aria-expanded', String(toggle.classList.contains('open')));
      }, 0);
    },true);
  }
  // Aguardar inicialização das tabelas e dos plugins da versão original.
  if (document.readyState !== 'loading') ready();
  else document.addEventListener('DOMContentLoaded', ready, {once:true});
}());

/* Reduz consultas automáticas, sem interferir em reprodução, importações ou ações. */
(function(){
 'use strict';
 if(window.NaxxPerformance)return;
 var later=window.setTimeout.bind(window),cancel=window.clearTimeout.bind(window),pending=new Map(),handles=new Map(),statsMarker={};
 var policy={headerStats:10000,getStats:3000,getGraphStats:60000,refreshInformation:10000};
 function key(callback){
  if(typeof callback!=='function')return null;
  var name=callback.name;
  return Object.prototype.hasOwnProperty.call(policy,name)&&window[name]===callback?name:null;
 }
 function current(item){return item.name==='headerStats'||item.page===window.rCurrentPage;}
 function remove(item){
  if(item.timer!==null)cancel(item.timer);
  if(pending.get(item.name)===item)pending.delete(item.name);
  handles.delete(item.handle);
 }
 function schedule(name,callback,args,delay){
  var previous=pending.get(name);if(previous)remove(previous);
  var item={name:name,callback:callback,args:args,page:window.rCurrentPage,timer:null,handle:null,waiting:false};
  pending.set(name,item);
  item.timer=later(function(){run(item);},delay);
  // O handle que o código nativo recebeu continua válido durante a pausa e
  // após reagendar o timer físico, inclusive para killTimeouts().
  item.handle=item.timer;handles.set(item.handle,item);
  return item.handle;
 }
 function run(item){
  if(pending.get(item.name)!==item)return;
  item.timer=null;
  if(!current(item)){remove(item);return;}
  if(document.hidden){item.waiting=true;return;}
  remove(item);item.callback.apply(window,item.args);
 }
 window.setTimeout=function(callback,delay){
  var name=key(callback),args=Array.prototype.slice.call(arguments,2);
  if(!name)return later.apply(window,arguments);
  return schedule(name,callback,args,Math.max(Number(delay)||0,policy[name]));
 };
 window.clearTimeout=function(id){
  var item=handles.get(id);if(item)remove(item);
  return cancel(id);
 };
 function enhance(){
  var native=window.getStats;
  if(typeof native!=='function'||native.naxxPerformance===statsMarker)return;
  var page=window.rCurrentPage,lastStarted=-Infinity;
  function getStats(){
   var args=Array.prototype.slice.call(arguments);
   // auto=false é a consulta manual nativa: mantém argumentos e retorno.
   if(args[0]===false)return native.apply(this,args);
   if(page!==window.rCurrentPage)return;
   var wait=Math.max(0,policy.getStats-(Date.now()-lastStarted));
   // A resposta lenta nativa chama getStats() diretamente, fora dos timers.
   // Essa entrada também respeita a pausa e o intervalo mínimo.
   if(document.hidden||wait>0){schedule('getStats',getStats,args,wait);return;}
   lastStarted=Date.now();return native.apply(this,args);
  }
  getStats.naxxPerformance=statsMarker;
  window.getStats=getStats;
  var item=pending.get('getStats');
  if(item){if(item.callback===native)item.callback=getStats;else remove(item);}
 }
 document.addEventListener('visibilitychange',function(){
  if(document.hidden)return;
  pending.forEach(function(item){
   if(!current(item)){remove(item);return;}
   if(item.timer!==null)cancel(item.timer);
   item.waiting=false;item.timer=later(function(){run(item);},0);
  });
 });
 window.NaxxPerformance={pollingIntervals:Object.freeze(Object.assign({},policy)),enhance:enhance};
 enhance();
}());

/* Nomes dos controles e navegação por teclado sobre os componentes originais. */
(function(){
 'use strict';var bound=false;
 function find(root,selector){var list=Array.from(root.querySelectorAll(selector));if(root.nodeType===1&&root.matches(selector))list.unshift(root);return list;}
 function label(element,text){if(text&&!element.getAttribute('aria-label')&&!element.getAttribute('aria-labelledby'))element.setAttribute('aria-label',text);}
 function actionName(element){
  var action=element.getAttribute('onclick')||'',icon=element.querySelector('i'),classes=icon?icon.className:'',epg=/\/epgs(?:\.php)?$/.test(location.pathname);
  if(element.matches('.search-toggle'))return 'Pesquisar no painel';
  if(element.matches('.nav-user'))return 'Menu da conta';
  if(element.id==='scrollToTop')return 'Ir para o início da página';
  if(element.id==='scrollToBottom')return 'Ir para o fim da página';
  if(/clearFilters\(/.test(action))return 'Limpar filtros';
  if(/refreshTable\(/.test(action))return 'Atualizar lista';
  if(/showFailures\(/.test(action))return 'Ver estado e falhas do canal';
  if(/player\(/.test(action))return 'Reproduzir prévia do canal';
  if(element.matches('[data-toggle="dropdown"]'))return element.closest('table')?'Ações do item':'Mais opções desta página';
  if(element.matches('.page-link')){
   var item=element.parentElement;
   if(item.classList.contains('previous')||/chevron-left/.test(classes))return 'Página anterior';
   if(item.classList.contains('next')||/chevron-right/.test(classes))return 'Próxima página';
  }
  if(/['"]reload['"]/.test(action)||/mdi-refresh/.test(classes))return epg?'Atualizar guia de programação':'Atualizar item';
  if(/['"]delete['"]/.test(action)||/mdi-close|mdi-delete/.test(classes))return epg?'Excluir guia de programação':'Excluir item';
  if(/pencil/.test(classes))return epg?'Editar guia de programação':'Editar item';
  if(/fa-square/.test(classes)&&!action)return 'Estado da transmissão';
  return element.getAttribute('data-original-title')||'';
 }
 function enhance(root){
  root=root||document;
  var main=document.querySelector('.wrapper');
  if(main){
   main.setAttribute('role','main');if(!main.id)main.id='naxx-main-content';main.tabIndex=-1;
   if(!document.querySelector('.naxx-skip-link')){var skip=document.createElement('a');skip.className='naxx-skip-link';skip.href='#'+main.id;skip.textContent='Ir para o conteúdo';document.body.prepend(skip);}
  }
  var nav=document.getElementById('navigation');if(nav){nav.setAttribute('role','navigation');label(nav,'Navegação principal');}
  find(root,'button,a[href],[role="button"]').forEach(function(element){
   if(element.matches('[data-toggle="tab"],.nav-user'))label(element,element.textContent.trim()||actionName(element));
   else if(!element.textContent.trim())label(element,actionName(element));
   if(element.id==='scrollToTop'||element.id==='scrollToBottom'){
    label(element,actionName(element));element.setAttribute('role','button');
    var button=element.querySelector(':scope > button');if(button){var span=document.createElement('span');span.className=button.className;span.setAttribute('aria-hidden','true');while(button.firstChild)span.appendChild(button.firstChild);button.replaceWith(span);}
   }
   if(element.tagName==='A'){
    var child=element.querySelector(':scope > button');if(child&&!child.getAttribute('onclick')){label(element,actionName(child)||child.textContent.trim());if(element.getAttribute('aria-label')){child.tabIndex=-1;child.setAttribute('aria-hidden','true');}}
   }
  });
  find(root,'input[data-switchery="true"],.switchery').forEach(function(node){
   var input=node.tagName==='INPUT'?node:node.previousElementSibling,visual=input&&input.nextElementSibling;
   if(!input||input.type!=='checkbox'||!visual||!visual.classList.contains('switchery'))return;
   input.classList.add('naxx-switch-input');input.parentElement.classList.add('naxx-switch-field');visual.setAttribute('aria-hidden','true');
   if(!input.labels||!input.labels.length){var column=input.parentElement.previousElementSibling;if(column)label(input,column.textContent.replace(/\s+/g,' ').trim());}
  });
  [['minute','Minuto da rotina'],['hour','Hora da rotina'],['cache_thread_count','Quantidade de threads da rotina']].forEach(function(pair){var control=document.getElementById(pair[0]);if(control)label(control,pair[1]);});
  if(!bound){bound=true;document.addEventListener('click',function(event){var skip=event.target.closest('.naxx-skip-link');if(skip){var target=document.querySelector('.wrapper');if(target){event.preventDefault();target.focus();}}});document.addEventListener('keydown',function(event){if(event.key===' '&&event.target.matches('#scrollToTop,#scrollToBottom')){event.preventDefault();event.target.click();}});}
 }
 window.NaxxAccessibility={enhance:enhance};
 if(document.readyState!=='loading')enhance();
}());

/* Menus nativos: mantém os links e as ações; abre fora da área rolável da tabela. */
(function(){
 'use strict';
 var active=null,bound=false,frame=0;
 function place(){
  frame=0;if(!active)return;
  var menu=active.menu,toggle=active.toggle;
  if(!toggle.isConnected||!active.parent.isConnected){restore();return;}
  var r=toggle.getBoundingClientRect(),vw=document.documentElement.clientWidth,vh=innerHeight;
  if(r.bottom<0||r.top>vh||r.right<0||r.left>vw){window.jQuery(toggle).dropdown('hide');toggle.setAttribute('aria-expanded','false');restore();return;}
  var width=Math.min(Math.max(active.width,210),vw-24),below=vh-r.bottom-16,above=r.top-16;
  var available=Math.max(80,Math.max(below,above)),height=Math.min(menu.scrollHeight,available,vh-24);
  var top=below>=height||below>=above?r.bottom+6:r.top-height-6;
  menu.style.setProperty('--naxx-menu-width',width+'px');
  menu.style.setProperty('--naxx-menu-height',Math.max(80,Math.min(available,vh-24))+'px');
  menu.style.setProperty('--naxx-menu-left',Math.max(12,Math.min(r.right-width,vw-width-12))+'px');
  menu.style.setProperty('--naxx-menu-top',Math.max(12,Math.min(top,vh-height-12))+'px');
 }
 function requestPlace(){if(active&&!frame)frame=requestAnimationFrame(place);}
 function restore(){
  if(!active)return;var saved=active;active=null;
  saved.menu.classList.remove('naxx-floating-dropdown');
  if(saved.style===null)saved.menu.removeAttribute('style');else saved.menu.setAttribute('style',saved.style);
  if(saved.marker.isConnected)saved.marker.replaceWith(saved.menu);else saved.menu.remove();
 }
 function bind(){
  var jq=window.jQuery;if(bound||!jq||!jq.fn.dropdown)return;bound=true;
  jq(document).on('shown.bs.dropdown.naxxFloating',function(event){
   var parent=event.target;if(!parent.closest||!parent.closest('table,.page-title-box'))return;
   var menu=parent.querySelector(':scope > .dropdown-menu'),toggle=parent.querySelector('[data-toggle="dropdown"]');
   if(!menu||!toggle)return;if(active)restore();
   var marker=document.createComment('naxx-menu');
   active={menu:menu,parent:parent,toggle:toggle,marker:marker,style:menu.getAttribute('style'),width:menu.getBoundingClientRect().width};
   menu.before(marker);document.body.appendChild(menu);menu.classList.add('naxx-floating-dropdown');place();
  });
  jq(document).on('hidden.bs.dropdown.naxxFloating',function(event){if(active&&event.target===active.parent)restore();});
  document.addEventListener('scroll',requestPlace,true);window.addEventListener('resize',requestPlace,{passive:true});
  document.addEventListener('keydown',function(event){
   if(!active||!(active.menu.contains(event.target)||event.target===active.toggle))return;
   if(event.key==='Escape'){event.preventDefault();event.stopImmediatePropagation();var toggle=active.toggle;jq(toggle).dropdown('hide');toggle.setAttribute('aria-expanded','false');restore();toggle.focus();}
   else if(['ArrowDown','ArrowUp','Home','End'].indexOf(event.key)!==-1){event.preventDefault();event.stopImmediatePropagation();var items=Array.from(active.menu.querySelectorAll('.dropdown-item:not(.disabled)')).filter(function(x){return x.getBoundingClientRect().height>0;}),index=items.indexOf(document.activeElement);if(!items.length)return;var next=event.key==='Home'?0:event.key==='End'?items.length-1:event.key==='ArrowDown'?(index+1)%items.length:(index<=0?items.length:index)-1;items[next].focus();items[next].scrollIntoView({block:'nearest'});}
  },true);
 }
 function organize(){
  if(!/\/streams(?:\.php)?$/.test(location.pathname))return;
  document.querySelectorAll('.page-title-box .dropdown-menu').forEach(function(menu){
   if(menu.dataset.naxxChannelTools)return;menu.dataset.naxxChannelTools='1';
   var links=Array.from(menu.querySelectorAll(':scope > a')),groups=[['Conteúdo',[]],['Edição em lote',[]],['Manutenção e análise',[]],['Exportação',[]]];
   var importer=document.createElement('a');importer.href='naxx-importador.php';importer.className='dropdown-item';importer.dataset.naxxImportLink='';importer.textContent='Importador';groups[0][1].push(importer);
   links.forEach(function(link){var action=link.getAttribute('onclick')||'',group=2;
    if(/review|stream_categories|channel_order|epgs/.test(action))group=0;
    if(/mass_delete|stream_mass/.test(action))group=1;
    if(link.id==='btn-export-csv')group=3;
    if(/review\?type=1/.test(action))link.textContent='Revisar canais';
    groups[group][1].push(link);
   });
   groups.forEach(function(group){if(!group[1].length)return;var heading=document.createElement('h6');heading.className='dropdown-header';heading.textContent=group[0];menu.appendChild(heading);group[1].forEach(function(link){menu.appendChild(link);});});
  });
 }
 window.NaxxMenus={enhance:function(){bind();organize();if(active)requestPlace();}};
}());

/* Cache e Redis: diagnóstico de leitura, tradução e edição assistida da rotina nativa. */
(function(){
 'use strict';var current=null;
 var words={
 'Maximum Performance':'Recursos de desempenho','Good Performance':'Recursos de desempenho',
 "You're using both Caching and Redis Connection Handler, your service is optimised for":'Cache e gerenciador Redis estão habilitados nas configurações. Confira o diagnóstico abaixo para validar a conexão e o',
 'maximum performance':'estado do serviço',
 'Your last cron execution was at':'A última execução da rotina ocorreu em',
 '. If it takes longer to run a cron than the time between executions, you will have issues as the caching will be cut off before completion.':'. Se a execução demorar mais que o intervalo configurado, o cache poderá ser interrompido antes de terminar.',
 "Please ensure the cron format is correct, otherwise it won't run.":'Confira o formato da rotina; uma expressão inválida impede a execução.',
 'Minute':'Minuto','Hour':'Hora','Thread Count':'Quantidade de threads','Update Changes Only':'Atualizar somente alterações','Streams':'Canais','Lines':'Contas','Series':'Séries','Time Taken':'Tempo de execução',
 'Disable Cache':'Desativar cache','Enable Cache':'Ativar cache','Regenerate Cache':'Reconstruir cache','Save Cron':'Salvar agendamento',
 'Server Status':'Estado do servidor','Authentication':'Autenticação','ONLINE':'Ativo','OFFLINE':'Indisponível','AUTHENTICATED':'Autenticado','VALID PASSWORD':'Autenticação válida','INVALID PASSWORD':'Autenticação inválida',
 'Disable Handler':'Desativar gerenciador','Enable Handler':'Ativar gerenciador','Clear Database':'Limpar dados do Redis','Pros & Cons':'Vantagens e limitações',
 'The handler will allow all connections from clients to load balancers to be verified and managed using Redis rather than through mysql connections.':'O gerenciador valida e administra as conexões dos clientes nos servidores de distribuição usando Redis.',
 'Disabling Redis handler will disconnect all of your active clients, enabling it however should move the live connections from MySQL to Redis without disconnects.':'Desativar o gerenciador Redis desconecta os clientes ativos. Ao ativá-lo, o painel procura transferir as conexões do MySQL para o Redis sem desconectá-las.',
 "Before deciding whether Redis Connection Handler is right for you, you should know a few things. Firstly, enabling Redis will significantly increase XUI's ability to handle connections as the previous bottleneck would be from MySQL not being able to handle the amount of incoming client requests. You'll also find that zap time will be quicker, CPU should be lower and things will generally run quite smoothly.":'O Redis pode ampliar a capacidade de conexões e reduzir a carga do MySQL em servidores movimentados. O resultado depende da quantidade de clientes, das fontes e dos recursos do servidor.',
 'The drawbacks from using Redis is that the live connection database is stored in memory, although a backup is periodically written, restarting XUI can result in connection losses. In addition to this, your ability to filter or search some content in the Admin or Reseller interface will be diminished. For example, with Redis on you can only sort Live Connections by Time Active ascending or descending and you cannot search the live connection list. You also lose the ability to sort by Active Connections in Lines or Content pages etc.':'As conexões ativas ficam na memória. Mesmo com gravações periódicas de backup, reiniciar o painel pode desconectar clientes. Algumas pesquisas e ordenações também ficam limitadas: a lista de conexões pode ser ordenada pelo tempo ativo, mas sua pesquisa e a ordenação por conexões ativas em contas e conteúdo deixam de estar disponíveis.',
 'The best way to decide if Redis is right for you is to try it for yourself.':'Acompanhe os indicadores e o comportamento dos clientes para escolher a configuração adequada ao seu servidor.',
 'Clear':'Limpar','Cancel':'Cancelar','Are you sure you want to clear the Redis database? This will drop all connections.':'Limpar os dados do Redis desconecta todos os clientes ativos. Deseja continuar?',
 'Cache has been completely disabled!':'Cache desativado.','Cache has been completely regenerated!':'Reconstrução do cache solicitada.','Cache has been completely enabled!':'Cache ativado.','Handler has been completely disabled!':'Gerenciador desativado.','Handler has been enabled!':'Gerenciador ativado.','Redis database has been cleared!':'Dados do Redis limpos.','An error occured while processing your request.':'Não foi possível concluir a operação.'
 };
 function translate(){
  var roots=[document.querySelector('.wrapper')].concat(Array.from(document.querySelectorAll('.jBox-container,.jq-toast-wrap')));
  roots.filter(Boolean).forEach(function(root){var walker=document.createTreeWalker(root,NodeFilter.SHOW_TEXT),node;
   while((node=walker.nextNode())){if(node.parentElement.closest('script,style,textarea,code,pre,[data-naxx-cache-tools]'))continue;var key=node.nodeValue.replace(/\s+/g,' ').trim(),value=words[key];if(value)node.nodeValue=(/^\s/.test(node.nodeValue)?' ':'')+value+(/\s$/.test(node.nodeValue)?' ':'');}
   root.querySelectorAll('input[type="submit"]').forEach(function(input){if(words[input.value])input.value=words[input.value];});
  });
 }
 function cronPart(value,max){
  if(!value||value.length>128)return false;
  return value.split(',').every(function(part){var match=part.match(/^(\*|\d+(?:-\d+)?)(?:\/(\d+))?$/);if(!match)return false;if(match[2]&&(+match[2]<1||+match[2]>max+1))return false;if(match[1]==='*')return true;var range=match[1].split('-').map(Number);return range.every(function(n){return n>=0&&n<=max;})&&(range.length===1||range[0]<=range[1]);});
 }
 function bytes(value){if(!Number.isFinite(value))return '—';if(value===0)return '0 B';var unit=Math.min(3,Math.floor(Math.log(value)/Math.log(1024)));return new Intl.NumberFormat('pt-BR',{maximumFractionDigits:1}).format(value/Math.pow(1024,unit))+' '+['B','KB','MB','GB'][unit];}
 function mount(){
  var table=document.getElementById('datatable-cache'),minute=document.getElementById('minute'),hour=document.getElementById('hour'),threads=document.getElementById('cache_thread_count');if(!table||!minute||!hour||!threads)return;
  var root=document.createElement('section');root.className='card naxx-cache-tools';root.dataset.naxxCacheTools='';
  root.innerHTML='<div class="card-body"><div class="naxx-cache-tools-heading"><div><h5 class="header-title">Diagnóstico de cache e Redis</h5><p class="text-muted">Indicadores do Redis deste servidor, sem alterar os canais.</p></div><div class="naxx-cache-tool-actions"><button type="button" class="btn btn-primary" data-cache-refresh>Atualizar diagnóstico</button><button type="button" class="btn btn-light" data-cache-report disabled>Baixar relatório</button></div></div><p data-cache-status role="status" aria-live="polite">Consultando o serviço…</p><div class="naxx-cache-metrics">'+[['latency','Tempo de resposta'],['memory','Memória utilizada'],['peak','Pico de memória'],['keys','Chaves armazenadas'],['clients','Clientes Redis'],['rate','Taxa de acertos']].map(function(pair){return '<div><span>'+pair[1]+'</span><strong data-cache-metric="'+pair[0]+'">—</strong></div>';}).join('')+'</div><p class="naxx-cache-diagnostic-note text-muted" data-cache-note></p><label class="naxx-cache-auto"><input type="checkbox" data-cache-auto> Atualizar a cada 30 segundos enquanto esta página estiver visível</label></div>';
  var nativeCard=table.closest('.card');nativeCard.before(root);
  Array.from(document.querySelectorAll('.wrapper .card')).some(function(card){if(card!==nativeCard&&card.querySelector('.progress')){card.classList.add('naxx-cache-performance');return true;}return false;});
  [['#cache','Cache do painel'],['#connections','Conexões Redis']].forEach(function(pair){var link=document.querySelector('.nav-link[href="'+pair[0]+'"]'),span=link&&link.querySelector('span');if(span){span.classList.remove('d-none','d-sm-inline');span.textContent=pair[1];link.setAttribute('aria-label',pair[1]);}});
  var presets=document.createElement('section');presets.className='naxx-cache-presets';presets.innerHTML='<h6>Perfis de agendamento</h6><p class="text-muted">Preencha um perfil e use “Salvar agendamento” para aplicar.</p><div class="naxx-cache-preset-buttons"><button type="button" class="btn btn-light" data-cache-preset="10,1">Econômico · 10 min</button><button type="button" class="btn btn-light" data-cache-preset="5,2">Equilibrado · 5 min</button><button type="button" class="btn btn-light" data-cache-preset="2,2">Mais frequente · 2 min</button><button type="button" class="btn btn-outline-primary" data-cache-restore>Restaurar campos</button></div><p data-cache-schedule role="status"></p></section>';
  table.closest('.form-group').before(presets);
  var form=minute.closest('form'),original={minute:minute.value,hour:hour.value,threads:threads.value},timer=null,controller=null,last=null,pending=false;
  var status=root.querySelector('[data-cache-status]'),refresh=root.querySelector('[data-cache-refresh]'),auto=root.querySelector('[data-cache-auto]'),report=root.querySelector('[data-cache-report]');
  function schedule(){clearTimeout(timer);if(root.isConnected&&auto.checked&&!document.hidden)timer=setTimeout(load,30000);}
  function put(key,value){var node=root.querySelector('[data-cache-metric="'+key+'"]');if(node.textContent!==value)node.textContent=value;}
  async function load(){
   if(pending||!root.isConnected)return;pending=true;refresh.disabled=true;refresh.textContent='Consultando…';controller=new AbortController();var timeout=setTimeout(function(){controller.abort();},12000);
   try{var response=await fetch('naxx-update.php?feature=cache',{credentials:'same-origin',cache:'no-store',signal:controller.signal,headers:{'Accept':'application/json'}}),type=response.headers.get('content-type')||'';if(!type.includes('application/json'))throw new Error('A sessão expirou. Entre novamente no painel.');var data=await response.json();if(!response.ok||!data.ok)throw new Error(data.message||'Não foi possível consultar o diagnóstico.');last=data;report.disabled=false;
    var r=data.redis,online=r.status==='online';status.dataset.state=online?'success':'error';status.textContent=(online?'Redis respondeu':'Redis indisponível')+' · '+new Date(data.checked_at).toLocaleTimeString('pt-BR');
    put('latency',online?r.latency_ms.toLocaleString('pt-BR')+' ms':'—');put('memory',bytes(r.used_memory));put('peak',bytes(r.peak_memory));put('keys',online?r.keys.toLocaleString('pt-BR'):'—');put('clients',online?r.clients.toLocaleString('pt-BR'):'—');put('rate',online&&r.hit_rate!==null?r.hit_rate.toLocaleString('pt-BR')+'%':'—');
    root.querySelector('[data-cache-note]').textContent=online?(data.cache.native_redis_warning?'O Redis local respondeu, mas o painel informa uma falha na conexão ou autenticação. Revise a configuração do gerenciador antes de alterar seu estado.':(r.max_memory?'Limite de memória: '+bytes(r.max_memory)+'. ':'Sem limite de memória definido no Redis. ')+(r.operations_per_second||0)+' operações/s. Clientes Redis incluem processos internos do painel.'):r.message;
    Array.from(table.querySelectorAll('button')).forEach(function(button,index){var value=data.cache.counts[index];if(value&&button.textContent.trim()!==value)button.textContent=value;});
   }catch(error){status.dataset.state='error';status.textContent=error.name==='AbortError'?'O diagnóstico demorou para responder. Tente novamente.':error.message;}
   finally{clearTimeout(timeout);pending=false;refresh.disabled=false;refresh.textContent='Atualizar diagnóstico';schedule();}
  }
  function describe(){
   var validMinute=cronPart(minute.value.trim(),59),validHour=cronPart(hour.value.trim(),23),validThreads=/^\d+$/.test(threads.value)&&+threads.value>=1&&+threads.value<=256;
   minute.setCustomValidity(validMinute?'':'Informe um minuto válido, de 0 a 59, ou uma expressão como */5.');hour.setCustomValidity(validHour?'':'Informe uma hora válida, de 0 a 23, ou * para todas.');threads.setCustomValidity(validThreads?'':'Informe de 1 a 256 threads.');
   var note=presets.querySelector('[data-cache-schedule]');note.dataset.state=validMinute&&validHour&&validThreads?'success':'error';
   var match=minute.value.match(/^\*\/(\d+)$/);note.textContent=!validMinute||!validHour||!validThreads?'Revise os campos de minuto, hora e quantidade de threads.':(match&&hour.value==='*'?'Execução a cada '+match[1]+' minutos.':'Agendamento: minuto '+minute.value+' · hora '+hour.value+'.')+' '+threads.value+' thread(s). Aumentar a frequência ou as threads pode elevar o uso do servidor.';
   return validMinute&&validHour&&validThreads;
  }
  presets.addEventListener('click',function(event){var preset=event.target.closest('[data-cache-preset]');if(preset){var values=preset.dataset.cachePreset.split(',');minute.value='*/'+values[0];hour.value='*';threads.value=values[1];describe();}if(event.target.closest('[data-cache-restore]')){minute.value=original.minute;hour.value=original.hour;threads.value=original.threads;describe();}});
  [minute,hour,threads].forEach(function(input){input.addEventListener('input',describe);});
  function validate(event){if(!describe()){event.preventDefault();event.stopImmediatePropagation();form.reportValidity();}}
  form.addEventListener('submit',validate,true);refresh.addEventListener('click',load);auto.addEventListener('change',schedule);
  function visibility(){clearTimeout(timer);if(auto.checked&&!document.hidden)load();}document.addEventListener('visibilitychange',visibility);
  report.addEventListener('click',function(){if(!last)return;var url=URL.createObjectURL(new Blob([JSON.stringify(last,null,2)],{type:'application/json'})),link=document.createElement('a');link.href=url;link.download='naxx-diagnostico-cache-'+new Date().toISOString().slice(0,10)+'.json';link.click();setTimeout(function(){URL.revokeObjectURL(url);},1000);});
  current={root:root,destroy:function(){clearTimeout(timer);if(controller)controller.abort();document.removeEventListener('visibilitychange',visibility);form.removeEventListener('submit',validate,true);}};
  describe();load();
 }
 window.NaxxCache={enhance:function(){if(!/\/cache(?:\.php)?$/.test(location.pathname)){if(current){current.destroy();current=null;}return;}translate();if(current&&current.root.isConnected)return;if(current)current.destroy();mount();},validCronPart:cronPart};
}());

/* Agrupa os indicadores mantendo os mesmos nós usados pela atualização nativa. */
(function(){
 'use strict';
 function arrange(){
  if(document.querySelector('.naxx-dashboard-stat-shell'))return;
  var selectors=['active-connections','online-users','active-streams','offline-streams','input-flow','output-flow'];
  var columns=[];
  selectors.forEach(function(name){var body=document.querySelector('.card-body.'+name),card=body&&body.closest('.card');if(!card)return;var root=card.parentElement.tagName==='A'?card.parentElement:card,column=root.parentElement;if(columns.indexOf(column)===-1)columns.push(column);});
  if(!columns.length)return;var parent=columns[0].parentElement;if(!columns.every(function(column){return column.parentElement===parent;}))return;
  var shell=document.createElement('div');shell.className='col-12 naxx-dashboard-stat-shell';var grid=document.createElement('div');grid.className='row naxx-dashboard-stat-grid';shell.appendChild(grid);
  columns[0].before(shell);parent.classList.remove('naxx-dashboard-stat-grid');columns.forEach(function(column){grid.appendChild(column);});
 }
 function combine(firstSelector,secondSelector,title,key){
  if(document.querySelector('[data-naxx-stat-group="'+key+'"]'))return;
  var first=document.querySelector(firstSelector),second=document.querySelector(secondSelector);if(!first||!second)return;
  var firstCard=first.closest('.card'),secondCard=second.closest('.card');if(!firstCard||!secondCard||firstCard===secondCard)return;
  var firstLink=firstCard.parentElement.tagName==='A'?firstCard.parentElement:null,secondLink=secondCard.parentElement.tagName==='A'?secondCard.parentElement:null;
  var firstRoot=firstLink||firstCard,secondRoot=secondLink||secondCard,firstColumn=firstRoot.parentElement,secondColumn=secondRoot.parentElement;
  if(firstColumn.parentElement!==secondColumn.parentElement)return;
  var card=document.createElement('div');card.className='card cta-box naxx-joined-stat-card';card.dataset.naxxStatGroup=key;
  var heading=document.createElement('h5');heading.textContent=title;card.appendChild(heading);
  var grid=document.createElement('div');grid.className='naxx-joined-stats';card.appendChild(grid);firstRoot.before(card);
  [[first,firstCard,firstLink],[second,secondCard,secondLink]].forEach(function(parts){var body=parts[0],oldCard=parts[1],link=parts[2];if(link){link.replaceChildren(body);grid.appendChild(link);}else{var item=document.createElement('div');item.appendChild(body);grid.appendChild(item);oldCard.remove();}});
  var labels=key==='channels'?['Ao vivo','Indisponíveis']:key==='network'?['Saída','Entrada']:['Conexões ativas','Contas ativas'];
  first.querySelector('p').textContent=labels[0];second.querySelector('p').textContent=labels[1];
  Array.from(firstColumn.classList).forEach(function(name){var match=name.match(/^(col-(?:(?:sm|md|lg|xl)-)?)(\d+)$/);if(match&&secondColumn.classList.contains(name))firstColumn.classList.replace(name,match[1]+Math.min(12,+match[2]*2));});
  if(!secondColumn.children.length&&!secondColumn.textContent.trim())secondColumn.remove();
 }
 function servers(){
  if(!document.querySelector('.naxx-dashboard-stat-shell'))return;
  document.querySelectorAll('[id^="s_"][id$="_conns"]').forEach(function(counter){
   var body=counter.closest('.card-header'),column=body&&body.parentElement;if(!body||body.classList.contains('naxx-dashboard-server-metrics')||!column||column.classList.contains('naxx-dashboard-server'))return;
   var footer=Array.from(column.children).find(function(child){return child.classList.contains('card-footer');});if(!footer)return;
   column.classList.add('naxx-dashboard-server');var card=document.createElement('div');card.className='card naxx-dashboard-server-card';
   while(column.firstChild)card.appendChild(column.firstChild);column.appendChild(card);body.classList.add('naxx-dashboard-server-metrics');
   var labels={'Streams Live':'Canais ao vivo','Requests /sec':'Requisições/s','MEM':'Memória','IO':'Disco (E/S)','DISK':'Armazenamento'};
   body.querySelectorAll('.header-title').forEach(function(label){var text=label.textContent.replace(/\s+/g,' ').trim();if(labels[text])label.textContent=labels[text];});
  });
 }
 window.NaxxDashboard={enhance:function(){arrange();combine('.card-body.active-connections','.card-body.online-users','Acessos','access');combine('.card-body.output-flow','.card-body.input-flow','Tráfego de rede','network');combine('.card-body.active-streams','.card-body.offline-streams','Canais','channels');servers();}};
}());

/* Limpeza de conteúdo com consulta, autenticação e operações nativas do painel. */
(function () {
  'use strict';
  var definitions = {
    channel:{form:'stream_form', field:'streams', selection:'rStreams', pane:'stream-selection', table:'datatable-md1', action:'mass_delete_streams', label:'canais'},
    movie:{form:'movie_form', field:'movies', selection:'rMovies', pane:'movie-selection', table:'datatable-md2', action:'mass_delete_movies', label:'filmes'},
    series:{form:'series_form', field:'series', selection:'rSeries', pane:'series-selection', table:'datatable-md4', action:'mass_delete_series', label:'séries'},
    episodes:{form:'episodes_form', field:'episodes', selection:'rEpisodes', pane:'episodes-selection', table:'datatable-md5', action:'mass_delete_episodes', label:'episódios'}
  };
  var labels = {channel:'Deletar Canais', movie:'Deletar Filmes', series:'Deletar Séries', all:'Deletar Tudo'};
  // Os endpoints nativos só retornam dados para requisições AJAX identificadas.
  var ajaxHeaders = {'X-Requested-With':'XMLHttpRequest','Accept':'application/json, text/javascript, */*; q=0.01'};
  var active = null, busy = false, cancelled = false, readerController = null, phase = '';
  function ids(type) {
    return Array.from(new Set((window[definitions[type].selection] || []).map(String).filter(function (id) {return /^\d+$/.test(id);})));
  }
  function route(mode, run) {return 'mass_delete?naxx_cleanup=' + mode + (run ? '&naxx_cleanup_run=1' : '');}
  function mode() {
    if (!/\/mass_delete(?:\.php)?$/.test(location.pathname)) return null;
    var value = new URLSearchParams(location.search).get('naxx_cleanup');
    return Object.prototype.hasOwnProperty.call(labels, value) ? value : null;
  }
  function addQuickTools() {
    document.querySelectorAll('[data-naxx-cleanup-menu]').forEach(function (item) {item.remove();});
    if (!/\/quick_tools(?:\.php)?$/.test(location.pathname) || document.querySelector('[data-naxx-quick-cleanup]')) return;
    var nav = document.querySelector('.navigation-menu');
    // A presença do atalho original preserva a permissão de limpeza do usuário.
    var original = nav && nav.querySelector('a[href="mass_delete"],a[href="./mass_delete"],a[href="mass_delete.php"]');
    if (!original) return;
    var heading = document.querySelector('.page-title-box');
    if (!heading) return;
    var card = document.createElement('section'); card.className = 'card'; card.dataset.naxxQuickCleanup = '';
    card.innerHTML = '<div class="card-body"><h2 class="header-title">Limpeza de conteúdo</h2><p class="text-muted">Exclua todos os conteúdos do tipo escolhido, em todas as páginas e categorias. A confirmação mostra a quantidade antes da exclusão.</p><div class="d-flex flex-wrap" style="gap:10px" data-cleanup-actions></div></div>';
    Object.keys(labels).forEach(function (key) {
      var link = document.createElement('a');
      link.href = route(key,true); link.className = 'btn ' + (key === 'all' ? 'btn-danger' : 'btn-outline-danger'); link.dataset.naxxCleanupLink = '';
      var icon = document.createElement('i'); icon.className = (key === 'all' ? 'fas fa-bomb' : 'fas fa-trash-alt') + ' mr-1'; icon.setAttribute('aria-hidden','true');
      link.appendChild(icon); link.appendChild(document.createTextNode(labels[key]));
      card.querySelector('[data-cleanup-actions]').appendChild(link);
    });
    heading.after(card);
  }
  function say(text, error) {
    if (!active) return;
    var status = active.panel.querySelector('[data-cleanup-status]');
    status.className = 'alert ' + (error ? 'alert-danger' : 'alert-info') + ' mt-3 mb-0'; status.textContent = text;
  }
  function markSelection(type, selected) {
    var def = definitions[type], form = document.getElementById(def.form);
    window[def.selection] = selected.slice();
    if (form) form.querySelector('[name="' + def.field + '"]').value = JSON.stringify(selected);
    var lookup = new Set(selected);
    document.querySelectorAll('#' + def.table + ' tbody tr').forEach(function (row) {
      var cell = row.querySelector('td'), match = cell && lookup.has(cell.textContent.trim());
      ['selectedfilter','ui-selected','selected'].forEach(function (name) {row.classList.toggle(name,Boolean(match));});
    });
  }
  function plan(types) {
    return types.map(function (type) {return {type:type, ids:ids(type)};}).filter(function (job) {return job.ids.length;});
  }
  function confirm(jobs, all) {
    var total = jobs.reduce(function (sum,job) {return sum + job.ids.length;},0);
    if (!total) {say(all ? 'Não há conteúdos deste tipo para excluir.' : 'Selecione os conteúdos que deseja excluir nas opções detalhadas.',!all);return false;}
    var summary = jobs.map(function (job) {return job.ids.length + ' ' + definitions[job.type].label;}).join('\n');
    return window.confirm('Confirmar limpeza de conteúdo\n\n' + summary + '\n\nTotal: ' + total + ' conteúdos' + (all ? ' deste escopo, incluindo todas as páginas e categorias.' : ' selecionados.') + '\nA exclusão é permanente. Confirmar?');
  }
  function setBusy(value) {
    busy = value;
    if (!active) return;
    active.panel.querySelectorAll('[data-cleanup-delete-all]').forEach(function (button) {button.disabled=value;});
    active.forms.forEach(function (form) {form.querySelectorAll('[type="submit"],[data-cleanup-select-filter]').forEach(function (button) {button.disabled=value;});});
    active.panel.querySelector('[data-cleanup-cancel]').hidden = !value;
    active.panel.querySelector('[data-cleanup-cancel]').disabled = false;
    active.panel.querySelector('[data-cleanup-cancel]').textContent = phase === 'read' ? 'Cancelar consulta' : 'Interromper após o lote atual';
  }
  function delay(ms) {return new Promise(function (resolve) {window.setTimeout(resolve,ms);});}
  async function readJson(response, operation, deletion) {
    var body = (await response.text()).trim(), result;
    var next = deletion ? ' Atualize a página para conferir o resultado antes de tentar novamente.' : ' Atualize a página e tente novamente.';
    if (!body) throw new Error('O painel retornou uma resposta vazia ' + operation + '.' + next);
    try {result = JSON.parse(body);} catch (error) {throw new Error('O painel retornou uma resposta inválida ' + operation + '.' + next);}
    if (!result || typeof result !== 'object' || Array.isArray(result)) throw new Error('O painel retornou uma resposta inválida ' + operation + '.' + next);
    return result;
  }
  function orderedTypes() {return ['channel','movie','episodes','series'].filter(function (type) {return active.types.indexOf(type) !== -1;});}
  async function readIds(type, all) {
    var jq=window.jQuery,def=definitions[type],attempt=0;
    var params=null;
    while (attempt++ < 75) {
      if (jq && jq.fn.dataTable && jq.fn.dataTable.isDataTable('#'+def.table)) {
        params=jq('#'+def.table).DataTable().ajax.params();
        if (params && params.id) break;
      }
      if (cancelled) throw new Error('Consulta cancelada. Nenhum conteúdo foi excluído.');
      await delay(200);jq=window.jQuery;
    }
    if (!document.getElementById(def.form) || !jq || !jq.fn.dataTable || !jq.fn.dataTable.isDataTable('#'+def.table)) throw new Error('A tabela de '+def.label+' não está disponível. Atualize a página e tente novamente.');
    if (!params || !params.id) throw new Error('A tabela nativa ainda não está pronta.');
    params=jq.extend(true,{},params);
    if (all) {
      // Limpa somente filtros de conteúdo. Mantém o identificador da tabela,
      // include_channels e os parâmetros nativos que definem seu escopo.
      ['category','filter','server','series'].forEach(function (key) {if (Object.prototype.hasOwnProperty.call(params,key)) params[key]='';});
      params.search={value:'',regex:false};
      (params.columns || []).forEach(function (column) {column.search={value:'',regex:false};});
      params.order=[{column:0,dir:'asc'}];
    }
    var selected=new Set(),start=0,target=null;
    do {
      if (cancelled) throw new Error('Consulta cancelada. Nenhum conteúdo foi excluído.');
      params.start=start;params.length=500;
      var response=await fetch('table?'+jq.param(params),{credentials:'same-origin',cache:'no-store',headers:ajaxHeaders,signal:readerController.signal});
      if (!response.ok || /\/(login|license)(?:[?/]|$)/.test(response.url)) throw new Error('Não foi possível consultar os conteúdos. Verifique sua sessão.');
      var result=await readJson(response,'ao consultar '+def.label,false),count=Number(result.recordsFiltered);
      if (!Array.isArray(result.data) || !Number.isSafeInteger(count) || count < 0) throw new Error('A tabela nativa retornou uma resposta inválida.');
      if (target===null) target=count;
      else if (target!==count) throw new Error('A lista mudou durante a consulta. Tente novamente.');
      for (var row of result.data) {
        var id=String(row[0]).replace(/<[^>]*>/g,'').trim();
        if (!/^\d+$/.test(id) || selected.has(id)) throw new Error('A lista mudou durante a consulta ou retornou um identificador inválido. Tente novamente.');
        selected.add(id);
      }
      start+=result.data.length;
      if (start>target || (start<target && !result.data.length)) throw new Error('A lista mudou durante a consulta. Tente novamente.');
      say('Consultando '+def.label+': '+selected.size+' de '+target+'. Nenhum conteúdo foi excluído.');
      if (start<target) await delay(200);
    } while (start<target);
    if (cancelled) throw new Error('Consulta cancelada. Nenhum conteúdo foi excluído.');
    return Array.from(selected);
  }
  async function selectFilter(type) {
    if (busy || !active) return;
    var def=definitions[type];
    cancelled=false;phase='read';readerController=new AbortController();setBusy(true);
    try {
      var selected=await readIds(type,false);markSelection(type,selected);
      say(selected.length+' '+def.label+' selecionados pelo filtro atual. Revise antes de excluir.');
    } catch (error) {say(error.name === 'AbortError' ? 'Seleção cancelada. A seleção anterior foi mantida.' : error.message,true);}
    finally {readerController=null;phase='';setBusy(false);}
  }
  async function deleteAll() {
    if (busy || !active) return;
    cancelled=false;phase='read';readerController=new AbortController();setBusy(true);
    try {
      var jobs=[];
      for (var type of orderedTypes()) {
        var found=await readIds(type,true);if (found.length) jobs.push({type:type,ids:found});
      }
      if (cancelled) throw new Error('Consulta cancelada. Nenhum conteúdo foi excluído.');
      if (!confirm(jobs,true)) {if (jobs.length) say('Exclusão cancelada. Nenhum conteúdo foi excluído.');return;}
      jobs.forEach(function (job) {markSelection(job.type,job.ids);});
      readerController=null;phase='delete';setBusy(true);
      await execute(jobs);
    } catch (error) {say(error.name==='AbortError'?'Consulta cancelada. Nenhum conteúdo foi excluído.':error.message,true);}
    finally {readerController=null;phase='';setBusy(false);}
  }
  async function deleteSelected(onlyType) {
    if (busy || !active) return;
    var types=typeof onlyType==='string'?[onlyType]:orderedTypes();
    var jobs=plan(types.filter(function (type) {return active.types.indexOf(type)!==-1;}));
    if (!confirm(jobs,false)) return;
    cancelled=false;phase='delete';setBusy(true);
    try {await execute(jobs);} finally {phase='';setBusy(false);}
  }
  async function execute(jobs) {
    var sent = 0, total = jobs.reduce(function (sum,job) {return sum + job.ids.length;},0);
    try {
      for (var job of jobs) {
        var def = definitions[job.type], form = document.getElementById(def.form);
        if (!form) throw new Error('O formulário nativo não está disponível.');
        for (var start=0; start<job.ids.length; start+=100) {
          if (cancelled) {say('Limpeza interrompida. ' + sent + ' conteúdos processados; os demais continuam selecionados.');return;}
          var batch = job.ids.slice(start,start+100), data = new FormData(form);
          data.set(def.field,JSON.stringify(batch));
          say('Excluindo ' + def.label + ': ' + sent + ' de ' + total + ' conteúdos processados.');
          var response = await fetch('post.php?action=' + def.action + '&referer=' + encodeURIComponent(route(active.mode)),{method:'POST',body:data,credentials:'same-origin',headers:ajaxHeaders});
          if (!response.ok || /\/(login|license)(?:[?/]|$)/.test(response.url)) throw new Error('O painel recusou a operação. Verifique sua sessão.');
          var result = await readJson(response,'após solicitar a exclusão de '+def.label,true);
          var destination=typeof result.location==='string'?result.location.trim():'';
          if ((result.location!=null&&typeof result.location!=='string') || (!destination && !(result.result === true && Number(result.status) === 1)) || /(?:^|\/)(?:login|license)(?:[?.#]|$)/i.test(destination)) throw new Error('O painel recusou a exclusão (código ' + result.status + ').');
          sent += batch.length;
          var removed = new Set(batch);markSelection(job.type,ids(job.type).filter(function (id) {return !removed.has(id);}));
          await delay(250);
        }
      }
      say('Limpeza concluída: ' + sent + ' conteúdos processados pelo painel.');
      jobs.forEach(function (job) {var jq=window.jQuery;if (jq && jq.fn.dataTable.isDataTable('#' + definitions[job.type].table)) jq('#' + definitions[job.type].table).DataTable().ajax.reload(null,false);});
    } catch (error) {say(error.message + (sent ? ' Já processados: ' + sent + '. A seleção restante foi mantida.' : ''),true);}
  }
  function setup() {
    var selectedMode = mode();
    if (!selectedMode || document.querySelector('[data-naxx-cleanup-panel]')) return;
    var types = selectedMode === 'all' ? ['channel','movie','series','episodes'] : selectedMode === 'series' ? ['series','episodes'] : [selectedMode];
    var forms = types.map(function (type) {return document.getElementById(definitions[type].form);}).filter(Boolean);
    if (!forms.length) return;
    var panel = document.createElement('div');panel.className='card';panel.dataset.naxxCleanupPanel='';
    panel.innerHTML='<div class="card-body"><h2 class="header-title">Limpeza de Conteúdo</h2><p class="text-muted">A limpeza inclui todo o conteúdo do tipo escolhido, em todas as páginas e categorias. Não é necessário selecionar linhas. Confira o total na confirmação.</p><div class="d-flex flex-wrap" style="gap:10px" data-cleanup-modes></div><div class="mt-3 d-flex flex-wrap" style="gap:10px"><button type="button" class="btn btn-danger" data-cleanup-delete-all>Deletar Tudo</button><button type="button" class="btn btn-light" data-cleanup-cancel hidden>Interromper após o lote atual</button></div><div role="status" aria-live="polite" data-cleanup-status></div></div>';
    Object.keys(labels).forEach(function (key) {var link=document.createElement('a');link.className='btn '+(key===selectedMode?'btn-primary':'btn-light');link.href=route(key,true);link.textContent=labels[key];link.dataset.naxxCleanupLink='';if (key===selectedMode) link.setAttribute('aria-current','page');panel.querySelector('[data-cleanup-modes]').appendChild(link);});
    var heading=document.querySelector('.page-title-box');if (heading) heading.after(panel);else forms[0].closest('.card').before(panel);
    active={mode:selectedMode,types:types,forms:forms,panel:panel};
    var pageTitle=document.querySelector('.page-title');if (pageTitle) pageTitle.textContent='Limpeza de Conteúdo';document.title='XUI NAXX | Limpeza de Conteúdo';
    document.querySelectorAll('.nav-pills a[href$="-selection"]').forEach(function (link) {var id=link.getAttribute('href').slice(1);link.closest('li').hidden=!types.some(function (type) {return definitions[type].pane===id;});});
    document.querySelectorAll('.tab-pane').forEach(function (pane) {if (/-selection$/.test(pane.id)) pane.hidden=!types.some(function (type) {return definitions[type].pane===pane.id;});});
    var first=document.querySelector('a[href="#'+definitions[types[0]].pane+'"]');if (first && window.jQuery && window.jQuery.fn.tab) window.jQuery(first).tab('show');
    panel.querySelector('[data-cleanup-delete-all]').textContent=labels[selectedMode];
    panel.querySelector('[data-cleanup-delete-all]').addEventListener('click',deleteAll);
    panel.querySelector('[data-cleanup-cancel]').addEventListener('click',function () {cancelled=true;if (readerController) readerController.abort();say(readerController?'Cancelando consulta…':'Interrompendo após a resposta do lote atual…');});
    var current=new URL(location.href);
    if (current.searchParams.get('naxx_cleanup_run')==='1') {
      current.searchParams.delete('naxx_cleanup_run');
      history.replaceState(history.state,'',current.pathname+current.search+current.hash);
      window.setTimeout(deleteAll,0);
    }
  }
  document.addEventListener('submit',function (event) {
    if (!active || !mode() || active.forms.indexOf(event.target) === -1) return;
    var type=active.types.find(function (key) {return definitions[key].form===event.target.id;});
    event.preventDefault();event.stopImmediatePropagation();
    // Usa o endpoint e os campos nativos, dividindo a seleção em lotes pequenos.
    deleteSelected(type);
  },true);
  document.addEventListener('click',function (event) {
    var anchor=event.target.closest('a[href]');
    var nativeNavigation=event.target.closest('[onclick]');
    if (busy && nativeNavigation && /(?:^|[^\w$.])(?:window\.)?navigate\s*\(/.test(nativeNavigation.getAttribute('onclick') || '')) {
      event.preventDefault();event.stopImmediatePropagation();
      say('Há uma limpeza em andamento. Aguarde ou interrompa a operação atual.');
      return;
    }
    if (busy && anchor && anchor.getAttribute('href').charAt(0)!=='#' && !/^javascript:/i.test(anchor.getAttribute('href'))) {
      event.preventDefault();event.stopImmediatePropagation();
      var target=new URL(anchor.href,location.href);
      if (/\/mass_delete(?:\.php)?$/.test(target.pathname)) say('Há uma limpeza em andamento. Aguarde ou interrompa a operação atual.');
      else window.open(anchor.href,'_blank','noopener');
      return;
    }
    var link=event.target.closest('[data-naxx-cleanup-link]');
    if (link && event.button===0 && !event.ctrlKey && !event.metaKey && !event.shiftKey && !event.altKey) {event.preventDefault();event.stopImmediatePropagation();window.location.assign(link.href);}
  },true);
  window.addEventListener('beforeunload',function (event) {if (busy) {event.preventDefault();event.returnValue='';}});
  function enhance() {addQuickTools();setup();}
  function ready() {
    enhance();var scheduled=false;
    new MutationObserver(function (changes) {if (scheduled || !changes.some(function (change) {return change.addedNodes.length;})) return;scheduled=true;window.requestAnimationFrame(function () {scheduled=false;enhance();});}).observe(document.body,{childList:true,subtree:true});
  }
  if (document.readyState==='complete') ready();else window.addEventListener('load',ready,{once:true});
}());

/* Escolha automática NAXX sobre os modos de transmissão reconhecidos pelo núcleo. */
(function () {
  'use strict';
  if (window.NaxxOnDemand) { window.NaxxOnDemand.enhance(); return; }
  var AUTO = 'naxx_auto', controllers = [], scheduled = 0, submitMarker = {};
  var labels = {'0': 'modo padrão', '1': 'LLOD v2 — FFMPEG', '2': 'LLOD v3 — PHP'};

  function mode(value) { return /^[012]$/.test(String(value)) ? String(value) : null; }
  function number(value) { var n = Number(value); return Number.isFinite(n) ? n : 0; }
  function field(data, key) { var value = data.get(key); return typeof value === 'string' ? value : ''; }
  function checked(data, key) { return data.has(key) && !/^(?:0|false|off|)$/i.test(field(data, key)); }
  function snapshot(data) {
    var servers = data.getAll('on_demand[]').map(number).filter(function (id) { return Number.isInteger(id) && id > 0; });
    servers = Array.from(new Set(servers)).sort(function (a, b) { return a - b; });
    return {
      sources: data.getAll('stream_source[]').filter(function (value) { return typeof value === 'string' && value.trim(); }).map(function (value) { return value.trim(); }),
      flags: {transcode: checked(data, 'enable_transcode') || number(field(data, 'transcode_profile_id')) > 0,
        custom_ffmpeg: field(data, 'custom_ffmpeg'), direct_source: checked(data, 'direct_source'), delay: number(field(data, 'delay_minutes')),
        fetch: {user_agent: field(data, 'user_agent'), proxy: field(data, 'http_proxy'), cookie: field(data, 'cookie'), headers: field(data, 'headers')}},
      on_demand_servers: servers
    };
  }
  function signature(data) {
    return JSON.stringify({draft: snapshot(data), fetch: ['user_agent', 'http_proxy', 'cookie', 'headers'].map(function (key) { return field(data, key); })});
  }
  function connected(controller) { return controller.form.isConnected && !controller.destroyed; }
  function text(controller, message, error) {
    if (!connected(controller)) return;
    controller.status.textContent = message;
    controller.status.setAttribute('role', error ? 'alert' : 'status');
    controller.status.dataset.state = error ? 'error' : 'info';
  }
  function syncSelect(controller) {
    var jq = window.jQuery;
    if (jq) { try { jq(controller.select).trigger('change.select2'); } catch (error) {} }
  }
  function restoreNativeForm(controller) {
    if (!connected(controller)) return;
    Array.from(controller.form.querySelectorAll('input[type="submit"],button[type="submit"]')).forEach(function (button) { button.disabled = false; });
    var jq = window.jQuery;
    if (jq) { try { jq('.wrapper').show(); jq('#status').hide(); } catch (error) {} }
  }
  function direct(controller) {
    var control = controller.form.querySelector('[name="direct_source"]');
    return !!(control && control.checked);
  }
  function busy(controller, enabled) {
    controller.busy = enabled;
    if (!connected(controller)) return;
    controller.analyze.disabled = enabled || direct(controller) || !controller.ready || controller.select.value !== AUTO;
    controller.restore.disabled = enabled || !controller.profile || !controller.profile.active;
    controller.select.disabled = enabled || direct(controller);
    controller.box.setAttribute('aria-busy', enabled ? 'true' : 'false');
  }
  function fail(controller, message) {
    busy(controller, false); restoreNativeForm(controller); text(controller, message, true);
  }
  function sourceStillCurrent(controller, expected) {
    return connected(controller) && signature(new FormData(controller.form)) === expected;
  }
  function endpoint(controller) {
    return new URL('naxx-update.php?feature=ondemand&id=' + controller.id, window.location.href).href;
  }
  function jsonRequest(controller, url, options, milliseconds) {
    var abort = new AbortController(), timeout = 0;
    controller.requests.add(abort);
    options = Object.assign({credentials: 'same-origin', cache: 'no-store'}, options);
    options.headers = Object.assign({'X-Requested-With': 'XMLHttpRequest', 'Accept': 'application/json'}, options.headers || {});
    options.signal = abort.signal;
    var expired = new Promise(function (resolve, reject) {
      timeout = window.setTimeout(function () { abort.abort(); reject(new Error('request_timeout')); }, Math.max(1, milliseconds));
    });
    var request;
    try {
      request = window.fetch(url, options).then(function (response) {
        if (response.status === 401 || response.status === 403 || /\/(?:login|license)(?:\.php)?\/?$/i.test(new URL(response.url || url, window.location.href).pathname)) throw new Error('session_expired');
        if (!response.ok) throw new Error('request_failed');
        return response.json();
      });
    } catch (error) { request = Promise.reject(error); }
    return Promise.race([request, expired]).finally(function () {
      window.clearTimeout(timeout); controller.requests.delete(abort);
    });
  }
  function api(controller, action, values) {
    return jsonRequest(controller, endpoint(controller), {method: 'POST', headers: {'Content-Type': 'application/json'},
      body: JSON.stringify(Object.assign({action: action, id: controller.id, csrf: controller.csrf}, values || {}))}, 10000).then(function (result) {
      if (!result || result.ok !== true) throw new Error('profile_failed');
      if (typeof result.csrf === 'string') controller.csrf = result.csrf;
      return result;
    });
  }
  function observation(raw) {
    if (!raw || typeof raw !== 'object' || !raw.format || typeof raw.format.format_name !== 'string' || !Array.isArray(raw.streams)) return {error: 'probe_failed'};
    return {format: {format_name: raw.format.format_name.slice(0, 120)}, streams: raw.streams.slice(0, 32).map(function (stream) {
      return {codec_type: typeof stream.codec_type === 'string' ? stream.codec_type.slice(0, 16) : '',
        codec_name: typeof stream.codec_name === 'string' ? stream.codec_name.slice(0, 64) : ''};
    })};
  }
  async function plan(controller, data) {
    var draft = snapshot(data), expected = signature(data);
    if (draft.flags.direct_source) throw new Error('direct_source');
    if (!draft.on_demand_servers.length) throw new Error('servers_required');
    if (!draft.sources.length) throw new Error('sources_required');
    if (controller.cached && controller.cached.signature === expected && controller.cached.expires > Date.now()) return controller.cached;
    var observations = [], deadline = Date.now() + 20000;
    var incompatible = draft.flags.transcode || draft.flags.custom_ffmpeg.trim() !== '' || draft.flags.delay > 0;
    if (!incompatible && draft.sources.length <= 3) {
      for (var source of draft.sources) {
        if (!sourceStillCurrent(controller, expected)) throw new Error('source_changed');
        var remaining = deadline - Date.now();
        if (remaining <= 0) { observations.push({error: 'probe_failed'}); continue; }
        var url = new URL('api', window.location.href);
        url.searchParams.set('action', 'probe_stream'); url.searchParams.set('map', '1'); url.searchParams.set('url', source);
        url.searchParams.set('user_agent', field(data, 'user_agent')); url.searchParams.set('proxy', field(data, 'http_proxy'));
        url.searchParams.set('cookies', field(data, 'cookie')); url.searchParams.set('headers', field(data, 'headers'));
        url.searchParams.set('server', String(draft.on_demand_servers[0]));
        try { observations.push(observation(await jsonRequest(controller, url.href, {}, Math.min(8000, remaining)))); }
        catch (error) {
          if (error && error.message === 'session_expired') throw error;
          observations.push({error: 'probe_failed'});
        }
      }
    }
    if (!sourceStillCurrent(controller, expected)) throw new Error('source_changed');
    var result = await api(controller, 'plan', {draft: draft, observations: observations});
    if (!sourceStillCurrent(controller, expected)) throw new Error('source_changed');
    var chosen = result.plan;
    if (!chosen || mode(chosen.mode) === null || typeof chosen.nonce !== 'string' || !/^[a-f0-9]{32,128}$/i.test(chosen.nonce)) throw new Error('invalid_plan');
    controller.cached = {plan: chosen, signature: expected, expires: Date.now() + 240000};
    text(controller, 'Escolha automática: ' + labels[String(chosen.mode)] + '. ' + (typeof chosen.reason === 'string' ? chosen.reason : '') + ' Salve o canal para aplicar.');
    return controller.cached;
  }
  function errorMessage(error) {
    return {direct_source: 'A escolha automática exige retransmissão pelo servidor. Desative Fonte direta para usar este perfil.',
      servers_required: 'Escolha pelo menos um servidor sob demanda antes de analisar ou salvar o perfil automático.',
      sources_required: 'Informe a fonte do canal antes de analisar.', source_changed: 'A fonte ou as opções mudaram durante a análise. Analise novamente antes de salvar.',
      session_expired: 'Sua sessão expirou ou você não tem permissão para editar este canal. Entre novamente no painel e reabra o canal.',
      native_unavailable: 'Não foi possível acompanhar o formulário nativo. Reabra o canal e confira o cadastro antes de tentar novamente.'}[error && error.message] || 'Não foi possível confirmar a escolha automática. Tente analisar novamente; o canal não foi enviado para gravação.';
  }
  function updateProfile(controller, profile) {
    controller.profile = profile && typeof profile === 'object' ? profile : {active: false};
    controller.restore.hidden = !controller.profile.active || mode(controller.profile.previous_mode) === null;
  }
  function finishMetadata(controller, pending, result, nativeCallback, callbackThis, callbackArguments) {
    if (!result || typeof result.location !== 'string' || !result.location.trim() || /(?:^|\/)(?:login|license)(?:[?.#]|$)/i.test(result.location)) {
      controller.cached = null; busy(controller, false);
      if (connected(controller)) return nativeCallback.apply(callbackThis, callbackArguments);
      return;
    }
    var change = pending.automatic ? api(controller, 'commit', {nonce: pending.plan.nonce}) : api(controller, 'deactivate');
    return change.then(function (response) {
      if (pending.automatic && (!response.profile || response.profile.active !== true || mode(response.profile.mode) !== pending.mode)) throw new Error('profile_failed');
      updateProfile(controller, response.profile || {active: false});
      controller.cached = null; busy(controller, false);
      if (connected(controller)) return nativeCallback.apply(callbackThis, callbackArguments);
    }).catch(function () {
      controller.cached = null;
      if (pending.automatic) { controller.select.value = String(pending.plan.mode); syncSelect(controller); }
      updateProfile(controller, {active: false});
      fail(controller, 'O canal foi salvo, mas o perfil NAXX Automático não foi confirmado. Foi solicitado ' + labels[pending.mode] + '. Reabra o canal e confira antes de tentar novamente.');
    });
  }
  function nativeSubmit(controller, receiver, native, args, pending) {
    var jq = window.jQuery, originalAjax = jq && jq.ajax, captured = false;
    if (typeof originalAjax !== 'function' || typeof window.callbackForm !== 'function') throw new Error('native_unavailable');
    var data = args[1];
    // Só este FormData recebe o callback adicional; outros formulários preservam o fluxo nativo.
    function intercept(options) {
      if (options && options.data === data && typeof options.success === 'function' && /(?:[?&])action=stream(?:&|$)/.test(options.url || '')) {
        captured = true;
        var success = options.success, failure = options.error, complete = options.complete;
        options = Object.assign({}, options);
        options.success = function () {
          var oldCallback = window.callbackForm, responseThis = this, responseArgs = arguments;
          window.callbackForm = function (result) {
            return finishMetadata(controller, pending, result, oldCallback, this, arguments);
          };
          try { return success.apply(responseThis, responseArgs); }
          finally { window.callbackForm = oldCallback; }
        };
        options.error = function () {
          controller.cached = null;
          fail(controller, 'A gravação do canal não foi confirmada. Confira o cadastro antes de tentar novamente.');
          if (connected(controller) && typeof failure === 'function') return failure.apply(this, arguments);
        };
        if (typeof complete === 'function') options.complete = complete;
        return originalAjax.call(this, options);
      }
      return originalAjax.apply(this, arguments);
    }
    jq.ajax = intercept;
    try {
      var result = native.apply(receiver, args);
      if (!captured) throw new Error('native_unavailable');
      return result;
    } finally { if (jq.ajax === intercept) jq.ajax = originalAjax; }
  }
  function findController(data) {
    if (!data || typeof data.get !== 'function') return null;
    var id = field(data, 'edit');
    return controllers.find(function (controller) { return connected(controller) && String(controller.id) === id; }) || null;
  }
  function ensureHook() {
    var original = window.submitForm;
    if (typeof original !== 'function' || original.naxxOnDemand === submitMarker) return;
    function submitForm() {
      var args = Array.prototype.slice.call(arguments), controller = args[0] === 'stream' ? findController(args[1]) : null;
      if (!controller && args[0] === 'stream' && args[1] && typeof args[1].get === 'function' && field(args[1], 'llod') === AUTO) {
        // Uma navegação pode remover o formulário entre a serialização e o envio.
        if (typeof window.showError === 'function') window.showError('Reabra o canal para confirmar a escolha automática antes de salvar.');
        return;
      }
      if (!controller) return original.apply(this, args);
      var selected = controller.select.value, automatic = selected === AUTO;
      if (!automatic && !(controller.ready && controller.profile && controller.profile.active)) return original.apply(this, args);
      if (controller.busy) return;
      if (!controller.ready || (automatic && direct(controller))) { fail(controller, errorMessage(new Error(direct(controller) ? 'direct_source' : 'native_unavailable'))); return; }
      // Mesmo em erro de integração o valor virtual nunca chega ao núcleo.
      if (!automatic && mode(selected) === null) { fail(controller, 'Escolha um modo de transmissão válido.'); return; }
      var receiver = this, expected = signature(args[1]);
      busy(controller, true);
      if (!automatic) {
        args[1].set('llod', selected);
        try { return nativeSubmit(controller, receiver, original, args, {automatic: false, mode: selected}); }
        catch (error) { fail(controller, errorMessage(error)); return; }
      }
      text(controller, 'Analisando a fonte para escolher o modo de abertura…');
      return plan(controller, args[1]).then(function (choice) {
        if (!sourceStillCurrent(controller, expected) || controller.select.value !== AUTO) throw new Error('source_changed');
        args[1].set('llod', String(choice.plan.mode));
        return nativeSubmit(controller, receiver, original, args, {automatic: true, mode: String(choice.plan.mode), plan: choice.plan});
      }).catch(function (error) { fail(controller, errorMessage(error)); });
    }
    submitForm.naxxOnDemand = submitMarker;
    window.submitForm = submitForm;
  }
  function mount(form) {
    var idControl = form.querySelector('input[name="edit"]'), select = form.querySelector('select#llod');
    var id = idControl && number(idControl.value);
    if (!select || !Number.isInteger(id) || id <= 0 || form.querySelector('input[name="m3u_file"]')) return;
    if (controllers.some(function (controller) { return controller.form === form; })) return;
    var option = document.createElement('option'); option.value = AUTO; option.textContent = 'NAXX Automático'; option.disabled = true;
    select.appendChild(option);
    var box = document.createElement('div'); box.className = 'naxx-ondemand-profile mt-2';
    var status = document.createElement('p'); status.className = 'small text-muted mb-2'; status.setAttribute('aria-live', 'polite');
    var analyze = document.createElement('button'); analyze.type = 'button'; analyze.className = 'btn btn-sm btn-light mr-2'; analyze.textContent = 'Analisar agora'; analyze.disabled = true;
    var restore = document.createElement('button'); restore.type = 'button'; restore.className = 'btn btn-sm btn-light'; restore.textContent = 'Usar modo anterior'; restore.hidden = true;
    box.appendChild(status); box.appendChild(analyze); box.appendChild(restore);
    var parent = select.parentNode; parent.appendChild(box);
    var controller = {id: id, form: form, select: select, option: option, box: box, status: status, analyze: analyze, restore: restore,
      ready: false, busy: false, profile: null, csrf: '', requests: new Set(), cached: null, touched: false, destroyed: false};
    controllers.push(controller);
    text(controller, 'Verificando a disponibilidade da escolha automática…');
    function changed(selectionChanged) {
      if (selectionChanged) controller.touched = true;
      controller.cached = null;
      if (direct(controller)) {
        option.disabled = true;
        if (select.value === AUTO) { select.value = mode(controller.profile && controller.profile.mode) || '0'; syncSelect(controller); }
        text(controller, 'NAXX Automático fica disponível para canais retransmitidos pelo servidor.');
      } else {
        option.disabled = !controller.ready;
        if (select.value === AUTO) text(controller, 'Analisa as fontes ao salvar e escolhe um modo compatível. Selecione ao menos um servidor sob demanda.');
        else if (selectionChanged && mode(select.value) !== null) text(controller, 'Modo manual selecionado: ' + labels[select.value] + '. Salve o canal para aplicar.');
      }
      busy(controller, controller.busy);
    }
    function selectChanged() { changed(true); }
    function formChanged(event) { if (event.target !== select) changed(event.target && event.target.name === 'direct_source'); }
    select.addEventListener('change', selectChanged);
    form.addEventListener('change', formChanged);
    // Select2 dispara change pelo jQuery, sem dispatchEvent nativo. Ambos os caminhos
    // atualizam apenas o estado local; a análise continua explícita e não se duplica.
    var jq = window.jQuery;
    if (jq) {
      var jqSelect = jq(select), jqForm = jq(form);
      if (jqSelect && jqForm && typeof jqSelect.on === 'function' && typeof jqForm.on === 'function') {
        jqSelect.on('change.naxxOnDemand', selectChanged);
        jqForm.on('change.naxxOnDemand', formChanged);
        controller.jqueryCleanup = function () {
          if (typeof jqSelect.off === 'function') jqSelect.off('change.naxxOnDemand');
          if (typeof jqForm.off === 'function') jqForm.off('change.naxxOnDemand');
        };
      }
    }
    form.addEventListener('input', function () { controller.cached = null; });
    analyze.addEventListener('click', function () {
      if (controller.busy || !controller.ready || select.value !== AUTO) return;
      busy(controller, true); text(controller, 'Analisando a fonte para escolher o modo de abertura…');
      plan(controller, new FormData(form)).catch(function (error) { text(controller, errorMessage(error), true); }).finally(function () { busy(controller, false); restoreNativeForm(controller); });
    });
    restore.addEventListener('click', function () {
      var previous = mode(controller.profile && controller.profile.previous_mode);
      if (controller.busy || previous === null) return;
      select.value = previous; syncSelect(controller); controller.cached = null; controller.touched = true;
      busy(controller, false); text(controller, 'Modo anterior selecionado: ' + labels[previous] + '. Salve o canal para aplicar.');
    });
    jsonRequest(controller, endpoint(controller), {}, 10000).then(function (result) {
      if (!connected(controller)) return;
      if (!result || result.ok !== true || result.feature !== 'ondemand' || typeof result.csrf !== 'string' || typeof window.submitForm !== 'function' || !window.jQuery || typeof window.jQuery.ajax !== 'function') throw new Error('unavailable');
      controller.csrf = result.csrf; controller.ready = true;
      updateProfile(controller, result.profile);
      option.disabled = direct(controller);
      if (!controller.touched && controller.profile.active && mode(controller.profile.mode) !== null && !direct(controller)) {
        select.value = AUTO; syncSelect(controller);
        text(controller, 'NAXX Automático ativo: ' + labels[String(controller.profile.mode)] + '. ' + (typeof controller.profile.reason === 'string' ? controller.profile.reason : ''));
      } else text(controller, 'Escolha NAXX Automático para analisar as fontes ao salvar. Os modos manuais continuam disponíveis.');
      busy(controller, false); ensureHook();
    }).catch(function (error) {
      if (!connected(controller)) return;
      option.disabled = true; analyze.disabled = true;
      if (error && error.message === 'session_expired') text(controller, errorMessage(error), true);
      else text(controller, 'A escolha automática ainda não está disponível neste servidor. Os modos manuais continuam disponíveis.');
    });
  }
  function enhance() {
    scheduled = 0;
    controllers.forEach(function (controller) {
      if (!controller.form.isConnected && !controller.destroyed) {
        controller.destroyed = true; controller.requests.forEach(function (request) { request.abort(); }); controller.requests.clear();
        if (controller.jqueryCleanup) controller.jqueryCleanup();
      }
    });
    controllers = controllers.filter(function (controller) { return !controller.destroyed; });
    ensureHook();
    Array.from(document.querySelectorAll('form#stream_form')).forEach(mount);
  }
  function queue() { if (!scheduled) scheduled = window.setTimeout(enhance, 0); }
  window.NaxxOnDemand = {enhance: enhance};
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () {
    enhance(); new MutationObserver(queue).observe(document.body, {childList: true, subtree: true});
  }, {once: true});
  else { enhance(); new MutationObserver(queue).observe(document.body, {childList: true, subtree: true}); }
}());

/* Acrescenta tamanhos à lista de Canais e mantém os dois controles nativos sincronizados. */
(function () {
  'use strict';
  var sizes = [['2000', '2.000'], ['5000', '5.000']];
  var bound = false;

  function controls() {
    // Filmes e séries reutilizam o ID da tabela, mas têm controles próprios.
    var mass = /\/stream_mass(?:\.php)?$/.test(window.location.pathname);
    if (!mass && !/\/streams(?:\.php)?$/.test(window.location.pathname)) return null;
    var tableId = mass ? 'datatable-mass' : 'datatable-streampage';
    var table = document.getElementById(tableId);
    var main = document.getElementById(mass ? 'show_entries' : 'stream_show_entries');
    if (!table || !main) return null;
    return {
      table: table,
      main: main,
      mass: mass,
      generated: document.querySelector('select[name="' + tableId + '_length"][aria-controls="' + tableId + '"]')
    };
  }

  function hasOption(select, value) {
    return Array.prototype.some.call(select.options, function (option) { return option.value === value; });
  }

  function extendOptions(select) {
    if (!select) return;
    sizes.forEach(function (size) {
      if (hasOption(select, size[0])) return;
      var option = document.createElement('option');
      option.value = size[0];
      option.textContent = size[1];
      select.appendChild(option);
    });
  }

  function setValue(select, value, jq) {
    if (!select || select.value === value || !hasOption(select, value)) return false;
    select.value = value;
    // Atualiza só a apresentação do Select2. O change nativo desenharia a tabela novamente.
    if (select.classList.contains('select2-hidden-accessible')) jq(select).trigger('change.select2');
    return true;
  }

  function synchronize(current, length, jq) {
    if (window.rClearing) return false;
    var value = String(length);
    setValue(current.generated, value, jq);
    return setValue(current.main, value, jq);
  }

  function bind(jq) {
    if (bound) return;
    bound = true;
    jq(document).on('init.dt.naxxStreamPageSize', '#datatable-streampage, #datatable-mass', enhance);
    jq(document).on('length.dt.naxxStreamPageSize', '#datatable-streampage, #datatable-mass', function (_event, settings, length) {
      var current = controls();
      if (!current || settings.nTable !== current.table) return;
      extendOptions(current.main);
      extendOptions(current.generated);
      var changed = synchronize(current, length, jq);
      // Quando o menu do DataTables mudou o tamanho, guarda entries como o Select2 nativo faria.
      if (changed && !current.mass && typeof window.setParam === 'function' &&
          new URLSearchParams(window.location.search).get('entries') !== String(length)) {
        window.setParam('entries', String(length));
      }
    });
  }

  function enhance() {
    var current = controls();
    if (!current) return;
    extendOptions(current.main);
    extendOptions(current.generated);
    var jq = window.jQuery;
    if (!jq || !jq.fn || !jq.fn.dataTable) return;
    bind(jq);
    if (jq.fn.dataTable.isDataTable(current.table)) {
      synchronize(current, jq(current.table).DataTable().page.len(), jq);
    }
  }

  window.NaxxStreamPageSize = {enhance: enhance};
  enhance();
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', enhance, {once: true});
}());

/* Fonte e páginas maiores da lista nativa de canais. */
(function () {
  'use strict';
  var batch = 1000, maxCatalog = 50000;
  var active = null, bound = false;

  function text(state, message) {
    state.status.textContent = message;
    state.status.hidden = !message;
  }

  function json(url, signal) {
    return window.fetch(url, {credentials: 'same-origin', cache: 'no-store', signal: signal,
      headers: {'X-Requested-With': 'XMLHttpRequest', 'Accept': 'application/json'}}).then(function (response) {
      if (!response.ok) {
        var error = new Error('request_failed');
        error.status = response.status;
        throw error;
      }
      return response.json();
    });
  }

  function sourceURL(host) {
    var url = new URL('naxx-update.php', window.location.href);
    url.searchParams.set('feature', 'stream-sources');
    if (host) url.searchParams.set('host', host);
    return url.href;
  }

  function integer(value) {
    var n = typeof value === 'number' ? value : typeof value === 'string' && /^\d+$/.test(value) ? Number(value) : NaN;
    return Number.isSafeInteger(n) && n >= 0 ? n : NaN;
  }

  function rowId(row, mass) {
    var value = Array.isArray(row) ? String(row[0]) : '';
    var id = integer(mass ? value : value.replace(/<[^>]*>/g, '').trim());
    return id > 0 ? id : NaN;
  }

  function pageStart(start, length, filtered) {
    if (start < filtered) return start;
    return filtered ? Math.floor((filtered - 1) / length) * length : 0;
  }

  async function queryPage(state, params, start, length, signal) {
    var url = new URL(state.native.url, window.location.href);
    if (url.origin !== window.location.origin || !/\/table(?:\.php)?$/.test(url.pathname)) throw new Error('native_route');
    var payload = Object.assign({}, params, {start: start, length: length});
    url.search = state.jq.param(payload);
    var page = await json(url.href, signal);
    var total = integer(page.recordsTotal), filtered = integer(page.recordsFiltered);
    if (integer(page.draw) !== integer(params.draw) || !Number.isFinite(total) || !Number.isFinite(filtered) ||
        !Array.isArray(page.data) || page.data.length !== Math.min(length, Math.max(0, filtered - start))) throw new Error('native_page');
    return {total: total, filtered: filtered, rows: page.data};
  }

  async function collect(state, params, source, signal) {
    var start = source ? 0 : integer(params.start), count = integer(params.length);
    if (!Number.isFinite(start) || !Number.isFinite(count) || count < 1 || count > 5000) throw new Error('length');
    var ids = null;
    if (source) {
      var selection = await json(sourceURL(source), signal);
      if (!selection.ok || !Array.isArray(selection.ids) || selection.ids.length > maxCatalog ||
          selection.ids.some(function (id) { return !Number.isSafeInteger(id) || id < 1; })) throw new Error('source_ids');
      ids = new Set(selection.ids);
    }
    var result = null, seen = new Set();
    do {
      var limit = source ? (ids.size ? batch : 1) : Math.min(batch, count - (result ? result.rows.length : 0));
      var page = await queryPage(state, params, start, limit, signal);
      if (!result) {
        var first = source ? 0 : pageStart(start, count, page.filtered);
        result = {total: page.total, filtered: page.filtered, rows: [], start: first};
        if (first !== start) {
          start = first;
          if (page.filtered) continue;
        }
      }
      if (result.filtered !== page.filtered || result.total !== page.total || (source && page.filtered > maxCatalog)) throw new Error('catalog_changed');
      page.rows.forEach(function (row) {
        var id = rowId(row, state.mass);
        if (!Number.isFinite(id) || seen.has(id)) throw new Error('catalog_changed');
        seen.add(id);
        if (!ids || ids.has(id)) {
          result.rows.push(row);
          if (ids) ids.delete(id);
        }
      });
      start += page.rows.length;
      if (start >= page.filtered || !page.rows.length || (ids ? !ids.size : result.rows.length >= count)) break;
    } while (true);
    if (source) result.filtered = result.rows.length;
    return result;
  }

  function signature(params, source) {
    var filters = Object.assign({}, params);
    delete filters.start; delete filters.length; delete filters.draw;
    return JSON.stringify([source, filters]);
  }

  // Reusa a mesma consulta nativa da tabela, inclusive categoria, servidor e busca.
  // A seleção só recebe IDs depois que todos os lotes foram validados.
  async function filteredIds(table, signal) {
    var state = active;
    if (!state || state.table !== table || !table.isConnected || !state.api.ajax.params) throw new Error('table_unavailable');
    var params = state.api.ajax.params();
    if (!params || state.request || state.requested) throw new Error('table_loading');
    params = JSON.parse(JSON.stringify(params));
    state.native.data(params, state.settings);
    var source = state.source, key = signature(params, source), rows = [], seen = new Set(), total, filtered;
    if (source) rows = (await collect(state, Object.assign({}, params, {start: 0, length: batch}), source, signal)).rows;
    else {
      for (var start = 0; ; start += batch) {
        var page = await queryPage(state, params, start, batch, signal);
        if (page.filtered > maxCatalog) throw new Error('catalog_limit');
        if (start && (total !== page.total || filtered !== page.filtered)) throw new Error('catalog_changed');
        total = page.total; filtered = page.filtered;
        rows = rows.concat(page.rows);
        if (rows.length >= filtered) break;
      }
    }
    var ids = rows.map(function (row) {
      var id = rowId(row, state.mass);
      if (!Number.isFinite(id) || seen.has(id)) throw new Error('catalog_changed');
      seen.add(id); return String(id);
    });
    var current = state.api.ajax.params();
    if (signal.aborted || active !== state || !table.isConnected || state.request || !current) throw new Error('selection_changed');
    current = JSON.parse(JSON.stringify(current)); state.native.data(current, state.settings);
    if (signature(current, state.source) !== key) throw new Error('selection_changed');
    return ids;
  }

  function useAjax(state, length) {
    var replacement = state.source || Number(length) > batch;
    if (!replacement && state.settings.ajax === state.ajax) {
      abort(state);
      text(state, '');
    }
    state.settings.ajax = replacement ? state.ajax : state.native;
  }

  function abort(state) {
    if (state.request) state.request.abort();
    state.request = null;
  }

  function runAjax(state, data, callback) {
    abort(state);
    state.native.data(data, state.settings);
    var source = state.source, start = integer(data.start), length = integer(data.length);
    var controller = new AbortController(), timedOut = false;
    var request = {readyState: 1, abort: function () { controller.abort(); request.readyState = 0; }};
    state.request = request;
    var timer = window.setTimeout(function () { timedOut = true; controller.abort(); }, 45000);
    var key = signature(data, source), cached = state.cache;
    var reuse = source && cached && cached.key === key && cached.expires > Date.now() &&
      (cached.start !== start || cached.length !== length);
    text(state, source ? 'Buscando canais da fonte…' : 'Carregando a página de canais…');
    var loading = reuse ? Promise.resolve(cached.result) : collect(state, data, source, controller.signal);
    loading.then(function (result) {
      if (state.request !== request || controller.signal.aborted || !state.table.isConnected) return;
      var first = source ? pageStart(start, length, result.filtered) : result.start;
      if (first !== start) {
        // O DataTables usa o offset interno para numerar a página após o callback.
        state.settings._iDisplayStart = first;
        data.start = first;
      }
      if (source) state.cache = {key: key, result: result, start: first, length: length, expires: reuse ? cached.expires : Date.now() + 15000};
      text(state, '');
      callback({draw: integer(data.draw), recordsTotal: result.total, recordsFiltered: result.filtered,
        data: source ? result.rows.slice(first, first + length) : result.rows});
    }, function () {
      if (state.request !== request || (!timedOut && controller.signal.aborted) || !state.table.isConnected) return;
      state.cache = null;
      text(state, 'Não foi possível carregar os canais. Atualize a lista e tente novamente.');
      callback({draw: integer(data.draw), recordsTotal: 0, recordsFiltered: 0, data: []});
    }).finally(function () {
      window.clearTimeout(timer);
      request.readyState = 4;
      if (state.request === request) state.request = null;
    });
    return request;
  }

  function setURL(host) {
    if (host && typeof window.setParam === 'function') window.setParam('naxx_source', host);
    else if (!host && typeof window.delParam === 'function') window.delParam('naxx_source');
    else {
      var url = new URL(window.location.href);
      if (host) url.searchParams.set('naxx_source', host); else url.searchParams.delete('naxx_source');
      window.history.replaceState(window.history.state, '', url.href);
    }
  }

  function choose(state, source, redraw, resetPaging) {
    var pending = state.requested;
    state.requested = '';
    if (state.source === source) {
      if (pending) { setURL(source); text(state, ''); }
      return;
    }
    abort(state);
    state.source = source;
    state.cache = null;
    state.select.value = source;
    if (state.select.classList.contains('select2-hidden-accessible')) state.jq(state.select).trigger('change.select2');
    setURL(source);
    useAjax(state, state.api.page.len());
    text(state, '');
    if (redraw) {
      if (typeof window.checkClear === 'function') window.checkClear();
      state.api.ajax.reload(null, resetPaging !== false);
    }
  }

  function wrap(state, name, make) {
    var original = window[name];
    if (typeof original !== 'function') return;
    var previous = state.wrappers[name];
    if (previous && previous.replacement === original) return;
    var replacement = make(original);
    state.wrappers[name] = {original: original, replacement: replacement};
    window[name] = replacement;
  }

  function hooks(state) {
    wrap(state, 'clearFilters', function (original) { return function () {
      choose(state, '', false);
      return original.apply(this, arguments);
    }; });
    wrap(state, 'checkClear', function (original) { return function () {
      var result = original.apply(this, arguments), button = document.getElementById('clearFilters');
      if ((state.source || state.requested) && button) button.disabled = false;
      return result;
    }; });
    // Um timer da página anterior pode disparar depois de selecionar 5.000.
    wrap(state, 'getStreamIDs', function (original) { return function () {
      if (state.mass || !state.table.isConnected || state.api.rows().count() > 50) return [[], []];
      return original.apply(this, arguments);
    }; });
  }

  function destroy(state) {
    abort(state); state.list.abort();
    state.jq(state.table).off('.naxxStreamTable');
    state.jq(state.select).off('.naxxStreamTable');
    if (state.select.classList.contains('select2-hidden-accessible')) state.jq(state.select).select2('destroy');
    if (state.settings.ajax === state.ajax) state.settings.ajax = state.native;
    Object.keys(state.wrappers).forEach(function (name) {
      var binding = state.wrappers[name];
      if (window[name] === binding.replacement) window[name] = binding.original;
    });
    state.filters.classList.remove('naxx-stream-source-filters');
    state.box.remove(); state.status.remove();
  }

  function addOption(select, value, label) {
    var option = document.createElement('option');
    option.value = value; option.textContent = label; select.appendChild(option);
  }

  function mount(table, filters, jq, api, settings, initializing, mass) {
    var native = settings.ajax;
    if (!native || typeof native.url !== 'string' || typeof native.data !== 'function') return;
    var box = document.createElement('div'), select = document.createElement('select'), status = document.createElement('p');
    box.className = 'naxx-stream-source-control'; box.hidden = true;
    select.className = 'form-control'; select.id = 'naxx-stream-source';
    select.setAttribute('aria-label', 'Filtrar canais por fonte');
    addOption(select, '', 'Todas as fontes'); box.appendChild(select);
    var category = document.getElementById(mass ? 'category_search' : 'stream_category_id');
    if (category && category.parentElement.parentElement === filters) category.parentElement.after(box); else filters.appendChild(box);
    status.className = 'naxx-stream-source-status text-muted'; status.hidden = true;
    status.setAttribute('role', 'status'); filters.after(status);
    var state = {table: table, filters: filters, api: api, settings: settings, native: native, jq: jq,
      box: box, select: select, status: status, source: '', request: null, cache: null,
      mass: mass, list: new AbortController(), wrappers: {}, requested: new URLSearchParams(window.location.search).get('naxx_source') || ''};
    state.ajax = function (data, callback) { return runAjax(state, data, callback); };
    active = state;
    jq(table).on('length.dt.naxxStreamTable', function (_event, eventSettings, length) {
      if (eventSettings === settings) useAjax(state, length);
    });
    jq(table).on('destroy.dt.naxxStreamTable', function (_event, eventSettings) {
      if (eventSettings !== settings || active !== state) return;
      active = null;
      destroy(state);
    });
    hooks(state);
    useAjax(state, api.page.len());
    if (state.requested && typeof window.checkClear === 'function') window.checkClear();
    if (!initializing && api.page.len() > batch) api.ajax.reload(null, false);
    json(sourceURL(''), state.list.signal).then(function (result) {
      if (active !== state || !table.isConnected) return;
      if (!result || !result.ok || !Array.isArray(result.hosts)) throw new Error('source_hosts');
      var hosts = result.hosts.filter(function (host) { return typeof host === 'string' && host.length && host.length <= 253; });
      hosts.forEach(function (host) { addOption(select, host, host); });
      if (!hosts.length) select.disabled = true;
      box.hidden = false;
      filters.classList.add('naxx-stream-source-filters');
      if (jq.fn.select2) jq(select).select2({width: '100%'});
      jq(select).on('change.naxxStreamTable', function () { choose(state, select.value, true); });
      if (state.requested && hosts.indexOf(state.requested) !== -1) choose(state, state.requested, true, false);
      else if (state.requested) {
        choose(state, '', false);
        if (typeof window.checkClear === 'function') window.checkClear();
        text(state, 'A fonte do endereço já não está disponível.');
      }
    }).catch(function (error) {
      if (active !== state || !table.isConnected) return;
      if (error && error.status === 413) text(state, 'O filtro de fonte aceita catálogos com até 50.000 canais ao vivo.');
      else if (state.requested || !error || error.status !== 403) text(state, 'Não foi possível carregar as fontes. Atualize a lista ou limpe o filtro.');
    });
  }

  function enhance(initializing) {
    var mass = /\/stream_mass(?:\.php)?$/.test(window.location.pathname);
    var tableId = mass ? 'datatable-mass' : 'datatable-streampage';
    var table = mass || /\/streams(?:\.php)?$/.test(window.location.pathname) ? document.getElementById(tableId) : null;
    var panel = table && document.getElementById('stream-selection');
    var filters = table && (mass ? panel && panel.querySelector('.row') : document.getElementById('collapse_filters')), jq = window.jQuery;
    if (active && (active.table !== table || active.filters !== filters || !table || !table.isConnected)) {
      destroy(active); active = null;
    }
    if (!jq || !jq.fn || !jq.fn.dataTable) return;
    if (!bound) {
      bound = true;
      jq(document).on('preInit.dt.naxxStreamTable', '#datatable-streampage, #datatable-mass', function (_event, settings) { enhance(settings); });
      jq(document).on('init.dt.naxxStreamTable', '#datatable-streampage, #datatable-mass', function () { enhance(); });
      document.addEventListener('click', function (event) {
        if (!active || (!active.source && !active.requested) || !active.table.isConnected || !event.target.closest('#btn-export-csv')) return;
        event.preventDefault(); event.stopImmediatePropagation();
        text(active, 'Limpe o filtro de fonte antes de exportar o CSV.');
      }, true);
    }
    if (!table || !filters || !jq.fn.dataTable.isDataTable(table)) return;
    var api = jq(table).DataTable(), settings = api.settings()[0];
    if (active && active.settings !== settings) { destroy(active); active = null; }
    if (active) { hooks(active); return; }
    if (settings && (settings._bInitComplete || settings === initializing)) mount(table, filters, jq, api, settings, settings === initializing, mass);
  }

  window.NaxxStreamSources = {enhance: enhance, filteredIds: filteredIds};
  enhance();
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { enhance(); }, {once: true});
}());

/* Seleção por página ou por resultado completo no rascunho nativo de listas. */
(function () {
  'use strict';
  if (window.NaxxBouquetSelection) { window.NaxxBouquetSelection.enhance(); return; }

  var tables = {
    'datatable-stream': {type: 'stream', label: 'Canais', query: 'bouquets_streams', category: 'category_id', search: 'stream_search'},
    'datatable-movies': {type: 'movies', label: 'Filmes', query: 'bouquets_vod', category: 'category_idv', search: 'vod_search'},
    'datatable-series': {type: 'series', label: 'Séries', query: 'bouquets_series', category: 'category_ids', search: 'series_search'},
    'datatable-radios': {type: 'radios', label: 'Rádio', query: 'bouquets_radios', category: 'category_idr', search: 'radios_search'}
  };
  var states = new Map();
  var observedForm = null;
  var observer = null;
  var bound = false;
  var frame = null;
  var bulk = null;
  var lazySettings = null;
  var names = new Map();
  var batchSize = 1000;

  function count(value) { return value.toLocaleString('pt-BR'); }

  function integer(value) {
    if (typeof value !== 'number' && (typeof value !== 'string' || !/^\d+$/.test(value))) return null;
    var number = Number(value);
    return Number.isSafeInteger(number) && number >= 0 ? number : null;
  }

  // Preserve callbacks while copying public DataTables configuration/parameters.
  function copy(value) {
    if (Array.isArray(value)) return value.map(copy);
    if (value && Object.prototype.toString.call(value) === '[object Object]') {
      var result = {};
      Object.keys(value).forEach(function (key) {
        if (key !== '__proto__' && key !== 'constructor' && key !== 'prototype') result[key] = copy(value[key]);
      });
      return result;
    }
    return value;
  }

  function sourceTable(state) {
    var jq = window.jQuery;
    return jq && jq.fn.dataTable.isDataTable(state.table) ? jq(state.table).DataTable() : null;
  }

  function filterValue(id) {
    var control = document.getElementById(id);
    return control ? String(control.value || '') : '';
  }

  function allScope(state) {
    try {
      var api = sourceTable(state);
      if (!api || !api.ajax || typeof api.ajax.params !== 'function' || typeof api.ajax.url !== 'function') return null;
      var params = copy(api.ajax.params());
      var info = api.page.info();
      var total = integer(info.recordsDisplay);
      var records = integer(info.recordsTotal);
      if (!params || params.id !== state.definition.query || total === null || records === null || total > records) return null;
      var signature = copy(params);
      ['draw', 'start', 'length', 'order'].forEach(function (key) { delete signature[key]; });
      var url = api.ajax.url();
      if (typeof url !== 'string' || !url) return null;
      return {params: params, total: total, records: records, url: url,
        key: JSON.stringify([url, signature, filterValue(state.definition.category), filterValue(state.definition.search)])};
    } catch (_error) { return null; }
  }

  function unchanged(job) {
    if (window.rBouquet !== job.model || document.getElementById('bouquet_form') !== job.form ||
        document.getElementById(job.table.id) !== job.table ||
        document.getElementById('datatable-review') !== job.reviewTable ||
        !job.form.isConnected || !job.form.contains(job.table)) return false;
    var scope = allScope(job.state);
    return job.state.table.isConnected && scope && scope.key === job.scope.key &&
      scope.total === job.scope.total && scope.records === job.scope.records;
  }

  function escapeHTML(value) {
    return String(value).replace(/[&<>"']/g, function (character) {
      return {'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'}[character];
    });
  }

  function reviewRow(id, type, name) {
    var row = [id, type.charAt(0).toUpperCase() + type.slice(1), escapeHTML(name),
      '<button type="button" class="btn-remove btn btn-warning waves-effect waves-warning btn-xs" ' +
      'onClick="toggleBouquet(' + id + ', \'' + type + '\');"><i class="mdi mdi-minus"></i></button>'];
    row.DT_RowId = type + '-' + id;
    return row;
  }

  function rowCopy(data) {
    if (!Array.isArray(data) || data.length !== 4) throw new Error('review_contract');
    var id = integer(data[0]);
    var type = String(data[1]).toLowerCase();
    if (!id || !Object.keys(tables).some(function (key) { return tables[key].type === type; })) throw new Error('review_contract');
    var row = data.slice();
    row.DT_RowId = type + '-' + id;
    return row;
  }

  function visibleName(id, type) {
    var table = document.getElementById('datatable-' + type);
    var row = table && table.querySelector('#' + type + '-' + id);
    return row && row.children[1] ? row.children[1].textContent : names.get(type + '-' + id) || '';
  }

  // Native addRow requires an immediate DOM node. With rowId metadata, native
  // delRow keeps finding even off-page rows while Review creates only its page.
  function lazyReview() {
    var api = review();
    var table = document.getElementById('datatable-review');
    if (lazySettings && lazySettings.table === table) return api;
    var rows = api.rows().data().toArray().map(rowCopy);
    var config = copy(api.init());
    var info = api.page.info();
    config.data = rows;
    delete config.aaData;
    config.deferRender = true;
    config.rowId = 'DT_RowId';
    config.order = copy(api.order());
    config.search = copy(config.search || {});
    config.search.search = api.search();
    config.pageLength = info.length;
    config.displayStart = info.start;
    if (typeof api.columns === 'function') {
      var priorSearches = config.searchCols || [];
      config.searchCols = api.columns().search().toArray().map(function (search, index) {
        var options = copy(priorSearches[index] || {});
        options.search = search;
        return options;
      });
    }
    api.destroy(false);
    try {
      api = window.jQuery(table).DataTable(config);
    } catch (error) {
      // Rebuild the same draft even if initialization fails midway.
      try {
        var damaged = review();
        if (damaged) damaged.destroy(false);
        var fallback = copy(config);
        fallback.deferRender = false;
        window.jQuery(table).DataTable(fallback);
      } catch (_restoreError) { /* The outer operation reports failure. */ }
      throw error;
    }
    lazySettings = {table: table};
    window.addRow = function (raw, type) {
      var id = integer(raw);
      if (!id || !Object.keys(tables).some(function (key) { return tables[key].type === type; })) return;
      review().row.add(reviewRow(id, type, visibleName(id, type)));
    };
    return api;
  }

  function lock(job) {
    job.controls = Array.prototype.map.call(job.form.querySelectorAll('button,input,select,textarea'), function (control) {
      var prior = control.disabled;
      if (control !== job.state.cancel) control.disabled = true;
      return [control, prior];
    });
  }

  function unlock(job) {
    (job.controls || []).forEach(function (entry) { if (entry[0].isConnected) entry[0].disabled = entry[1]; });
  }

  function repaintVisible(state) {
    var selection = selected(state.type);
    Array.prototype.forEach.call(state.table.querySelectorAll('tbody .btn-add[data-id][data-type],tbody .btn-remove[data-id][data-type]'), function (button) {
      var id = integer(button.getAttribute('data-id'));
      if (!id || button.getAttribute('data-type') !== state.type || button.closest('table') !== state.table) return;
      var add = button.className.split(/\s+/).indexOf('btn-add') !== -1;
      button.style.display = selection.has(id) === add ? 'none' : '';
    });
  }

  function updateJob(job, message) {
    job.message = message;
    states.forEach(refresh);
  }

  function cancelBulk(reason) {
    if (!bulk) return;
    bulk.cancelled = reason || 'cancelled';
    if (bulk.xhr && typeof bulk.xhr.abort === 'function') bulk.xhr.abort();
    updateJob(bulk, 'Cancelando seleção…');
  }

  function check(job) {
    if (job.cancelled) throw new Error(job.cancelled);
    if (!unchanged(job)) throw new Error('changed');
  }

  function tick() { return new Promise(function (resolve) { window.setTimeout(resolve, 0); }); }

  function requestPage(job, params, url) {
    return new Promise(function (resolve, reject) {
      job.xhr = window.jQuery.ajax({url: url, type: 'GET', data: params, dataType: 'json', timeout: 30000,
        success: function (response) { job.xhr = null; resolve(response); },
        error: function () { job.xhr = null; reject(new Error(job.cancelled || 'network')); }});
    });
  }

  async function applyAll(state) {
    if (bulk || state.busy || state.loading || !nativeReady(state) || !visible(state.table)) return;
    var scope = allScope(state);
    if (!scope || !scope.total) return;
    var job = {state: state, scope: scope, model: window.rBouquet,
      form: document.getElementById('bouquet_form'), table: state.table,
      reviewTable: document.getElementById('datatable-review'),
      phase: 'collecting', message: '', cancelled: '', xhr: null};
    var snapshot = null;
    var selection = job.model[state.type].slice();
    var api = null;
    var committed = false;
    var modelPublished = false;
    bulk = job;
    state.notice = '';
    lock(job);
    updateJob(job, 'Buscando 0 de ' + count(scope.total) + ' itens…');
    try {
      // Only the native same-origin table endpoint is allowed. Source/media
      // URLs in row data are never opened or used as request destinations.
      var url = new URL(scope.url, window.location.href);
      if (url.origin !== window.location.origin || !/^https?:$/.test(url.protocol) ||
          !/\/table(?:\.php)?$/.test(url.pathname) || url.username || url.password || url.hash) throw new Error('endpoint');
      var collected = [];
      var previous = 0;
      var offset = 0;
      var draw = integer(scope.params.draw) || 0;
      while (offset < scope.total) {
        check(job);
        var params = copy(scope.params);
        params.start = offset;
        params.length = batchSize;
        params.order = [{column: 0, dir: 'asc'}];
        params.draw = ++draw;
        var response = await requestPage(job, params, url.href);
        check(job);
        if (!response || response.error || integer(response.recordsFiltered) !== scope.total ||
            integer(response.recordsTotal) !== scope.records || !Array.isArray(response.data) ||
            !response.data.length || response.data.length > batchSize ||
            (response.draw !== undefined && integer(response.draw) !== params.draw) ||
            offset + response.data.length > scope.total) throw new Error('response');
        response.data.forEach(function (row) {
          var id = Array.isArray(row) && row.length === 4 ? integer(row[0]) : null;
          if (!id || id <= previous || typeof row[1] !== 'string' || typeof row[3] !== 'string') throw new Error('response');
          previous = id;
          collected.push({id: id, name: row[1]});
        });
        // Servers may cap length below the requested batch size.
        offset += response.data.length;
        updateJob(job, 'Buscando ' + count(offset) + ' de ' + count(scope.total) + ' itens…');
      }
      check(job);
      var present = new Set(selection.map(Number));
      var additions = collected.filter(function (item) { return !present.has(item.id); });
      if (!additions.length) {
        state.notice = 'Todos os ' + count(scope.total) + ' itens já estão selecionados.';
        return;
      }
      job.phase = 'applying';
      api = lazyReview();
      snapshot = api.rows().data().toArray().map(rowCopy);
      for (var start = 0; start < additions.length; start += batchSize) {
        check(job);
        api.rows.add(additions.slice(start, start + batchSize).map(function (item) { return reviewRow(item.id, state.type, item.name); }));
        updateJob(job, 'Selecionando ' + count(Math.min(start + batchSize, additions.length)) + ' de ' + count(additions.length) + ' itens…');
        await tick();
      }
      check(job);
      // Publish the native draft only after every page and Review batch passed.
      job.model[state.type] = selection.concat(additions.map(function (item) { return item.id; }));
      modelPublished = true;
      api.draw(false);
      additions.forEach(function (item) { names.set(state.type + '-' + item.id, item.name); });
      committed = true;
      state.notice = count(additions.length) + (additions.length === 1 ? ' item selecionado.' : ' itens selecionados.');
    } catch (error) {
      if (snapshot && api) {
        if (modelPublished) job.model[state.type] = selection;
        // One linear restore avoids removing hundreds of thousands of rows
        // individually, which would repeatedly reindex the complete table.
        try { api.clear(); api.rows.add(snapshot); api.draw(false); }
        catch (_restoreError) { state.notice = 'Não foi possível restaurar a revisão. Recarregue a página antes de salvar.'; }
      }
      if (!state.notice) state.notice = error.message === 'cancelled' ? 'Seleção cancelada. O rascunho foi preservado.' :
        error.message === 'changed' ? 'Busca ou categoria alterada. O rascunho foi preservado.' :
        'Não foi possível selecionar todos os itens. O rascunho foi preservado; tente novamente.';
    } finally {
      if (!committed && modelPublished) job.model[state.type] = selection;
      bulk = null;
      unlock(job);
      if (committed) repaintVisible(state);
      states.forEach(refresh);
    }
  }

  function visible(element) {
    if (!element || !element.isConnected || element.hidden || !element.getClientRects().length) return false;
    var style = window.getComputedStyle(element);
    return style.display !== 'none' && style.visibility !== 'hidden' && style.visibility !== 'collapse';
  }

  function selected(type) {
    if (!window.rBouquet || !Array.isArray(window.rBouquet[type])) return null;
    return new Set(window.rBouquet[type].map(Number));
  }

  function review() {
    var jq = window.jQuery;
    var table = document.getElementById('datatable-review');
    if (!jq || !jq.fn || !jq.fn.dataTable || typeof jq.fn.dataTable.isDataTable !== 'function' ||
        !table || !jq.fn.dataTable.isDataTable(table)) return null;
    return jq(table).DataTable();
  }

  function nativeReady(state) {
    return typeof window.toggleBouquet === 'function' && window.rBouquet &&
      Array.isArray(window.rBouquet[state.type]) && review() !== null;
  }

  function items(state, mode, selection) {
    if (!visible(state.table)) return [];
    selection = selection || selected(state.type);
    if (!selection) return [];
    var seen = new Set();
    var selector = mode === 'add' ? '.btn-add[data-id][data-type]' :
      mode === 'remove' ? '.btn-remove[data-id][data-type]' : '.btn-add[data-id][data-type],.btn-remove[data-id][data-type]';
    return Array.prototype.filter.call(state.table.querySelectorAll('tbody ' + selector.split(',').join(',tbody ')), function (button) {
      var raw = button.getAttribute('data-id');
      var id = Number(raw);
      if (button.closest('table') !== state.table || button.getAttribute('data-type') !== state.type ||
          !/^[1-9]\d*$/.test(raw || '') || !Number.isSafeInteger(id) ||
          button.disabled || button.getAttribute('aria-disabled') === 'true' || !visible(button) || seen.has(id)) return false;
      if (mode === 'add' && selection.has(id) || mode === 'remove' && !selection.has(id)) return false;
      seen.add(id);
      return true;
    });
  }

  function text(element, value) {
    if (element.textContent !== value) element.textContent = value;
  }

  function refresh(state) {
    if (bulk) {
      state.add.disabled = state.remove.disabled = state.all.disabled = true;
      var current = bulk.state === state;
      if (state.cancel.hidden !== !current) state.cancel.hidden = !current;
      state.cancel.disabled = false;
      if (current) text(state.status, bulk.message);
      return;
    }
    if (!state.cancel.hidden) state.cancel.hidden = true;
    var ready = nativeReady(state);
    var selection = visible(state.table) ? selected(state.type) : null;
    var adds = items(state, 'add', selection);
    var removes = items(state, 'remove', selection);
    var total = items(state, null, selection).length;
    var unavailable = state.busy || state.loading || !ready || !visible(state.table);
    state.add.disabled = unavailable || adds.length === 0;
    state.remove.disabled = unavailable || removes.length === 0;
    var scope = allScope(state);
    state.all.disabled = unavailable || !scope || scope.total === 0;
    text(state.all, 'Selecionar tudo' + (scope && scope.total ? ' (' + count(scope.total) + ')' : ''));
    text(state.add, 'Selecionar visíveis' + (adds.length ? ' (' + adds.length + ')' : ''));
    text(state.remove, 'Desmarcar visíveis' + (removes.length ? ' (' + removes.length + ')' : ''));
    var status = state.busy ? 'Atualizando seleção…' : state.loading || !ready ? 'Carregando itens…' :
      total + (total === 1 ? ' item nesta página' : ' itens nesta página') + ' · ' + removes.length +
        (removes.length === 1 ? ' selecionado.' : ' selecionados.');
    text(state.status, state.notice ? state.notice + ' ' + status : status);
  }

  function apply(state, mode) {
    if (bulk || state.busy || state.loading || !nativeReady(state) || !visible(state.table)) return;
    var buttons = items(state, mode);
    if (!buttons.length) return;
    state.busy = true;
    state.notice = '';
    refresh(state);
    var changed = 0;
    var failed = false;
    try {
      buttons.forEach(function (button) {
        var id = Number(button.getAttribute('data-id'));
        var values = window.rBouquet && window.rBouquet[state.type];
        // A callback nativa pode redesenhar/ocultar uma linha. Nunca inverta
        // novamente um item que já atingiu o estado solicitado.
        if (!Array.isArray(values) || !visible(button) || (mode === 'add') === values.some(function (value) { return Number(value) === id; })) return;
        window.toggleBouquet(id, state.type, false);
        var after = window.rBouquet && window.rBouquet[state.type];
        if (Array.isArray(after) && after.some(function (value) { return Number(value) === id; }) === (mode === 'add')) changed++;
        else throw new Error('selection_not_confirmed');
      });
    } catch (_error) {
      failed = true;
    } finally {
      try {
        // Cada toggle atualiza o rascunho e as linhas da revisão nativa;
        // desenhar uma única vez evita redesenhar a lista inteira a cada item.
        if (changed) review().draw(false);
      } catch (_error) { failed = true; }
      state.busy = false;
      state.notice = failed ? 'A seleção foi parcialmente atualizada. Confira os itens antes de salvar.' :
        changed + (changed === 1 ? ' item ' : ' itens ') + (mode === 'add' ?
          (changed === 1 ? 'selecionado.' : 'selecionados.') : (changed === 1 ? 'desmarcado.' : 'desmarcados.'));
      refresh(state);
    }
  }

  function create(table, definition) {
    var box = document.createElement('div');
    box.className = 'naxx-bouquet-selection mb-3';
    box.setAttribute('role', 'group');
    box.setAttribute('aria-label', 'Seleção dos itens visíveis: ' + definition.label);
    var actions = document.createElement('div');
    actions.className = 'd-flex flex-wrap align-items-center';
    actions.style.gap = '8px';
    var add = document.createElement('button');
    add.type = 'button'; add.className = 'btn btn-outline-primary btn-sm';
    add.setAttribute('aria-controls', table.id);
    var remove = document.createElement('button');
    remove.type = 'button'; remove.className = 'btn btn-outline-secondary btn-sm';
    remove.setAttribute('aria-controls', table.id);
    var all = document.createElement('button');
    all.type = 'button'; all.className = 'btn btn-primary btn-sm';
    all.setAttribute('aria-controls', table.id);
    all.setAttribute('data-naxx-bouquet-all', definition.type);
    var cancel = document.createElement('button');
    cancel.type = 'button'; cancel.className = 'btn btn-outline-secondary btn-sm';
    cancel.textContent = 'Cancelar'; cancel.hidden = true;
    var status = document.createElement('span');
    status.className = 'text-muted small';
    status.setAttribute('role', 'status'); status.setAttribute('aria-live', 'polite');
    var help = document.createElement('div');
    help.className = 'text-muted small mt-2';
    help.textContent = 'Visíveis: página atual. Tudo: todos os resultados da busca e categoria. Salve a lista para gravar as alterações.';
    actions.appendChild(add); actions.appendChild(remove); actions.appendChild(status);
    actions.appendChild(all); actions.appendChild(cancel);
    box.appendChild(actions); box.appendChild(help);
    var target = table.closest('.dataTables_wrapper') || table;
    target.parentNode.insertBefore(box, target);
    var state = {table: table, type: definition.type, definition: definition, box: box, add: add, remove: remove,
      all: all, cancel: cancel, status: status, busy: false, loading: false, notice: ''};
    add.addEventListener('click', function (event) { event.preventDefault(); apply(state, 'add'); });
    remove.addEventListener('click', function (event) { event.preventDefault(); apply(state, 'remove'); });
    all.addEventListener('click', function (event) { event.preventDefault(); return applyAll(state); });
    cancel.addEventListener('click', function (event) { event.preventDefault(); cancelBulk(); });
    return state;
  }

  function schedule() {
    if (frame !== null) return;
    frame = window.requestAnimationFrame(function () { frame = null; enhance(); });
  }

  function bind() {
    var jq = window.jQuery;
    if (bound || !jq || !jq.fn || !jq.fn.dataTable) return;
    bound = true;
    jq(document).on('draw.dt.naxxBouquetSelection init.dt.naxxBouquetSelection', 'table', function () {
      var state = states.get(this);
      if (state) { state.loading = false; state.notice = ''; }
      schedule();
    });
    jq(document).on('processing.dt.naxxBouquetSelection', 'table', function (_event, _settings, processing) {
      var state = states.get(this);
      if (state) {
        if (bulk && bulk.state === state && processing) cancelBulk('changed');
        state.loading = Boolean(processing); refresh(state);
      }
    });
    jq(document).on('shown.bs.tab.naxxBouquetSelection', schedule);
  }

  function enhance() {
    if (!/\/bouquet(?:\.php)?$/.test(window.location.pathname)) {
      if (bulk) cancelBulk('changed');
      if (observer) observer.disconnect();
      observedForm = null;
      states.forEach(function (state) { state.box.remove(); });
      states.clear();
      return;
    }
    var form = document.getElementById('bouquet_form');
    if (!form) return;
    bind();
    states.forEach(function (state, table) {
      if (!table.isConnected || !form.contains(table)) { state.box.remove(); states.delete(table); }
    });
    Object.keys(tables).forEach(function (id) {
      var table = document.getElementById(id);
      if (!table || !form.contains(table)) return;
      var state = states.get(table);
      if (!state) { state = create(table, tables[id]); states.set(table, state); }
      refresh(state);
    });
    if (observedForm !== form && typeof MutationObserver === 'function') {
      if (observer) observer.disconnect();
      observer = new MutationObserver(schedule);
      observer.observe(form, {childList: true, subtree: true, attributes: true, attributeFilter: ['style', 'class', 'hidden']});
      observedForm = form;
      form.addEventListener('submit', function (event) {
        if (bulk) { event.preventDefault(); event.stopImmediatePropagation(); }
      }, true);
      form.addEventListener('click', function (event) {
        if (bulk && !bulk.state.cancel.contains(event.target)) { event.preventDefault(); event.stopImmediatePropagation(); }
      }, true);
      ['change', 'input'].forEach(function (name) {
        form.addEventListener(name, function () { if (bulk) cancelBulk('changed'); }, true);
      });
    }
  }

  window.NaxxBouquetSelection = {enhance: enhance};
  enhance();
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', enhance, {once: true});
}());

/* Editor de ordem: o formulário e o salvamento continuam sendo os nativos. */
(function () {
  'use strict';
  if (window.NaxxBouquetOrder) { window.NaxxBouquetOrder.enhance(); return; }

  var definitions = [
    {type: 'stream', panel: 'bouquet-stream', label: 'Canais'},
    {type: 'movie', panel: 'bouquet-movie', label: 'Filmes'},
    {type: 'series', panel: 'bouquet-series', label: 'Séries'},
    {type: 'radio', panel: 'bouquet-stations', label: 'Rádio'}
  ];
  var pageSize = 100;
  var historyLimit = 10;
  var collator = new Intl.Collator('pt-BR', {numeric: true, sensitivity: 'base'});
  var formatter = new Intl.NumberFormat('pt-BR');
  var active = null;
  var observer = null;
  var pending = null;

  function isOrderPage() { return /\/bouquet_sort(?:\.php)?$/.test(window.location.pathname); }
  function count(value) { return formatter.format(value); }
  function normalize(value) { return String(value).normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLocaleLowerCase('pt-BR'); }
  function equal(a, b) {
    if (a.length !== b.length) return false;
    for (var i = 0; i < a.length; i++) if (a[i] !== b[i]) return false;
    return true;
  }
  function element(tag, className, text) {
    var node = document.createElement(tag);
    if (className) node.className = className;
    if (text !== undefined) node.textContent = text;
    return node;
  }
  function button(text, action, className) {
    var node = element('button', 'naxx-order-button' + (className ? ' ' + className : ''), text);
    node.type = 'button';
    node.setAttribute('data-order-action', action);
    return node;
  }
  function readState(definition, form) {
    var panel = document.getElementById(definition.panel);
    var left = document.getElementById('sort_' + definition.type + '_l');
    var right = document.getElementById('sort_' + definition.type + '_r');
    if (!panel || !left || !right || left.form !== form || right.form !== form || !panel.contains(left) || !panel.contains(right)) return null;
    var leftOptions = Array.from(left.options), rightOptions = Array.from(right.options);
    if (leftOptions.length !== rightOptions.length) return null;
    var entries = [];
    for (var i = 0; i < leftOptions.length; i++) {
      var option = leftOptions[i], mirror = rightOptions[i];
      if (option.value !== mirror.value || option.text !== mirror.text) return null;
      var name = option.text.trim() || 'Sem nome' + (option.value ? ' · ID ' + option.value : '');
      entries.push({key: i, value: option.value, text: option.text, name: name,
        search: normalize(name + ' ' + option.value), left: option, right: mirror});
    }
    var order = entries.map(function (entry) { return entry.key; });
    return {definition: definition, panel: panel, left: left, right: right, entries: entries,
      order: order, nativeOrder: order.slice(), initial: order.slice(), selected: new Set(),
      undo: [], redo: [], query: '', page: 0, matches: null, changed: 0, dragKeys: null};
  }
  function matches(state) {
    if (state.matches) return state.matches;
    state.matches = [];
    state.order.forEach(function (key, index) {
      if (!state.query || state.entries[key].search.includes(state.query)) state.matches.push({key: key, index: index});
    });
    return state.matches;
  }
  function refreshFilter(state) {
    window.clearTimeout(state.searchTimer);
    var query = normalize(state.search.value.trim());
    if (query === state.query) return;
    state.query = query; state.page = 0; state.matches = null; render(state, true);
  }
  function announce(state, text) { state.notice.textContent = text; }
  function isSaving(editor) {
    // The native failure callback enables submit buttons. Respect that unlock,
    // including when the user retries before the attribute observer has run.
    if (editor.submitting && !editor.save.disabled) {
      editor.submitting = false;
      editor.form.removeAttribute('aria-busy');
    }
    return Boolean(editor.submitting);
  }
  function updateGlobal(editor) {
    var types = editor.states.filter(function (state) { return state.changed > 0; });
    var changed = editor.states.reduce(function (total, state) { return total + state.changed; }, 0);
    editor.pending.textContent = changed ? count(changed) + ' posições alteradas em ' + count(types.length) +
      (types.length === 1 ? ' tipo de conteúdo. Salve para aplicar.' : ' tipos de conteúdo. Salve para aplicar.') : 'Nenhuma alteração pendente.';
    if (!isSaving(editor)) editor.save.disabled = !changed;
    editor.footer.setAttribute('data-pending', changed ? 'true' : 'false');
  }
  function updateControls(state) {
    var selected = state.selected.size;
    var first = -1, last = -1;
    state.order.forEach(function (key, index) { if (state.selected.has(key)) { if (first < 0) first = index; last = index; } });
    ['up', 'top'].forEach(function (action) { state.buttons[action].disabled = !selected || first === 0 && last === selected - 1; });
    ['down', 'bottom'].forEach(function (action) { state.buttons[action].disabled = !selected || first === state.order.length - selected && last === state.order.length - 1; });
    state.buttons.move.disabled = !selected || selected === state.order.length;
    state.position.disabled = !selected || selected === state.order.length;
    state.position.max = String(Math.max(1, state.order.length));
    state.buttons.clear.disabled = !selected;
    state.buttons.select.disabled = !matches(state).some(function (match) { return !state.selected.has(match.key); });
    state.buttons.az.disabled = matches(state).length < 2;
    state.buttons.za.disabled = matches(state).length < 2;
    state.buttons.undo.disabled = !state.undo.length;
    state.buttons.redo.disabled = !state.redo.length;
    state.buttons.restore.disabled = !state.changed;
    state.summary.textContent = count(matches(state).length) + ' resultados de ' + count(state.order.length) + ' itens · ' + count(selected) + ' marcados';
    updateGlobal(state.editor);
  }
  function render(state, resetScroll) {
    var scrollTop = resetScroll ? 0 : state.list.scrollTop;
    var focused = document.activeElement;
    var focusedRow = focused && state.list.contains(focused) && focused.closest('[data-order-key]');
    var focusKey = focusedRow && focusedRow.getAttribute('data-order-key');
    var focusSelector = focused && focused.matches('input[type="checkbox"]') ? 'input[type="checkbox"]' : '.naxx-order-handle';
    var found = matches(state);
    var pages = Math.max(1, Math.ceil(found.length / pageSize));
    state.page = Math.min(state.page, pages - 1);
    if (!resetScroll && focusedRow) {
      var focusIndex = found.findIndex(function (match) { return match.key === Number(focusKey); });
      var focusPage = Math.floor(focusIndex / pageSize);
      if (focusIndex >= 0 && focusPage !== state.page) { state.page = focusPage; scrollTop = 0; }
    }
    var start = state.page * pageSize;
    var fragment = document.createDocumentFragment();
    found.slice(start, start + pageSize).forEach(function (match) {
      var entry = state.entries[match.key];
      var row = element('li', 'naxx-order-item' + (state.selected.has(match.key) ? ' is-selected' : ''));
      row.setAttribute('data-order-key', String(match.key));
      if (match.index !== match.key) row.classList.add('is-moved');
      var handle = button('⠿', 'drag', 'naxx-order-handle');
      handle.draggable = true;
      handle.setAttribute('aria-label', 'Arrastar ' + entry.name + '. Alt + seta para cima ou para baixo também move.');
      handle.title = 'Arraste para outra posição ou use Alt + ↑ / ↓';
      var label = element('label', 'naxx-order-item-label');
      var check = element('input'); check.type = 'checkbox'; check.checked = state.selected.has(match.key);
      check.setAttribute('aria-label', 'Marcar ' + entry.name + ', posição ' + count(match.index + 1));
      var position = element('span', 'naxx-order-position', count(match.index + 1));
      position.setAttribute('aria-label', 'Posição ' + count(match.index + 1));
      var name = element('span', 'naxx-order-name', entry.name); name.title = entry.name;
      label.append(check, position, name); row.append(handle, label); fragment.appendChild(row);
    });
    state.list.replaceChildren(fragment);
    if (focusKey !== null && focusKey !== false) {
      var restored = state.list.querySelector('[data-order-key="' + focusKey + '"] ' + focusSelector);
      if (restored) restored.focus({preventScroll: true});
    }
    state.list.scrollTop = scrollTop;
    state.empty.hidden = found.length > 0;
    state.empty.textContent = state.order.length ? 'Nenhum resultado. Tente outro nome ou ID.' : 'Nenhum item neste tipo de conteúdo.';
    state.buttons.previous.disabled = state.page === 0;
    state.buttons.next.disabled = state.page >= pages - 1;
    state.pageLabel.textContent = 'Página ' + count(state.page + 1) + ' de ' + count(pages) +
      (found.length ? ' · resultados ' + count(start + 1) + '–' + count(Math.min(start + pageSize, found.length)) : '');
    updateControls(state);
  }
  function apply(state, next, message) {
    if (equal(next, state.order)) { announce(state, 'A ordem já está nessa posição.'); return false; }
    state.undo.push(state.order.slice());
    if (state.undo.length > historyLimit) state.undo.shift();
    state.redo = [];
    state.order = next; state.matches = null;
    state.changed = next.reduce(function (total, key, index) { return total + (key !== state.initial[index] ? 1 : 0); }, 0);
    render(state); announce(state, message + ' Salve para aplicar.'); return true;
  }
  function selectedKeys(state) { return state.order.filter(function (key) { return state.selected.has(key); }); }
  function move(state, action, position, keys) {
    var moving = new Set(keys || selectedKeys(state));
    if (!moving.size) return;
    var next = state.order.slice(), i, temporary;
    if (action === 'up') {
      for (i = 1; i < next.length; i++) if (moving.has(next[i]) && !moving.has(next[i - 1])) {
        temporary = next[i - 1]; next[i - 1] = next[i]; next[i] = temporary;
      }
    } else if (action === 'down') {
      for (i = next.length - 2; i >= 0; i--) if (moving.has(next[i]) && !moving.has(next[i + 1])) {
        temporary = next[i + 1]; next[i + 1] = next[i]; next[i] = temporary;
      }
    } else {
      var block = next.filter(function (key) { return moving.has(key); });
      var rest = next.filter(function (key) { return !moving.has(key); });
      var target = action === 'top' ? 0 : action === 'bottom' ? rest.length : Math.max(0, Math.min(rest.length, position - 1));
      next = rest.slice(0, target).concat(block, rest.slice(target));
    }
    apply(state, next, count(moving.size) + (moving.size === 1 ? ' item movido.' : ' itens movidos.'));
  }
  function sortResults(state, descending) {
    var found = matches(state);
    var keys = found.map(function (match) { return match.key; });
    keys.sort(function (a, b) { return collator.compare(state.entries[a].name, state.entries[b].name) * (descending ? -1 : 1); });
    var next = state.order.slice();
    found.forEach(function (match, index) { next[match.index] = keys[index]; });
    apply(state, next, 'Resultados ordenados de ' + (descending ? 'Z a A.' : 'A a Z.'));
  }
  function history(state, redo) {
    var source = redo ? state.redo : state.undo, destination = redo ? state.undo : state.redo;
    if (!source.length) return;
    destination.push(state.order.slice());
    if (destination.length > historyLimit) destination.shift();
    state.order = source.pop(); state.matches = null;
    state.changed = state.order.reduce(function (total, key, index) { return total + (key !== state.initial[index] ? 1 : 0); }, 0);
    render(state); announce(state, redo ? 'Alteração refeita.' : 'Alteração desfeita.');
  }
  function build(state, editor) {
    state.editor = editor;
    var wrapper = element('section', 'naxx-content-order');
    wrapper.setAttribute('aria-label', 'Ordenar ' + state.definition.label);
    var head = element('div', 'naxx-order-section-head');
    head.appendChild(element('h3', '', state.definition.label));
    state.summary = element('p', 'naxx-order-summary'); head.appendChild(state.summary); wrapper.appendChild(head);
    var searchLabel = element('label', 'naxx-order-search');
    searchLabel.appendChild(element('span', '', 'Buscar por nome ou ID'));
    state.search = element('input'); state.search.type = 'search'; state.search.placeholder = 'Digite para encontrar um item…';
    state.search.autocomplete = 'off'; searchLabel.appendChild(state.search); wrapper.appendChild(searchLabel);
    var toolbar = element('div', 'naxx-order-toolbar'); state.buttons = {};
    function add(target, action, text, className) { var node = button(text, action, className); state.buttons[action] = node; target.appendChild(node); return node; }
    add(toolbar, 'select', 'Marcar resultados'); add(toolbar, 'clear', 'Limpar marcações');
    var sorts = element('div', 'naxx-order-button-group');
    add(sorts, 'az', 'Ordenar resultados A–Z'); add(sorts, 'za', 'Z–A'); toolbar.appendChild(sorts); wrapper.appendChild(toolbar);
    var moves = element('div', 'naxx-order-moves');
    moves.appendChild(element('span', 'naxx-order-moves-label', 'Mover marcados'));
    var directions = element('div', 'naxx-order-button-group');
    add(directions, 'up', '↑ Subir'); add(directions, 'down', '↓ Descer'); add(directions, 'top', '⇈ Início'); add(directions, 'bottom', '⇊ Fim'); moves.appendChild(directions);
    var moveTo = element('div', 'naxx-order-move-to');
    var positionLabel = element('label', '', 'Para a posição');
    state.position = element('input'); state.position.type = 'text'; state.position.inputMode = 'numeric'; state.position.value = '1';
    state.position.setAttribute('data-order-position', '');
    state.position.setAttribute('aria-label', 'Posição do primeiro item marcado na lista completa');
    positionLabel.appendChild(state.position); moveTo.appendChild(positionLabel); add(moveTo, 'move', 'Mover'); moves.appendChild(moveTo); wrapper.appendChild(moves);
    wrapper.appendChild(element('p', 'naxx-order-help', 'As posições pertencem à lista completa. A busca só oculta itens; ordenar A–Z reorganiza os resultados nas posições que já ocupam. Arraste pela alça ⠿ ou marque itens para movê-los juntos.'));
    var listHead = element('div', 'naxx-order-list-head'); listHead.append(element('span', '', 'POSIÇÃO'), element('span', '', 'NOME DO CONTEÚDO')); wrapper.appendChild(listHead);
    state.list = element('ol', 'naxx-order-list'); state.list.setAttribute('aria-label', 'Ordem de ' + state.definition.label); wrapper.appendChild(state.list);
    state.empty = element('p', 'naxx-order-empty'); wrapper.appendChild(state.empty);
    var pager = element('div', 'naxx-order-pagination'); add(pager, 'previous', '← Anterior');
    state.pageLabel = element('span', 'naxx-order-page-label'); pager.appendChild(state.pageLabel); add(pager, 'next', 'Próxima →'); wrapper.appendChild(pager);
    var historyBar = element('div', 'naxx-order-history'); add(historyBar, 'undo', 'Desfazer'); add(historyBar, 'redo', 'Refazer'); add(historyBar, 'restore', 'Restaurar ordem inicial'); wrapper.appendChild(historyBar);
    state.notice = element('p', 'naxx-order-notice'); state.notice.setAttribute('role', 'status'); state.notice.setAttribute('aria-live', 'polite'); wrapper.appendChild(state.notice);
    // Hide only this panel's original visible controls. Keep the native selects,
    // hidden fields, form and backend handler intact.
    Array.from(state.panel.children).forEach(function (child) { child.classList.add('naxx-order-native'); });
    state.panel.appendChild(wrapper); state.wrapper = wrapper;
    wrapper.addEventListener('click', function (event) {
      if (!isSaving(editor)) return;
      event.preventDefault(); event.stopImmediatePropagation(); announce(state, 'Salvamento em andamento. Aguarde a resposta.');
    }, true);
    state.search.addEventListener('input', function () {
      if (isSaving(editor)) return;
      window.clearTimeout(state.searchTimer);
      state.searchTimer = window.setTimeout(function () { refreshFilter(state); }, 100);
    });
    wrapper.addEventListener('keydown', function (event) {
      if (isSaving(editor)) { event.preventDefault(); return; }
      if (event.key !== 'Enter' || !event.target.matches('input[type="search"], [data-order-position]')) return;
      event.preventDefault();
      refreshFilter(state);
      if (event.target === state.position && !state.buttons.move.disabled) state.buttons.move.click();
    });
    wrapper.addEventListener('click', function (event) {
      var control = event.target.closest('[data-order-action]');
      if (!control || !wrapper.contains(control) || control.disabled) return;
      var action = control.getAttribute('data-order-action');
      refreshFilter(state);
      if (action === 'select') { matches(state).forEach(function (match) { state.selected.add(match.key); }); render(state); }
      else if (action === 'clear') { state.selected.clear(); render(state); }
      else if (action === 'az' || action === 'za') sortResults(state, action === 'za');
      else if (action === 'undo' || action === 'redo') history(state, action === 'redo');
      else if (action === 'restore') apply(state, state.initial.slice(), 'Ordem inicial restaurada.');
      else if (action === 'previous' || action === 'next') { state.page += action === 'next' ? 1 : -1; render(state, true); }
      else if (action === 'move') {
        var destination = Number(state.position.value);
        if (!Number.isSafeInteger(destination) || destination < 1 || destination > state.order.length) {
          announce(state, 'Informe uma posição de 1 a ' + count(state.order.length) + '.'); state.position.focus(); return;
        }
        move(state, action, destination);
      } else if (['up', 'down', 'top', 'bottom'].includes(action)) move(state, action);
    });
    state.list.addEventListener('change', function (event) {
      if (!event.target.matches('input[type="checkbox"]')) return;
      var row = event.target.closest('[data-order-key]'), key = Number(row.getAttribute('data-order-key'));
      if (isSaving(editor)) { event.target.checked = state.selected.has(key); return; }
      if (event.target.checked) state.selected.add(key); else state.selected.delete(key);
      row.classList.toggle('is-selected', event.target.checked); updateControls(state);
    });
    state.list.addEventListener('keydown', function (event) {
      if (isSaving(editor)) { event.preventDefault(); return; }
      if (!event.altKey || !['ArrowUp', 'ArrowDown'].includes(event.key)) return;
      var row = event.target.closest('[data-order-key]'); if (!row) return;
      event.preventDefault(); var key = Number(row.getAttribute('data-order-key'));
      move(state, event.key === 'ArrowUp' ? 'up' : 'down', null, state.selected.has(key) ? selectedKeys(state) : [key]);
      var handle = state.list.querySelector('[data-order-key="' + key + '"] .naxx-order-handle'); if (handle) handle.focus({preventScroll: true});
    });
    state.list.addEventListener('dragstart', function (event) {
      if (isSaving(editor)) { event.preventDefault(); return; }
      var handle = event.target.closest('.naxx-order-handle'); if (!handle) { event.preventDefault(); return; }
      var key = Number(handle.closest('[data-order-key]').getAttribute('data-order-key'));
      state.dragKeys = state.selected.has(key) ? selectedKeys(state) : [key];
      if (event.dataTransfer) { event.dataTransfer.effectAllowed = 'move'; event.dataTransfer.setData('text/plain', 'naxx-order:' + state.definition.type + ':' + key); }
    });
    state.list.addEventListener('dragover', function (event) {
      if (isSaving(editor)) return;
      var row = event.target.closest('[data-order-key]');
      if (!state.dragKeys || !row) return;
      event.preventDefault(); if (event.dataTransfer) event.dataTransfer.dropEffect = 'move';
      state.list.querySelectorAll('.is-drop-target').forEach(function (item) { item.classList.remove('is-drop-target'); }); row.classList.add('is-drop-target');
    });
    state.list.addEventListener('drop', function (event) {
      if (isSaving(editor)) { event.preventDefault(); state.dragKeys = null; return; }
      var row = event.target.closest('[data-order-key]'); if (!state.dragKeys || !row) return;
      event.preventDefault(); var key = Number(row.getAttribute('data-order-key')), keys = state.dragKeys; state.dragKeys = null;
      if (keys.includes(key)) { render(state); return; }
      var index = state.order.indexOf(key), moving = new Set(keys), before = 0;
      for (var i = 0; i < index; i++) if (moving.has(state.order[i])) before++;
      move(state, 'move', index - before + 1, keys);
    });
    state.list.addEventListener('dragend', function () { state.dragKeys = null; state.list.querySelectorAll('.is-drop-target').forEach(function (item) { item.classList.remove('is-drop-target'); }); });
    render(state);
  }
  function valid(state) {
    var form = state.editor.form;
    if (!form.isConnected || !state.panel.isConnected || document.getElementById(state.definition.panel) !== state.panel ||
        !state.left.isConnected || !state.right.isConnected ||
        document.getElementById('sort_' + state.definition.type + '_l') !== state.left ||
        document.getElementById('sort_' + state.definition.type + '_r') !== state.right ||
        state.left.form !== form || state.right.form !== form || !form.contains(state.panel) ||
        !state.panel.contains(state.left) || !state.panel.contains(state.right)) return false;
    if (state.order.length !== state.entries.length || new Set(state.order).size !== state.entries.length) return false;
    var left = state.left.options, right = state.right.options;
    if (left.length !== state.entries.length || right.length !== state.entries.length) return false;
    for (var i = 0; i < state.order.length; i++) {
      var key = state.order[i], native = state.entries[state.nativeOrder[i]];
      if (!Number.isInteger(key) || !state.entries[key] || !native || left[i] !== native.left || right[i] !== native.right ||
          native.left.value !== native.value || native.right.value !== native.value || native.left.text !== native.text || native.right.text !== native.text) return false;
    }
    return true;
  }
  function sync(state) {
    if (equal(state.order, state.nativeOrder)) return;
    var left = document.createDocumentFragment(), right = document.createDocumentFragment();
    state.order.forEach(function (key) { left.appendChild(state.entries[key].left); right.appendChild(state.entries[key].right); });
    state.left.appendChild(left); state.right.appendChild(right); state.nativeOrder = state.order.slice();
  }
  function enhance() {
    if (!isOrderPage()) return false;
    if (active && active.form.isConnected) return true;
    var field = document.getElementById('stream_order_array'), form = field && field.form;
    if (!form || !form.querySelector('input[name="reorder"]')) return false;
    var states = definitions.map(function (definition) { return readState(definition, form); });
    if (states.some(function (state) { return !state; })) return false;
    if (active && active.lockObserver) active.lockObserver.disconnect();
    var editor = {form: form, field: field, states: states, submitting: false};
    var intro = element('header', 'naxx-content-order naxx-order-intro');
    intro.appendChild(element('span', 'naxx-order-eyebrow', 'ORDEM DO CONTEÚDO'));
    intro.appendChild(element('h2', '', 'Ordenar conteúdos'));
    intro.appendChild(element('p', '', 'Uma lista por tipo de conteúdo. Encontre, marque e mova os itens para definir como serão exibidos.'));
    form.insertBefore(intro, form.firstChild);
    editor.footer = element('div', 'naxx-content-order naxx-order-savebar');
    var saveText = element('div'); saveText.appendChild(element('strong', '', 'Salve para aplicar a nova ordem'));
    editor.pending = element('p'); saveText.appendChild(editor.pending); editor.footer.appendChild(saveText);
    editor.save = element('button', 'naxx-order-save', 'Salvar alterações'); editor.save.type = 'submit';
    // Position is an auxiliary editor input, not a backend field. Its manual
    // Move validation must never prevent saving an otherwise valid draft.
    editor.save.formNoValidate = true; editor.footer.appendChild(editor.save);
    editor.lockObserver = new MutationObserver(function () { isSaving(editor); });
    editor.lockObserver.observe(editor.save, {attributes: true, attributeFilter: ['disabled']});
    form.appendChild(editor.footer);
    states.forEach(function (state) { build(state, editor); });
    states.forEach(function (state) {
      var tab = form.querySelector('a[href="#' + state.definition.panel + '"]');
      if (tab) {
        var span = tab.querySelector('span'); if (span) span.textContent = state.definition.label;
        tab.setAttribute('aria-label', state.definition.label); tab.classList.add('naxx-order-tab');
      }
    });
    form.classList.add('naxx-order-form');
    // Capture runs before the existing jQuery submit handler. Nothing is written
    // to the native selects or payload until the user explicitly submits Save.
    form.addEventListener('submit', function (event) {
      if (isSaving(editor)) { event.preventDefault(); event.stopImmediatePropagation(); return; }
      if (!isOrderPage() || document.getElementById('stream_order_array') !== field || field.form !== form || !states.every(valid)) {
        event.preventDefault(); event.stopImmediatePropagation();
        editor.pending.textContent = 'Não foi possível validar a ordem. Recarregue a página antes de salvar.';
        editor.pending.setAttribute('role', 'alert'); return;
      }
      try {
        states.forEach(sync);
        var order = {stream: [], movie: [], radio: [], series: []};
        states.forEach(function (state) { order[state.definition.type] = state.order.map(function (key) { return state.entries[key].value; }); });
        field.value = JSON.stringify(order);
        editor.submitting = true; editor.save.disabled = true; form.setAttribute('aria-busy', 'true');
      } catch (_error) {
        event.preventDefault(); event.stopImmediatePropagation();
        editor.pending.textContent = 'Não foi possível preparar a ordem para salvar. Recarregue a página e tente novamente.';
        editor.pending.setAttribute('role', 'alert');
      }
    }, true);
    active = editor;
    if (observer) { observer.disconnect(); observer = null; }
    return true;
  }
  function bootstrap() {
    if (!isOrderPage()) return;
    if (enhance() || observer || !document.body) return;
    observer = new MutationObserver(function () {
      if (pending) return;
      pending = window.setTimeout(function () { pending = null; enhance(); }, 50);
    });
    observer.observe(document.body, {childList: true, subtree: true});
  }
  window.NaxxBouquetOrder = {enhance: enhance};
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', bootstrap, {once: true});
  else bootstrap();
})();

/* Seleção explícita da edição em massa; o envio continua no formulário nativo. */
(function () {
  'use strict';
  var active = null, bound = false;

  function idOf(row) {
    var value = Array.isArray(row) ? String(row[0]) : '';
    return /^[1-9]\d*$/.test(value) && Number.isSafeInteger(Number(value)) ? value : null;
  }

  function selected() {
    if (!Array.isArray(window.rSelected)) return null;
    return window.rSelected;
  }

  function message(state, value) { state.status.textContent = value; }

  function sync(state) {
    var ids = selected();
    if (!ids) return;
    var chosen = new Set(ids.map(String));
    state.api.rows({page: 'current'}).every(function () {
      var node = this.node(), id = idOf(this.data());
      if (!node) return;
      ['selectedfilter', 'ui-selected', 'selected'].forEach(function (name) {
        node.classList.toggle(name, Boolean(id && chosen.has(id)));
      });
    });
    var count = document.getElementById('selected_count');
    if (count) count.textContent = ' — ' + ids.length + ' selecionados';
  }

  function cancel(state, announce) {
    if (!state.pending) return;
    state.pending.abort(); state.pending = null;
    state.cancel.hidden = true; state.all.disabled = false;
    if (announce) message(state, 'Seleção cancelada. Os canais já selecionados foram mantidos.');
  }

  function add(state, ids) {
    var current = selected();
    if (!current) throw new Error('selection_unavailable');
    var known = new Set(current.map(String));
    ids.forEach(function (id) {
      id = String(id);
      if (!known.has(id)) { current.push(id); known.add(id); }
    });
    sync(state);
  }

  function visible(state) {
    cancel(state, false);
    var ids = [];
    state.api.rows({page: 'current'}).every(function () {
      var node = this.node();
      if (!node || node.hidden || node.style.display === 'none') return;
      var id = idOf(this.data());
      if (id) ids.push(id);
    });
    add(state, ids);
    message(state, ids.length + ' canais visíveis selecionados.');
  }

  async function allFiltered(state) {
    cancel(state, false);
    if (!window.NaxxStreamSources || typeof window.NaxxStreamSources.filteredIds !== 'function') {
      message(state, 'Aguarde o carregamento da tabela e tente novamente.'); return;
    }
    var controller = new AbortController(); state.pending = controller;
    state.cancel.hidden = false; state.all.disabled = true;
    message(state, 'Buscando todos os canais dos filtros atuais…');
    try {
      var ids = await window.NaxxStreamSources.filteredIds(state.table, controller.signal);
      if (active !== state || state.pending !== controller || controller.signal.aborted || !state.table.isConnected) return;
      if (!Array.isArray(ids) || ids.some(function (id) { return !idOf([id]); })) throw new Error('invalid_ids');
      add(state, ids);
      message(state, ids.length + ' canais dos filtros atuais selecionados.');
    } catch (error) {
      if (active !== state || state.pending !== controller || controller.signal.aborted) return;
      message(state, error && error.message === 'catalog_limit' ?
        'A seleção aceita até 50.000 canais. Refine os filtros e tente novamente.' :
        'Não foi possível selecionar todos. Os canais já selecionados foram mantidos; aguarde a tabela e tente novamente.');
    } finally {
      if (state.pending === controller) { state.pending = null; state.cancel.hidden = true; state.all.disabled = false; }
    }
  }

  function selectable(state) {
    if (!state.jq.fn.selectable || !state.jq(state.table).data('ui-selectable')) return;
    state.jq(state.table).selectable('option', 'filter', 'tbody tr');
    state.jq(state.table).selectable('option', 'selected', state.selectRow);
  }

  function destroy(state) {
    cancel(state, false);
    window.clearTimeout(state.timer);
    state.jq(state.table).off('.naxxStreamMass');
    if (window.toggleStreams === state.toggle) window.toggleStreams = state.originalToggle;
    state.box.remove();
  }

  function button(box, name, label) {
    var node = document.createElement('button'); node.type = 'button';
    node.className = 'btn btn-light'; node.dataset.naxxMass = name; node.textContent = label;
    box.appendChild(node); return node;
  }

  function mount(table, jq, api) {
    var box = document.createElement('div'); box.className = 'naxx-stream-mass-selection';
    var visibleButton = button(box, 'visible', 'Selecionar visíveis');
    var all = button(box, 'all', 'Selecionar todos do filtro');
    var clear = button(box, 'clear', 'Limpar seleção');
    var stop = button(box, 'cancel', 'Cancelar seleção'); stop.hidden = true;
    var status = document.createElement('p'); status.className = 'text-muted mb-0'; status.setAttribute('role', 'status');
    box.appendChild(status); table.before(box);
    var state = {table: table, jq: jq, api: api, box: box, status: status, all: all, cancel: stop,
      pending: null, originalToggle: window.toggleStreams};
    active = state;
    state.toggle = function () { if (active === state && table.isConnected) visible(state); };
    window.toggleStreams = state.toggle;
    state.selectRow = function (_event, ui) {
      if (active !== state || !table.isConnected) return;
      var id = idOf(api.row(ui.selected).data()), ids = selected();
      if (!id || !ids) return;
      cancel(state, false);
      var index = ids.map(String).indexOf(id);
      if (index < 0) ids.push(id); else ids.splice(index, 1);
      sync(state);
    };
    visibleButton.addEventListener('click', function () { visible(state); });
    all.addEventListener('click', function () { allFiltered(state); });
    clear.addEventListener('click', function () {
      cancel(state, false); var ids = selected(); if (ids) ids.splice(0, ids.length);
      sync(state); message(state, 'Seleção limpa.');
    });
    stop.addEventListener('click', function () { cancel(state, true); });
    jq(table).on('preXhr.dt.naxxStreamMass', function () { cancel(state, true); });
    jq(table).on('draw.dt.naxxStreamMass', function () { selectable(state); sync(state); });
    jq(table).on('destroy.dt.naxxStreamMass', function () { if (active === state) { destroy(state); active = null; } });
    // A página nativa cria selectable logo depois de inicializar o DataTables.
    state.timer = window.setTimeout(function () { if (active === state) selectable(state); }, 0);
    var nativeButton = document.querySelector('#stream-selection button[onclick*="toggleStreams"]');
    if (nativeButton) { nativeButton.title = 'Selecionar visíveis'; nativeButton.setAttribute('aria-label', 'Selecionar visíveis'); }
    selectable(state); sync(state);
  }

  function enhance() {
    var table = /\/stream_mass(?:\.php)?$/.test(window.location.pathname) ? document.getElementById('datatable-mass') : null;
    if (active && (active.table !== table || !table || !table.isConnected)) { destroy(active); active = null; }
    var jq = window.jQuery;
    if (!jq || !jq.fn || !jq.fn.dataTable) return;
    if (!bound) {
      bound = true;
      jq(document).on('init.dt.naxxStreamMass', '#datatable-mass', enhance);
    }
    if (!table || !jq.fn.dataTable.isDataTable(table) || !selected()) return;
    if (active) { selectable(active); sync(active); return; }
    mount(table, jq, jq(table).DataTable());
  }

  window.NaxxStreamMass = {enhance: enhance};
  enhance();
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', enhance, {once: true});
}());

/* Página inicial pública: temas fixos e aplicação autenticada na aba Configurações. */
(function () {
  'use strict';
  var current = null;
  var themes = [
    {id:'naxx',name:'Naxx Azul',description:'Azul intenso, traços de luz e identidade NAXX.',colors:['#080f20','#4788ff','#dceaff']},
    {id:'aurora',name:'Aurora',description:'Verde e turquesa em um visual fluido e envolvente.',colors:['#062821','#9fe4b0','#e2f2dc']},
    {id:'claro',name:'Claro',description:'Tons claros, bastante espaço e acabamento minimalista.',colors:['#f5f3ec','#184ee8','#161c2b']},
    {id:'cinema',name:'Cinema',description:'Vinho, dourado e uma composição inspirada no cinema.',colors:['#241013','#e5b16f','#faeee0']}
  ];
  function known(id) { return themes.some(function (theme) { return theme.id === id; }); }
  function mount(link, pane) {
    var state = null, csrf = '', draft = 'naxx', loaded = false, pending = false, destroyed = false;
    var requestController = null, previewController = null, revision = 0, selectedPreview = '';
    pane.innerHTML = '<section class="naxx-public-page"><header class="naxx-public-heading"><div><span class="naxx-public-eyebrow">IDENTIDADE NAXX</span><h2>Página inicial do servidor</h2><p>A página exibida ao abrir o endereço principal do servidor.</p></div><a class="btn btn-light" data-public-open target="_blank" rel="noopener noreferrer">Abrir página inicial <span aria-hidden="true">↗</span></a></header>' +
      '<div class="naxx-public-notice" data-public-notice role="status" aria-live="polite" hidden></div>' +
      '<div class="naxx-public-layout"><section class="naxx-public-picker"><div class="naxx-public-section-heading"><h3>Escolha um tema</h3><button type="button" class="btn btn-light" data-public-refresh>Atualizar</button></div><p class="text-muted">Quatro estilos prontos. Visualize e aplique o que combina com sua NAXX.</p><div class="naxx-public-themes" role="radiogroup" aria-label="Tema da página inicial"></div>' +
      '<div class="naxx-public-apply"><p data-public-current>Consultando a página atual…</p><button type="button" class="btn btn-primary" data-public-apply disabled>Aplicar tema</button><button type="button" class="btn btn-light" data-public-restore disabled>Restaurar página original</button><small class="text-muted">A escolha só entra no ar ao clicar em Aplicar tema.</small></div></section>' +
      '<section class="naxx-public-preview"><div class="naxx-public-section-heading"><h3>Prévia <span data-public-preview-name>Naxx Azul</span></h3><div class="naxx-public-devices" aria-label="Tamanho da prévia"><button type="button" aria-pressed="true" data-public-device="desktop">Computador</button><button type="button" aria-pressed="false" data-public-device="mobile">Celular</button></div></div><div class="naxx-public-preview-stage" data-public-preview-stage><p data-public-preview-message role="status">Escolha um tema para visualizar.</p><iframe title="Prévia da página inicial" sandbox="" referrerpolicy="no-referrer" hidden></iframe></div><p class="text-muted naxx-public-preview-caption">A prévia permite conferir o visual antes de publicar.</p></section></div></section>';
    var root = pane.querySelector('.naxx-public-page');
    function query(selector) { return root.querySelector(selector); }
    query('[data-public-open]').href = new URL('/', window.location.href).href;
    var cards = [], frame = query('iframe'), previewMessage = query('[data-public-preview-message]');
    themes.forEach(function (theme, index) {
      var card = document.createElement('button'); card.type = 'button'; card.className = 'naxx-public-theme';
      card.dataset.publicTheme = theme.id; card.setAttribute('role', 'radio'); card.setAttribute('aria-checked', String(theme.id === draft)); card.tabIndex = index ? -1 : 0;
      var sample = document.createElement('span'); sample.className = 'naxx-public-sample'; sample.setAttribute('aria-hidden', 'true');
      sample.style.setProperty('--sample-bg', theme.colors[0]); sample.style.setProperty('--sample-accent', theme.colors[1]); sample.style.setProperty('--sample-ink', theme.colors[2]);
      sample.innerHTML = '<span class="naxx-public-sample-mark">N</span><span class="naxx-public-sample-lines"><i></i><i></i></span><span class="naxx-public-sample-orbit"></span>';
      var name = document.createElement('strong'); name.textContent = theme.name;
      var description = document.createElement('span'); description.className = 'naxx-public-theme-description'; description.textContent = theme.description;
      var badge = document.createElement('span'); badge.className = 'naxx-public-in-use'; badge.textContent = 'Em uso'; badge.hidden = true;
      card.append(sample, name, description, badge); query('.naxx-public-themes').appendChild(card); cards.push(card);
      card.addEventListener('click', function () { choose(theme.id); });
      card.addEventListener('keydown', function (event) {
        if (!['ArrowLeft','ArrowRight','ArrowUp','ArrowDown','Home','End'].includes(event.key) || pending) return;
        event.preventDefault(); var next = event.key === 'Home' ? 0 : event.key === 'End' ? themes.length - 1 : (index + (/Right|Down/.test(event.key) ? 1 : -1) + themes.length) % themes.length;
        choose(themes[next].id); cards[next].focus();
      });
    });
    function notice(message, error) {
      var node = query('[data-public-notice]'); node.hidden = !message; node.textContent = message || ''; node.dataset.tone = error ? 'error' : 'success'; node.setAttribute('role', error ? 'alert' : 'status');
    }
    function connected() { return !destroyed && pane.isConnected; }
    function controls() {
      var ready = !!state && !!csrf && Array.isArray(state.available) && state.available.includes(draft);
      cards.forEach(function (card) {
        var id = card.dataset.publicTheme; card.disabled = pending; card.setAttribute('aria-checked', String(id === draft)); card.tabIndex = id === draft ? 0 : -1;
        card.querySelector('.naxx-public-in-use').hidden = !state || state.selected !== id;
      });
      query('[data-public-refresh]').disabled = pending;
      query('[data-public-apply]').disabled = pending || !ready || state.can_publish !== true || state.selected === draft;
      query('[data-public-restore]').disabled = pending || !state || !csrf || state.can_restore !== true;
      query('[data-public-apply]').textContent = pending ? 'Aguarde…' : 'Aplicar tema'; root.setAttribute('aria-busy', String(pending));
      query('[data-public-current]').textContent = !state ? 'Consultando a página atual…' : state.selected === 'original' ? 'Em uso: página original do servidor.' : known(state.selected) ? 'Em uso: ' + themes.find(function (theme) { return theme.id === state.selected; }).name + '.' : 'Em uso: página personalizada.';
    }
    async function request(action, theme, signal) {
      var url = new URL('naxx-update.php', window.location.href); url.searchParams.set('feature', 'public-page');
      if (action === 'preview') url.searchParams.set('preview', theme);
      var init = {credentials:'same-origin',cache:'no-store',signal:signal,headers:{Accept:'application/json','X-Requested-With':'XMLHttpRequest'}};
      if (action === 'publish' || action === 'restore') { init.method = 'POST'; init.headers['Content-Type'] = 'application/json'; init.body = JSON.stringify({action:action,theme:action === 'publish' ? theme : undefined,csrf:csrf}); }
      var response = await window.fetch(url.href, init);
      if (response.redirected || /\/(?:login|license)(?:[/?#.]|$)/i.test(response.url)) throw new Error('Sua sessão expirou. Entre novamente no painel.');
      var result;
      try { result = JSON.parse(await response.text()); } catch (_) { throw new Error('Não foi possível consultar a página inicial. Atualize esta aba e tente novamente.'); }
      if (!result || typeof result !== 'object' || Array.isArray(result) || !response.ok || result.ok !== true) throw new Error(result && typeof result.message === 'string' ? result.message : 'O serviço da página inicial está indisponível. Atualize esta aba e tente novamente.');
      return result;
    }
    function accept(result) {
      var next = result.state;
      if (!next || !Array.isArray(next.available) || !['original','custom'].concat(themes.map(function (theme) { return theme.id; })).includes(next.selected) || typeof next.can_publish !== 'boolean' || typeof next.can_restore !== 'boolean' || typeof result.csrf !== 'string' || !/^[a-f0-9]{64}$/.test(result.csrf)) throw new Error('O serviço retornou informações incompletas. Atualize esta aba.');
      state = next; csrf = result.csrf;
    }
    async function preview(id) {
      if (previewController) previewController.abort(); var controller = new AbortController(); previewController = controller; var ticket = ++revision;
      selectedPreview = ''; frame.hidden = true; previewMessage.hidden = false; previewMessage.textContent = 'Preparando prévia…';
      query('[data-public-preview-name]').textContent = themes.find(function (theme) { return theme.id === id; }).name;
      var timeout = window.setTimeout(function () { controller.abort(); }, 15000);
      try {
        var result = await request('preview', id, controller.signal);
        if (!connected() || ticket !== revision || controller.signal.aborted) return;
        if (!result.preview || result.preview.theme !== id || typeof result.preview.html !== 'string' || result.preview.html.length > 131072 || !/<!doctype html>/i.test(result.preview.html)) throw new Error('A prévia deste tema não está disponível. Tente selecioná-lo novamente.');
        frame.srcdoc = result.preview.html; frame.title = 'Prévia: ' + themes.find(function (theme) { return theme.id === id; }).name;
        frame.hidden = false; previewMessage.hidden = true; selectedPreview = id;
      } catch (error) {
        if (connected() && ticket === revision) { previewMessage.textContent = error.name === 'AbortError' ? 'A prévia demorou para responder. Selecione o tema novamente.' : error.message; }
      } finally { window.clearTimeout(timeout); if (previewController === controller) previewController = null; }
    }
    function choose(id) {
      if (pending || !known(id) || !connected()) return;
      draft = id; controls(); if (selectedPreview !== id) preview(id);
    }
    async function load() {
      if (pending || !connected()) return; pending = true; controls(); notice('');
      var controller = new AbortController(); requestController = controller;
      var timeout = window.setTimeout(function () { controller.abort(); }, 15000);
      try {
        var result = await request('status', null, controller.signal); if (!connected()) return;
        accept(result); if (!loaded && known(state.selected)) draft = state.selected; loaded = true;
        if (state.reason) notice(String(state.reason), !state.can_publish);
        preview(draft);
      } catch (error) { if (connected()) { state = null; csrf = ''; notice(error.name === 'AbortError' ? 'A consulta demorou para responder. Clique em Atualizar.' : error.message, true); } }
      finally { window.clearTimeout(timeout); if (requestController === controller) requestController = null; pending = false; if (connected()) controls(); }
    }
    async function apply(action) {
      if (pending || !state || !csrf || (action === 'publish' ? !state.can_publish || !state.available.includes(draft) || state.selected === draft : !state.can_restore)) return;
      pending = true; controls(); notice(''); var controller = new AbortController(); requestController = controller;
      var timeout = window.setTimeout(function () { controller.abort(); }, 15000);
      try {
        var result = await request(action, draft, controller.signal); if (!connected()) return;
        accept(result); notice(action === 'publish' ? 'Tema aplicado. A nova página inicial já está disponível.' : 'A página original foi restaurada.');
      } catch (error) { if (connected()) { state = null; csrf = ''; notice(error.name === 'AbortError' ? 'Não foi possível confirmar a alteração. Clique em Atualizar para conferir o tema em uso.' : error.message, true); } }
      finally { window.clearTimeout(timeout); if (requestController === controller) requestController = null; pending = false; if (connected()) controls(); }
    }
    query('[data-public-refresh]').addEventListener('click', load);
    query('[data-public-apply]').addEventListener('click', function () { apply('publish'); });
    query('[data-public-restore]').addEventListener('click', function () { apply('restore'); });
    root.querySelectorAll('[data-public-device]').forEach(function (button) { button.addEventListener('click', function () {
      query('[data-public-preview-stage]').dataset.device = button.dataset.publicDevice;
      root.querySelectorAll('[data-public-device]').forEach(function (other) { other.setAttribute('aria-pressed', String(other === button)); });
    }); });
    function open() {
      if (!window.jQuery || !window.jQuery.fn || !window.jQuery.fn.tab) {
        var nav = link.closest('ul'); nav.querySelectorAll('.nav-link').forEach(function (other) { other.classList.toggle('active', other === link); other.setAttribute('aria-selected', String(other === link)); });
        Array.from(pane.parentElement.children).forEach(function (other) { if (other.classList.contains('tab-pane')) { other.classList.toggle('active', other === pane); other.classList.toggle('show', other === pane); } });
      }
      if (!loaded && !pending) load();
    }
    link.addEventListener('click', open);
    return {pane:pane,link:link,open:open,destroy:function () { destroyed = true; revision++; if (requestController) requestController.abort(); if (previewController) previewController.abort(); link.removeEventListener('click', open); var item = link.closest('li'); if (item) item.remove(); else link.remove(); pane.remove(); }};
  }
  function enhance() {
    var logs = /\/settings(?:\.php)?$/.test(window.location.pathname) ? document.querySelector('a[data-toggle="tab"][href="#logs"]') : null;
    var content = logs && document.getElementById('logs'), nav = logs && logs.closest('ul');
    if (current && (!logs || !nav || !content || !current.link.isConnected || current.link.closest('ul') !== nav || !current.pane.isConnected || current.pane.parentElement !== content.parentElement)) { current.destroy(); current = null; }
    if (!logs || !content || !nav || current) return;
    var item = document.createElement('li'); item.className = 'nav-item';
    var link = document.createElement('a'); link.id = 'naxx-public-page-tab'; link.className = 'nav-link rounded-0 pt-2 pb-2'; link.href = '#naxx-public-page'; link.dataset.toggle = 'tab'; link.setAttribute('role','tab'); link.setAttribute('aria-controls','naxx-public-page'); link.setAttribute('aria-selected','false');
    link.innerHTML = '<i class="fas fa-palette mr-1" aria-hidden="true"></i><span>Página inicial</span>'; item.appendChild(link); logs.closest('li').after(item);
    var pane = document.createElement('div'); pane.id = 'naxx-public-page'; pane.className = 'tab-pane'; pane.setAttribute('role','tabpanel'); pane.setAttribute('aria-labelledby',link.id); content.parentElement.appendChild(pane);
    current = mount(link, pane);
  }
  window.NaxxPublicPage = {enhance:enhance}; enhance();
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', enhance, {once:true});
}());

/* Traduções contextuais do painel nativo. Nunca altera dados ou ações. */
(function (global) {
  'use strict';

  // Textos fixos verificados no cabeçalho e nos formulários do XUI.
  // Os seletores não incluem nomes de contas, canais, categorias ou provedores.
  var modalHeadings = {
    'Server Tools': 'Ferramentas do servidor',
    'Domain List': 'Lista de domínios',
    'XUI EPG Browser': 'Navegador de EPG do XUI',
    'Provider Streams': 'Canais do provedor',
    'Provider Movies': 'Filmes do provedor',
    'Use the EPG icon for this stream?': 'Usar o ícone da EPG neste canal?',
    'Add / Remove Credits': 'Adicionar ou remover créditos',
    'Clear Stream Logs': 'Limpar registros dos canais'
  };
  var modalControls = {
    'Credits': 'Créditos',
    'Adjust Credits': 'Ajustar créditos',
    'Use Icon': 'Usar ícone',
    'Record': 'Gravar',
    'Cancel': 'Cancelar',
    'Close': 'Fechar',
    'Clear Stream Logs': 'Limpar registros dos canais'
  };
  var formLabels = {
    'Series Name': 'Nome da série',
    'Poster URL': 'URL do pôster',
    'Backdrop URL': 'URL da imagem de fundo',
    'Plot': 'Sinopse',
    'Cast': 'Elenco',
    'Director': 'Diretor',
    'Genres': 'Gêneros',
    'Release Date': 'Data de lançamento',
    'First Aired': 'Estreia',
    'Runtime': 'Duração',
    'Youtube Trailer': 'Trailer do YouTube',
    'Rating': 'Classificação',
    'Timezone': 'Fuso horário',
    'Disable TMDb': 'Desativar TMDb',
    'Ignore No Match': 'Ignorar itens sem correspondência',
    'Show Potential Duplicates': 'Mostrar possíveis duplicados',
    'Keep Logs For': 'Manter registros por'
  };
  var columns = {
    'Credits': 'Créditos',
    'Server Name': 'Nome do servidor',
    'Stream Name': 'Nome do canal',
    'Stream Info': 'Informações do canal',
    'Provider Streams': 'Canais do provedor',
    'Provider Movies': 'Filmes do provedor'
  };
  var navigation = {
    'Server Tools': 'Ferramentas do servidor',
    'Clear Stream Logs': 'Limpar registros dos canais',
    'Provider Streams': 'Canais do provedor',
    'Provider Movies': 'Filmes do provedor'
  };
  var accountColumns = {
    'USERNAME': 'Usuário', 'Username': 'Usuário',
    'PASSWORD': 'Senha', 'Password': 'Senha',
    'OWNER': 'Responsável', 'Owner': 'Responsável',
    'TRIAL': 'Teste', 'Trial': 'Teste',
    'ACTIVE': 'Em uso', 'Active': 'Em uso',
    'EXPIRATION': 'Vencimento', 'Expiration': 'Vencimento',
    'LAST CONNECTION': 'Última conexão', 'Last Connection': 'Última conexão'
  };
  var accountControls = {
    'Add Line': 'Adicionar conta', 'Filter Results': 'Filtrar resultados',
    'Show': 'Exibir', 'No Filter': 'Sem filtro',
    'Search for an owner...': 'Pesquisar responsável…'
  };
  var dialogButtons = {
    'Confirm': 'Confirmar', 'Cancel': 'Cancelar', 'Delete': 'Excluir',
    'Kill': 'Encerrar', 'Clear': 'Limpar', 'Close': 'Fechar'
  };
  // Somente mensagens estáticas emitidas pelos scripts nativos. Não há
  // substituição parcial: um texto que contenha nomes ou valores é preservado.
  var messages = {
    'All connections for this line have been killed.': 'Todas as conexões desta conta foram encerradas.',
    'An error occured while mapping streams.': 'Ocorreu um erro ao mapear os canais.',
    'An error occured while processing your request.': 'Ocorreu um erro ao processar sua solicitação.',
    'An invalid directory was entered, please use another.': 'A pasta informada é inválida. Escolha outra.',
    'Are you sure you want to clear the Redis database? This will drop all connections.': 'Deseja limpar o banco do Redis? Todas as conexões serão encerradas.',
    'Are you sure you want to delete these episodes?': 'Deseja excluir estes episódios?',
    'Are you sure you want to delete these movies?': 'Deseja excluir estes filmes?',
    'Are you sure you want to delete these streams?': 'Deseja excluir estes canais?',
    'Are you sure you want to delete this series and all episodes?': 'Deseja excluir esta série e todos os episódios?',
    'Are you sure you want to delete this stream?': 'Deseja excluir este canal?',
    'Are you sure you want to kill all connections for this line?': 'Deseja encerrar todas as conexões desta conta?',
    'Are you sure you want to kill all connections?': 'Deseja encerrar todas as conexões?',
    'Cache has been completely disabled!': 'O cache foi desativado por completo.',
    'Cache has been enabled!': 'O cache foi ativado.',
    'Connection has been killed.': 'A conexão foi encerrada.',
    'Connections have been killed.': 'As conexões foram encerradas.',
    'Could not process M3U file, please use another.': 'Não foi possível processar o arquivo M3U. Escolha outro.',
    'Credits could not be adjusted.': 'Não foi possível ajustar os créditos.',
    'Credits have been adjusted.': 'Os créditos foram ajustados.',
    'Enter a series name.': 'Informe o nome da série.',
    'Episodes have been deleted.': 'Os episódios foram excluídos.',
    'Episodes have been queued for re-encoding.': 'Os episódios foram adicionados à fila de recodificação.',
    'Episodes have started endoding.': 'A codificação dos episódios foi iniciada.',
    'Episodes have stopped encoding.': 'A codificação dos episódios foi interrompida.',
    'Fingerprint signal has been sent.': 'O sinal de identificação foi enviado.',
    'Generating CSV report...': 'Gerando relatório CSV…',
    'Handler has been completely disabled!': 'O gerenciador de conexões foi desativado por completo.',
    'Handler has been enabled!': 'O gerenciador de conexões foi ativado.',
    'Individual actions disabled in multi-select mode.': 'As ações individuais estão desativadas enquanto há vários itens selecionados.',
    'Item has been saved.': 'O item foi salvo.',
    'Line has been banned.': 'A conta foi bloqueada.',
    'Line has been disabled.': 'A conta foi desativada.',
    'Line has been enabled.': 'A conta foi ativada.',
    'Line has been unbanned.': 'A conta foi desbloqueada.',
    'Movies have been deleted.': 'Os filmes foram excluídos.',
    'Movies have been queued for re-encoding.': 'Os filmes foram adicionados à fila de recodificação.',
    'Movies have started endoding.': 'A codificação dos filmes foi iniciada.',
    'Movies have stopped encoding.': 'A codificação dos filmes foi interrompida.',
    'No new episodes could be found in the playlist or folder.': 'Nenhum episódio novo foi encontrado na lista ou na pasta.',
    'Please ensure the source is a local file before symlinking.': 'Para criar um link simbólico, a fonte precisa ser um arquivo local.',
    'Please ensure you enter both a title and message.': 'Informe o título e a mensagem.',
    'Please enter a description.': 'Informe uma descrição.',
    'Please enter a title for the recorded event.': 'Informe um título para a gravação.',
    'Please enter a valid IP address / CIDR.': 'Informe um endereço IP ou bloco CIDR válido.',
    'Please enter a valid MAC address.': 'Informe um endereço MAC válido.',
    'Please enter a valid date.': 'Informe uma data válida.',
    'Please enter a valid email address.': 'Informe um endereço de e-mail válido.',
    'Please enter an access code.': 'Informe um código de acesso.',
    'Please generate a key.': 'Gere uma chave.',
    'Please select a M3U file to upload.': 'Selecione um arquivo M3U para enviar.',
    'Please select a destination server to record the event to.': 'Selecione o servidor de destino da gravação.',
    'Please select a member group.': 'Selecione um grupo de usuários.',
    'Please select a playlist to upload & review.': 'Selecione uma lista para enviar e revisar.',
    'Please select a source server to record the event from.': 'Selecione o servidor de origem da gravação.',
    'Please select at least one source for your channel.': 'Selecione ao menos uma fonte para o canal.',
    'Please select at least one source for your movie.': 'Selecione ao menos uma fonte para o filme.',
    'Please select at least one source for your station.': 'Selecione ao menos uma fonte para a estação.',
    'Please select at least one source for your stream.': 'Selecione ao menos uma fonte para o canal.',
    'Please select both a source and destination.': 'Selecione a origem e o destino.',
    'Quick tool was successfully executed.': 'A ferramenta rápida foi executada.',
    'Redis database has been cleared!': 'O banco do Redis foi limpo.',
    'Regenerating cache in the background...': 'Recriando o cache em segundo plano…',
    'Required entry fields have not been populated. Please check the form.': 'Preencha os campos obrigatórios e confira o formulário.',
    'Select at least one stream to edit.': 'Selecione ao menos um canal para editar.',
    'Series successfully deleted.': 'A série foi excluída.',
    'Sorry, this code is reserved for system functions.': 'Este código é reservado para funções do sistema.',
    'Stream icon has been set.': 'O ícone do canal foi definido.',
    'Stream map complete. Please select relevant streams from the table.': 'O mapeamento foi concluído. Selecione os canais desejados na tabela.',
    'Stream map has started, this can take a while depending on how many streams are present.': 'O mapeamento foi iniciado. O tempo necessário depende da quantidade de canais.',
    "Stream mapping didn't return any information.": 'O mapeamento não retornou informações.',
    'Stream monitor logs have been cleared.': 'Os registros de monitoramento dos canais foram limpos.',
    'Stream successfully deleted.': 'O canal foi excluído.',
    'Stream successfully restarted.': 'O canal foi reiniciado.',
    'Stream successfully started.': 'O canal foi iniciado.',
    'Stream successfully stopped.': 'O canal foi interrompido.',
    'Streams have been deleted.': 'Os canais foram excluídos.',
    'Streams have been restarted.': 'Os canais foram reiniciados.',
    'Streams have been started.': 'Os canais foram iniciados.',
    'Streams have been stopped.': 'Os canais foram interrompidos.',
    'The MAC address you entered is already in use.': 'O endereço MAC informado já está em uso.',
    'The paired user does not exist! Please unlink it.': 'O usuário vinculado não existe. Remova o vínculo.',
    'The username you selected already exists. Please use another.': 'O nome de usuário informado já existe. Escolha outro.',
    'This HMAC Key already exists, please use another.': 'Esta chave HMAC já existe. Use outra.',
    'This IP address is already in the database. Please use another.': 'Este endereço IP já está cadastrado. Use outro.',
    'This ISP has already been blocked.': 'Este provedor de internet já está bloqueado.',
    'This access code already exists, please use another.': 'Este código de acesso já existe. Use outro.',
    'This directory is already being watched, please use another.': 'Esta pasta já está sendo monitorada. Escolha outra.',
    'This group name is already in use. Please use another.': 'Este nome de grupo já está em uso. Escolha outro.',
    'This library is already being synced, please use another.': 'Esta biblioteca já está sendo sincronizada. Escolha outra.',
    'This movie already exists in your database. Please use another name.': 'Este filme já está cadastrado. Use outro nome.',
    'This package name is already in use. Please use another.': 'Este nome de pacote já está em uso. Escolha outro.',
    'This provider is already being tracked on the system.': 'Este provedor já está sendo acompanhado pelo sistema.',
    'This series already exists in your database.': 'Esta série já está cadastrada.',
    'This station source is already in your database. Please use another URL.': 'Esta fonte de estação já está cadastrada. Use outra URL.',
    'This stream source is already in your database. Please use another URL.': 'Esta fonte de canal já está cadastrada. Use outra URL.',
    'User has been disabled.': 'O usuário foi desativado.',
    'User has been enabled.': 'O usuário foi ativado.',
    'You already have an empty row.': 'Já existe uma linha vazia.',
    'Your access code needs to be at least 8 characters long.': 'O código de acesso precisa ter pelo menos 8 caracteres.',
    'Your report has been submitted.': 'O relatório foi enviado.'
  };
  var headingSelector = '#restartServicesLabel,#epgBrowserLabel,#providerStreamsLabel,#providerMoviesLabel,#epgPiconLabel,#failuresLabel,.bs-domains #modalLabel,.creditsModal h4';
  var controlSelector = '.creditsModal label,.creditsModal button,.bs-picon-modal-center button,#programmeRecord,.bs-failures-modal-center button';
  var fieldSelector = ['title', 'cover', 'backdrop_path', 'plot', 'cast', 'director', 'genre', 'release_date', 'episode_run_time', 'youtube_trailer', 'rating', 'timezone', 'disable_tmdb', 'ignore_no_match', 'show_duplicates', 'keep_logs'].map(function (id) { return 'label[for="' + id + '"]'; }).join(',');
  var protectedSelector = '.nav-user,.pro-user-name,tbody,input,textarea,select,option,[contenteditable="true"],script,style';

  function within(root, selector) {
    var elements = [];
    if (root.nodeType === 1 && root.matches(selector)) elements.push(root);
    return elements.concat(Array.from(root.querySelectorAll(selector)));
  }
  function lookup(dictionary, text) {
    var key = text.replace(/\s+/g, ' ').trim();
    return Object.prototype.hasOwnProperty.call(dictionary, key) ? dictionary[key] : null;
  }
  function translateNode(node, dictionary) {
    var text = node.nodeValue, translated = lookup(dictionary, text);
    if (translated) node.nodeValue = text.replace(/\S[\s\S]*\S|\S/, translated);
  }
  function translateElement(element, dictionary, descendants) {
    if (element.closest(protectedSelector)) return;
    Array.from(element.childNodes).forEach(function (node) {
      if (node.nodeType === 3) translateNode(node, dictionary);
      else if (descendants && node.nodeType === 1 && !node.matches('br,svg,i,.close-jq-toast-single') && !node.closest(protectedSelector)) translateElement(node, dictionary, true);
    });
  }
  function translateGroup(root, selector, dictionary, descendants) {
    within(root, selector).forEach(function (element) { translateElement(element, dictionary, descendants); });
  }
  function translateAccounts(root) {
    var document = root.ownerDocument || root;
    var table = document.getElementById('datatable-users');
    if (!table) return;
    translateGroup(root, '#datatable-users thead th', accountColumns, true);
    translateGroup(root, '.page-title-box button,#collapse_filters > label', accountControls, true);
    translateGroup(root, '#select2-user_filter-container,[id^="select2-user_filter-result-"]', accountControls, true);
    within(root, '#select2-user_reseller-container').forEach(function (container) {
      var ownerSelect = document.getElementById('user_reseller');
      if (container.querySelector('.select2-selection__placeholder') || (ownerSelect && ownerSelect.value === '')) translateElement(container, accountControls, true);
    });
    within(root, '#user_filter option').forEach(function (option) {
      Array.from(option.childNodes).forEach(function (node) { if (node.nodeType === 3) translateNode(node, accountControls); });
    });
    // Só a opção vazia é uma instrução do seletor de responsáveis. As demais
    // opções e os resultados da busca são nomes cadastrados pelo administrador.
    within(root, '#user_reseller option').forEach(function (option) {
      if (option.value === '') Array.from(option.childNodes).forEach(function (node) { if (node.nodeType === 3) translateNode(node, accountControls); });
    });
    // "Never" é um marcador nativo apenas na coluna de data da última conexão.
    // As outras células, inclusive usuários chamados "Never", são preservadas.
    var headers = Array.from(table.querySelectorAll('thead tr:last-child th'));
    var connectionIndex = headers.findIndex(function (header) { return /^(?:last connection|última conexão)$/i.test(header.textContent.trim()); });
    if (connectionIndex < 0) return;
    var rows = root === document || root === table || (root.nodeType === 1 && root.contains(table)) ? table.querySelectorAll('tbody tr') : within(root, '#datatable-users tbody tr');
    if (root.nodeType === 1 && root.closest('#datatable-users tbody tr')) rows = [root.closest('#datatable-users tbody tr')];
    Array.from(rows).forEach(function (row) {
      var cell = row.children[connectionIndex];
      if (!cell || cell.tagName !== 'TD' || cell.childElementCount || !cell.classList.contains('dt-center')) return;
      Array.from(cell.childNodes).forEach(function (node) { if (node.nodeType === 3) translateNode(node, {'Never': 'Nunca'}); });
    });
  }
  function enhance(root) {
    root = root || global.document;
    if (root.nodeType === 3) root = root.parentElement;
    if (!root || !root.querySelectorAll) return;
    translateGroup(root, headingSelector, modalHeadings, true);
    translateGroup(root, controlSelector, modalControls, true);
    translateGroup(root, fieldSelector, formLabels, false);
    translateGroup(root, 'table thead th', columns, true);
    translateGroup(root, '.navigation-menu a,.navigation-menu a > span,.page-title,.header-title', navigation, false);
    translateAccounts(root);
    translateGroup(root, '.jBox-Confirm .jBox-content,.jq-toast-single', messages, true);
    translateGroup(root, '.jBox-Confirm .jBox-title,.jBox-Confirm .jBox-button,.jBox-Confirm .jBox-Confirm-button', dialogButtons, true);
    // Atributos aqui pertencem somente aos controles conhecidos dos diálogos.
    within(root, controlSelector).forEach(function (element) {
      ['title', 'data-original-title', 'aria-label'].forEach(function (attribute) {
        var value = element.getAttribute(attribute);
        if (value) {
          var translated = lookup(modalControls, value);
          if (translated) element.setAttribute(attribute, translated);
        }
      });
    });
  }

  global.NaxxPanelTranslations = { enhance: enhance };
  if (global.document.readyState === 'loading') {
    global.document.addEventListener('DOMContentLoaded', function () { enhance(global.document); }, {once:true});
  } else enhance(global.document);
})(window);

/* Melhoria da janela nativa. A conta, as opções e a geração do link continuam no XUI. */
(function () {
  'use strict';
  if (window.NaxxPlaylistDownloadUI) {
    window.NaxxPlaylistDownloadUI.refresh();
    return;
  }

  var states = new WeakMap();
  var sequence = 0;
  var scanTimer = null;
  var pollTimer = null;
  var jqueryBound = false;
  var contentLabels = {
    live: 'Canais ao vivo', movie: 'Filmes', created_live: 'Canais criados',
    radio_streams: 'Rádios', series: 'Séries'
  };

  function text(node, value) {
    if (node && node.textContent !== value) node.textContent = value;
  }

  function appendDescription(node, id) {
    var ids = (node.getAttribute('aria-describedby') || '').split(/\s+/).filter(Boolean);
    if (ids.indexOf(id) < 0) {
      ids.push(id);
      node.setAttribute('aria-describedby', ids.join(' '));
    }
  }

  function help(parent, className, message, id) {
    var node = document.createElement('p');
    node.className = className;
    if (id) node.id = id;
    node.textContent = message;
    parent.appendChild(node);
    return node;
  }

  function labelButton(button, label) {
    button.type = 'button';
    var node = button.querySelector('.naxx-playlist-action-label');
    if (!node) {
      node = document.createElement('span');
      node.className = 'naxx-playlist-action-label';
      button.appendChild(node);
    }
    text(node, label);
    button.setAttribute('aria-label', label);
    button.title = label;
    var icon = button.querySelector('i');
    if (icon && icon.getAttribute('aria-hidden') !== 'true') icon.setAttribute('aria-hidden', 'true');
  }

  function safeURL(value) {
    if (!value || value.trim() !== value || /[\u0000-\u001f\u007f\\]/.test(value)) return false;
    try {
      var absolute = /^https?:\/\//i.test(value);
      if (!absolute && !/^(?:\/(?!\/)|\.\.?\/|\?)/.test(value)) return false;
      var url = new URL(value, window.location.href);
      return /^(?:http:|https:)$/.test(url.protocol) &&
        (absolute || url.origin === window.location.origin);
    } catch (error) {
      return false;
    }
  }

  function payload(state) {
    var value = state.url.value;
    if (!value) return {kind: 'empty', text: ''};
    if (safeURL(value)) return {kind: 'url', text: value};
    // Alguns formatos nativos produzem um comando de instalação. Ele só pode
    // ser copiado; o endereço contido nele nunca é executado por esta melhoria.
    var option = state.format.options[state.format.selectedIndex];
    var template = option && option.getAttribute('data-text');
    if (template && template.split('{DEVICE_LINK}').length === 2) {
      var parts = template.split('{DEVICE_LINK}');
      if (value.indexOf(parts[0]) === 0 &&
          value.slice(value.length - parts[1].length) === parts[1]) {
        var quoted = value.slice(parts[0].length, parts[1].length ? -parts[1].length : undefined);
        var address = quoted.slice(1, -1);
        if (quoted.charAt(0) === '"' && quoted.charAt(quoted.length - 1) === '"' &&
            safeURL(address) && template.replace('{DEVICE_LINK}', '"' + address + '"') === value) {
          return {kind: 'command', text: value};
        }
      }
    }
    return {kind: 'invalid', text: ''};
  }

  function setFeedback(state, message, kind) {
    text(state.feedback, message);
    state.feedback.setAttribute('data-state', kind);
  }

  function selectedLabels(select) {
    return Array.prototype.filter.call(select.options, function (option) {
      return option.selected && option.value;
    }).map(function (option) { return option.textContent.trim(); });
  }

  function update(state) {
    if (!currentState(state)) return;
    var current = payload(state);
    var signature = state.url.value + '\n' + state.format.value + '\n' + selectedLabels(state.content).join('|');
    if (signature !== state.signature) {
      state.signature = signature;
      state.feedbackKind = '';
    }
    var command = current.kind === 'command';
    var copyDisabled = current.kind !== 'url' && !command;
    if (state.copy.disabled !== copyDisabled) state.copy.disabled = copyDisabled;
    // O gerador nativo é o único responsável por habilitar o download. Apenas
    // bloqueamos resultados vazios, comandos ou endereços não navegáveis.
    if (current.kind !== 'url' && !state.download.disabled) state.download.disabled = true;
    state.copy.setAttribute('aria-disabled', String(state.copy.disabled));
    state.download.setAttribute('aria-disabled', String(state.download.disabled));
    labelButton(state.copy, state.feedbackKind === 'copied' ? 'Copiado!' : command ? 'Copiar comando' : 'Copiar link');
    labelButton(state.download, 'Baixar playlist');
    text(state.linkLabel, command ? 'Comando do dispositivo' : 'Link da playlist');
    state.url.setAttribute('aria-label', command ? 'Comando do dispositivo' : 'Link da playlist');
    state.url.placeholder = 'Selecione o formato para gerar o link.';
    var rendered = state.modal.querySelector('#select2-download_type-container');
    if (rendered && !state.format.value) text(rendered, 'Selecione um formato');
    var search = state.content.parentElement.querySelector('.select2-search__field');
    if (search) search.placeholder = 'Todos os conteúdos';
    var selected = selectedLabels(state.content);
    text(state.summary, selected.length ? 'Conteúdo: ' + selected.join(', ') + '.' : 'Todos os conteúdos permitidos para esta conta.');
    if (!state.feedbackKind) {
      if (current.kind === 'url') setFeedback(state, 'Link pronto. Copie ou baixe a playlist.', 'ready');
      else if (command) setFeedback(state, 'Comando pronto. Copie para o dispositivo compatível.', 'ready');
      else if (current.kind === 'invalid') setFeedback(state, 'O link gerado não é válido. Selecione a conta novamente.', 'error');
      else setFeedback(state, 'Escolha um formato para gerar o link desta conta.', 'empty');
    }
  }

  function copyFallback(state, expected) {
    if (!currentState(state) || state.url.value !== expected) return false;
    var previousFocus = document.activeElement;
    var start = state.url.selectionStart;
    var end = state.url.selectionEnd;
    try {
      state.url.focus();
      state.url.select();
      state.url.setSelectionRange(0, state.url.value.length);
      return Boolean(document.execCommand && document.execCommand('copy'));
    } catch (error) {
      return false;
    } finally {
      if (start !== null && end !== null) {
        try { state.url.setSelectionRange(start, end); } catch (error) { /* Campo nativo sem seleção. */ }
      }
      if (previousFocus && previousFocus.isConnected && previousFocus.focus) previousFocus.focus();
    }
  }

  function copy(state, event) {
    event.preventDefault();
    event.stopImmediatePropagation();
    update(state);
    var current = payload(state);
    if (state.copy.disabled) return;
    var operation;
    try {
      operation = window.navigator.clipboard && window.navigator.clipboard.writeText ?
        Promise.resolve(window.navigator.clipboard.writeText(current.text)).then(function () { return true; }, function () {
          return copyFallback(state, current.text);
        }) : Promise.resolve(copyFallback(state, current.text));
    } catch (error) {
      operation = Promise.resolve(copyFallback(state, current.text));
    }
    operation.then(function (success) {
      if (!currentState(state) || state.url.value !== current.text) return;
      state.feedbackKind = success ? 'copied' : 'copy-error';
      setFeedback(state, success ? (current.kind === 'command' ? 'Comando copiado.' : 'Link copiado.') :
        'Não foi possível copiar. Selecione o campo e copie manualmente.', success ? 'success' : 'error');
      update(state);
    });
  }

  function currentState(state) {
    return state.modal.isConnected && states.get(state.modal) === state && state.modal.contains(state.url);
  }

  function release(state) {
    state.copy.removeEventListener('click', state.copyHandler, true);
    state.download.removeEventListener('click', state.downloadHandler, true);
    state.modal.removeEventListener('change', state.changeHandler);
    state.url.removeEventListener('input', state.changeHandler);
    states.delete(state.modal);
  }

  function enhance(modal) {
    var previous = states.get(modal);
    if (previous) {
      if (previous.url === modal.querySelector('#download_url') &&
          previous.copy === modal.querySelector('button[onclick*="copyDownload"]') &&
          previous.download === modal.querySelector('#download_button') &&
          previous.format === modal.querySelector('#download_type') &&
          previous.content === modal.querySelector('#output_type')) return previous;
      release(previous);
    }
    var format = modal.querySelector('#download_type');
    var content = modal.querySelector('#output_type');
    var url = modal.querySelector('#download_url');
    var download = modal.querySelector('#download_button');
    var copyButton = modal.querySelector('button[onclick*="copyDownload"]');
    var body = modal.querySelector('.modal-body');
    if (!format || !content || !url || !download || !copyButton || !body) return null;
    Array.prototype.forEach.call(modal.querySelectorAll('.naxx-playlist-intro,.naxx-playlist-help,.naxx-playlist-summary,.naxx-playlist-link-label,.naxx-playlist-feedback,.naxx-playlist-security'), function (node) { node.remove(); });
    [format, content, url].forEach(function (node) {
      var descriptions = (node.getAttribute('aria-describedby') || '').split(/\s+/).filter(function (item) {
        return item && !/^naxx-playlist-\d+-(?:format|content|feedback)$/.test(item);
      });
      if (descriptions.length) node.setAttribute('aria-describedby', descriptions.join(' '));
      else node.removeAttribute('aria-describedby');
    });
    // Não substituir controles: o XUI mantém os eventos e o Select2 existentes.
    var id = 'naxx-playlist-' + (++sequence);
    var state = {modal: modal, format: format, content: content, url: url,
      copy: copyButton, download: download, signature: null, feedbackKind: ''};
    states.set(modal, state);
    modal.classList.add('naxx-playlist-modal');
    var title = modal.querySelector('.modal-title');
    text(title, 'Baixar playlist');
    if (title && title.id) modal.setAttribute('aria-labelledby', title.id);
    var close = modal.querySelector('[data-dismiss="modal"]');
    if (close) close.setAttribute('aria-label', 'Fechar');
    var intro = document.createElement('p');
    intro.className = 'naxx-playlist-intro';
    intro.textContent = 'Escolha o formato compatível com o aplicativo ou dispositivo do cliente.';
    body.insertBefore(intro, body.firstChild);
    text(modal.querySelector('label[for="download_type"]'), 'Formato da playlist');
    text(modal.querySelector('label[for="output_type"]'), 'Conteúdo da lista');
    format.setAttribute('aria-label', 'Formato da playlist');
    format.setAttribute('data-placeholder', 'Selecione um formato');
    content.setAttribute('aria-label', 'Conteúdo da lista');
    content.setAttribute('data-placeholder', 'Todos os conteúdos');
    Array.prototype.forEach.call(content.options, function (option) {
      if (contentLabels[option.value]) text(option, contentLabels[option.value]);
    });
    var formatHelp = help(format.parentElement, 'naxx-playlist-help',
      'M3U e M3U Plus atendem à maioria dos aplicativos. HLS usa M3U8; MPEG-TS usa TS. Para receptores, escolha o modelo.', id + '-format');
    var contentHelp = help(content.parentElement, 'naxx-playlist-help',
      'Opcional. Selecione os tipos desejados ou deixe vazio para incluir todos.', id + '-content');
    appendDescription(format, formatHelp.id);
    appendDescription(content, contentHelp.id);
    state.summary = help(content.parentElement, 'naxx-playlist-summary', '');
    var group = url.closest('.input-group');
    if (group) group.classList.add('naxx-playlist-url-group');
    var actions = copyButton.parentElement;
    if (actions) actions.classList.add('naxx-playlist-actions');
    state.linkLabel = document.createElement('label');
    state.linkLabel.className = 'naxx-playlist-link-label';
    state.linkLabel.htmlFor = url.id;
    state.linkLabel.textContent = 'Link da playlist';
    (group || url).parentElement.insertBefore(state.linkLabel, group || url);
    url.readOnly = true;
    url.autocomplete = 'off';
    url.spellcheck = false;
    url.setAttribute('autocapitalize', 'off');
    state.feedback = help(body, 'naxx-playlist-feedback', '', id + '-feedback');
    state.feedback.setAttribute('role', 'status');
    state.feedback.setAttribute('aria-live', 'polite');
    state.feedback.setAttribute('aria-atomic', 'true');
    appendDescription(url, state.feedback.id);
    help(body, 'naxx-playlist-security', 'Este link contém os dados de acesso da conta. Compartilhe apenas com o cliente.');
    state.copyHandler = function (event) { copy(state, event); };
    state.downloadHandler = function (event) {
      update(state);
      if (payload(state).kind !== 'url' || download.disabled) {
        event.preventDefault();
        event.stopImmediatePropagation();
        return;
      }
      // O onclick do XUI continua fazendo o download, com seu endereço intacto.
      window.setTimeout(function () {
        if (!currentState(state)) return;
        state.feedbackKind = 'download';
        setFeedback(state, 'Download solicitado. Verifique os downloads do navegador.', 'success');
      }, 0);
    };
    state.changeHandler = function () { state.feedbackKind = ''; schedule(); };
    copyButton.addEventListener('click', state.copyHandler, true);
    download.addEventListener('click', state.downloadHandler, true);
    modal.addEventListener('change', state.changeHandler);
    url.addEventListener('input', state.changeHandler);
    if (visible(modal)) defaultFormat(state);
    return state;
  }

  function visible(modal) {
    return !modal.hidden && (modal.classList.contains('show') || modal.getAttribute('aria-hidden') === 'false' ||
      Boolean(modal.style.display && modal.style.display !== 'none'));
  }

  function defaultFormat(state) {
    var jq = window.jQuery;
    if (!state || state.format.value || !jq || typeof window.openDownload !== 'function' ||
        typeof window.doDownload !== 'function') return;
    var account = jq(state.modal);
    if (!account.data('username') || !account.data('password')) return;
    var option = Array.prototype.find.call(state.format.options, function (item) {
      return item.value === 'm3u_plus' && !item.disabled;
    });
    if (!option) return;
    // O evento shown ocorre depois de openDownload definir os dados da conta.
    // O próprio XUI gera o link, com o formato que ele já oferece no seletor.
    jq(state.format).val(option.value).trigger('change');
  }

  function bindJquery() {
    var jq = window.jQuery;
    if (jqueryBound || !jq || !jq.fn || !jq.fn.on) return;
    jq(document).on('shown.bs.modal.naxxPlaylistDownload', '.downloadModal', function () {
      defaultFormat(enhance(this));
      schedule();
    });
    jq(document).on('hidden.bs.modal.naxxPlaylistDownload', '.downloadModal', schedule);
    // Select2 notifica mudanças através do jQuery, sem evento DOM obrigatório.
    jq(document).on('change.naxxPlaylistDownload', '.downloadModal #download_type,.downloadModal #output_type', schedule);
    jqueryBound = true;
  }

  function refresh() {
    scanTimer = null;
    bindJquery();
    var hasVisibleModal = false;
    Array.prototype.forEach.call(document.querySelectorAll('.downloadModal'), function (modal) {
      var state = enhance(modal);
      if (!state) return;
      update(state);
      if (visible(modal)) hasVisibleModal = true;
    });
    if (hasVisibleModal && pollTimer === null) {
      // .val() nativo não emite input. Observar apenas a janela aberta também
      // contempla a geração assíncrona, sem interceptar funções do painel.
      pollTimer = window.setTimeout(function () { pollTimer = null; refresh(); }, 220);
    } else if (!hasVisibleModal && pollTimer !== null) {
      window.clearTimeout(pollTimer);
      pollTimer = null;
    }
  }

  function schedule() {
    if (scanTimer === null) scanTimer = window.setTimeout(refresh, 0);
  }

  window.NaxxPlaylistDownloadUI = {refresh: refresh};
  var observer = new MutationObserver(function (mutations) {
    if (mutations.some(function (mutation) {
      var node = mutation.target;
      if (node.nodeType === 1 && node.closest('.downloadModal')) return true;
      return Array.prototype.some.call(mutation.addedNodes, function (added) {
        return added.nodeType === 1 && (added.matches('.downloadModal') || added.querySelector('.downloadModal'));
      });
    })) schedule();
  });
  function start() {
    refresh();
    observer.observe(document.documentElement, {childList: true, subtree: true, attributes: true,
      attributeFilter: ['class', 'style', 'aria-hidden', 'disabled', 'value', 'data-username', 'data-password']});
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start, {once: true});
  else start();
}());

/* Fonte, páginas maiores e seleção explícita da exclusão nativa em massa. */
(function () {
  'use strict';
  if (window.NaxxBulkDelete) { window.NaxxBulkDelete.enhance(); return; }
  var batch = 1000, maxPage = 5000, maxCatalog = 50000;
  var states = new Map(), bound = false;
  var definitions = {
    'datatable-md1': {size:'show_entries', selection:'rStreams', field:'streams', label:'canais', source:true},
    'datatable-md2': {size:'movie_show_entries', selection:'rMovies', field:'movies', label:'filmes'},
    'datatable-md3': {size:'line_show_entries', selection:'rLines', field:'lines', label:'contas'},
    'datatable-md4': {size:'series_show_entries', selection:'rSeries', field:'series', label:'séries'},
    'datatable-md5': {size:'episode_show_entries', selection:'rEpisodes', field:'episodes', label:'episódios'},
    'datatable-md6': {size:'radio_show_entries', selection:'rRadios', field:'radios', label:'rádios'},
    'datatable-md7': {size:'user_show_entries', selection:'rUsers', field:'users', label:'usuários'},
    'datatable-md8': {size:'mag_show_entries', selection:'rMAGs', field:'mags', label:'dispositivos MAG'},
    'datatable-md9': {size:'enigma_show_entries', selection:'rEnigmas', field:'enigmas', label:'dispositivos Enigma'}
  };
  var selector = Object.keys(definitions).map(function (id) { return '#' + id; }).join(',');

  function integer(value) {
    var number = typeof value === 'number' ? value : typeof value === 'string' && /^\d+$/.test(value) ? Number(value) : NaN;
    return Number.isSafeInteger(number) && number >= 0 ? number : NaN;
  }
  function idOf(row) {
    var id = Array.isArray(row) ? String(row[0]).replace(/<[^>]*>/g, '').trim() : '';
    return /^[1-9]\d*$/.test(id) && Number.isSafeInteger(Number(id)) ? id : null;
  }
  function text(state, message) {
    if (state.status.textContent !== message) state.status.textContent = message;
    if (state.status.hidden !== !message) state.status.hidden = !message;
  }
  function valid(state) { return states.get(state.table) === state && state.table.isConnected; }
  function sourceURL(host) {
    var url = new URL('naxx-update.php', window.location.href);
    url.searchParams.set('feature', 'stream-sources');
    if (host) url.searchParams.set('host', host);
    return url.href;
  }
  async function json(url, signal) {
    var response = await window.fetch(url, {credentials:'same-origin', cache:'no-store', signal:signal,
      headers:{'X-Requested-With':'XMLHttpRequest', 'Accept':'application/json'}});
    if (!response.ok || /\/(?:login|license)(?:[/?]|$)/.test(response.url || '')) {
      var error = new Error('request_failed'); error.status = response.status; throw error;
    }
    return response.json();
  }
  function signature(params, source) {
    var filters = Object.assign({}, params);
    delete filters.draw; delete filters.start; delete filters.length;
    return JSON.stringify([source, filters]);
  }
  function paramsFor(state, data) {
    var params = JSON.parse(JSON.stringify(data));
    var result = state.native.data(params, state.settings);
    if (result && typeof result === 'object') params = result;
    return params;
  }
  async function queryPage(state, params, start, length, signal) {
    var url = new URL(state.native.url, window.location.href);
    if (url.origin !== window.location.origin || !/\/table(?:\.php)?$/.test(url.pathname)) throw new Error('native_route');
    url.search = state.jq.param(Object.assign({}, params, {start:start, length:length}));
    var page = await json(url.href, signal);
    var total = integer(page.recordsTotal), filtered = integer(page.recordsFiltered);
    if (integer(page.draw) !== integer(params.draw) || !Number.isFinite(total) || !Number.isFinite(filtered) || filtered > total ||
        !Array.isArray(page.data) || page.data.length !== Math.min(length, Math.max(0, filtered - start))) throw new Error('native_page');
    return {total:total, filtered:filtered, rows:page.data};
  }
  function pageStart(start, length, filtered) {
    return start < filtered ? start : filtered ? Math.floor((filtered - 1) / length) * length : 0;
  }
  async function collect(state, params, source, signal) {
    var start = source ? 0 : integer(params.start), length = integer(params.length), ids = null;
    if (!Number.isFinite(start) || !Number.isFinite(length) || length < 1 || length > maxPage) throw new Error('length');
    if (source) {
      var lookup = await json(sourceURL(source), signal);
      if (!lookup || !lookup.ok || !Array.isArray(lookup.ids) || lookup.ids.length > maxCatalog ||
          lookup.ids.some(function (id) { return !Number.isSafeInteger(id) || id < 1; })) throw new Error('source_ids');
      ids = new Set(lookup.ids.map(String));
    }
    var result = null, seen = new Set();
    do {
      if (signal.aborted) throw new Error('cancelled');
      var count = source ? (ids.size ? batch : 1) : Math.min(batch, length - (result ? result.rows.length : 0));
      var page = await queryPage(state, params, start, count, signal);
      if (!result) {
        var first = source ? 0 : pageStart(start, length, page.filtered);
        result = {total:page.total, filtered:page.filtered, rows:[], start:first};
        if (first !== start) { start = first; if (page.filtered) continue; }
      }
      if (result.total !== page.total || result.filtered !== page.filtered || (source && page.filtered > maxCatalog)) throw new Error('catalog_changed');
      page.rows.forEach(function (row) {
        var id = idOf(row);
        if (!id || seen.has(id)) throw new Error('catalog_changed');
        seen.add(id);
        if (!ids || ids.has(id)) { result.rows.push(row); if (ids) ids.delete(id); }
      });
      start += page.rows.length;
      if (start >= page.filtered || !page.rows.length || (ids ? !ids.size : result.rows.length >= length)) break;
    } while (true);
    if (source) result.filtered = result.rows.length;
    return result;
  }
  function abort(state) {
    if (state.request) state.request.abort();
    state.request = null;
  }
  function useAjax(state, length) {
    if (state.source || Number(length) > batch) state.settings.ajax = state.ajax;
    else if (state.settings.ajax === state.ajax) { abort(state); state.settings.ajax = state.native; }
  }
  function runAjax(state, data, callback) {
    abort(state);
    var params = paramsFor(state, data), source = state.source;
    var start = integer(params.start), length = integer(params.length), key = signature(params, source);
    var controller = new AbortController(), timeout = false;
    var request = {readyState:1, abort:function () { controller.abort(); request.readyState = 0; }};
    state.request = request;
    var timer = window.setTimeout(function () { timeout = true; controller.abort(); }, 45000);
    var cache = state.cache;
    var reuse = source && cache && cache.key === key && cache.expires > Date.now() &&
      (cache.start !== start || cache.length !== length);
    text(state, source ? 'Buscando canais da fonte…' : 'Carregando a página…');
    var loading = reuse ? Promise.resolve(cache.result) : collect(state, params, source, controller.signal);
    loading.then(function (result) {
      if (!valid(state) || state.request !== request || controller.signal.aborted) return;
      var first = source ? pageStart(start, length, result.filtered) : result.start;
      if (first !== start) { state.settings._iDisplayStart = first; data.start = first; }
      if (source) state.cache = {key:key, result:result, start:first, length:length, expires:reuse ? cache.expires : Date.now() + 15000};
      text(state, '');
      callback({draw:integer(data.draw), recordsTotal:result.total, recordsFiltered:result.filtered,
        data:source ? result.rows.slice(first, first + length) : result.rows});
    }, function () {
      if (!valid(state) || state.request !== request || (!timeout && controller.signal.aborted)) return;
      state.cache = null;
      text(state, 'Não foi possível carregar a lista. Atualize a página ou ajuste os filtros. A seleção anterior foi mantida.');
      callback({draw:integer(data.draw), recordsTotal:0, recordsFiltered:0, data:[]});
    }).finally(function () {
      window.clearTimeout(timer); request.readyState = 4;
      if (state.request === request) state.request = null;
    });
    return request;
  }

  async function filteredIds(table, signal) {
    var state = states.get(table);
    if (!state || !valid(state) || state.request || !state.api.ajax.params) throw new Error('table_loading');
    var current = state.api.ajax.params();
    if (!current) throw new Error('table_loading');
    var params = paramsFor(state, current), source = state.source, key = signature(params, source), rows = [];
    if (source) rows = (await collect(state, Object.assign({}, params, {start:0, length:batch}), source, signal)).rows;
    else {
      var total, filtered;
      for (var start = 0; ; start += batch) {
        if (signal.aborted) throw new Error('cancelled');
        var page = await queryPage(state, params, start, batch, signal);
        if (page.filtered > maxCatalog) throw new Error('catalog_limit');
        if (start && (total !== page.total || filtered !== page.filtered)) throw new Error('catalog_changed');
        total = page.total; filtered = page.filtered;
        rows = rows.concat(page.rows);
        if (rows.length >= filtered) break;
      }
    }
    var seen = new Set(), ids = rows.map(function (row) {
      var id = idOf(row); if (!id || seen.has(id)) throw new Error('catalog_changed'); seen.add(id); return id;
    });
    current = state.api.ajax.params();
    if (signal.aborted || !valid(state) || state.request || !current || signature(paramsFor(state, current), state.source) !== key) throw new Error('selection_changed');
    return ids;
  }
  function addOption(select, value, label) {
    if (Array.prototype.some.call(select.options, function (option) { return option.value === value; })) return;
    var option = document.createElement('option'); option.value = value; option.textContent = label; select.appendChild(option);
  }
  function sizeControls(state, length) {
    var main = document.getElementById(state.def.size);
    var generated = document.querySelector('select[name="' + state.table.id + '_length"][aria-controls="' + state.table.id + '"]');
    [main, generated].forEach(function (control) {
      if (!control) return;
      [['250','250'],['500','500'],['1000','1.000'],['2000','2.000'],['5000','5.000']].forEach(function (size) { addOption(control, size[0], size[1]); });
      var value = String(length);
      if (control.value !== value && Array.prototype.some.call(control.options, function (option) { return option.value === value; })) {
        control.value = value;
        if (control.classList.contains('select2-hidden-accessible')) state.jq(control).trigger('change.select2');
      }
    });
  }
  function selection(state) { return Array.isArray(window[state.def.selection]) ? window[state.def.selection] : null; }
  function sync(state) {
    var selected = selection(state);
    if (!selected) return;
    var ids = new Set(selected.map(String)), field = state.form.querySelector('[name="' + state.def.field + '"]');
    if (field) field.value = JSON.stringify(selected);
    state.api.rows({page:'current'}).every(function () {
      var row = this.node(), id = idOf(this.data());
      if (row) ['selectedfilter','ui-selected','selected'].forEach(function (name) { row.classList.toggle(name, Boolean(id && ids.has(id))); });
    });
    var message = selected.length + ' selecionados para excluir. A seleção é mantida ao mudar os filtros.';
    if (state.summary.textContent !== message) state.summary.textContent = message;
    state.scope.hidden = !state.source || !new URLSearchParams(window.location.search).has('naxx_cleanup');
  }
  function sourceControl(state) {
    var box = document.createElement('div'); box.className = 'naxx-bulk-source'; box.hidden = true;
    var label = document.createElement('label'); label.className = 'sr-only'; label.htmlFor = 'naxx-bulk-source'; label.textContent = 'Fonte dos canais ao vivo'; box.appendChild(label);
    var select = document.createElement('select'); select.className = 'form-control'; select.id = label.htmlFor;
    select.title = label.textContent;
    addOption(select, '', 'Todas as fontes'); box.appendChild(select);
    var category = state.form.querySelector('#stream_category_search');
    if (category && category.parentElement.parentElement === state.filters) category.parentElement.after(box);
    else {
      var tableCell = state.table;
      while (tableCell.parentElement && tableCell.parentElement !== state.filters) tableCell = tableCell.parentElement;
      if (tableCell.parentElement === state.filters) state.filters.insertBefore(box, tableCell);
      else state.filters.insertBefore(box, state.filters.firstChild);
    }
    state.sourceBox = box; state.sourceSelect = select;
    json(sourceURL(''), state.list.signal).then(function (result) {
      if (!valid(state)) return;
      if (!result || !result.ok || !Array.isArray(result.hosts)) throw new Error('source_hosts');
      result.hosts.filter(function (host) { return typeof host === 'string' && host.length > 0 && host.length <= 253 && !/[\u0000-\u0020\u007f]/.test(host); })
        .forEach(function (host) { addOption(select, host, host); });
      select.disabled = select.options.length < 2; box.hidden = false;
      if (state.jq.fn.select2) state.jq(select).select2({width:'100%'});
      state.jq(select).on('change.naxxBulkDelete', function () {
        abort(state); state.cache = null; state.source = select.value;
        useAjax(state, state.api.page.len()); state.api.ajax.reload(null, true); sync(state);
      });
    }).catch(function (error) {
      if (valid(state) && error.status !== 403) text(state, 'Não foi possível carregar o filtro de fonte. Os demais filtros continuam disponíveis.');
    });
  }
  function destroy(state) {
    abort(state); state.list.abort();
    state.jq(state.table).off('.naxxBulkDelete');
    if (state.nativeToggle) state.nativeToggle.removeEventListener('click', state.toggleHandler);
    if (state.sourceSelect) {
      state.jq(state.sourceSelect).off('.naxxBulkDelete');
      if (state.sourceSelect.classList.contains('select2-hidden-accessible')) state.jq(state.sourceSelect).select2('destroy');
    }
    if (state.settings.ajax === state.ajax) state.settings.ajax = state.native;
    state.filters.classList.remove('naxx-bulk-delete-filters');
    if (state.sourceBox) state.sourceBox.remove();
    state.summary.remove(); state.scope.remove(); state.status.remove(); states.delete(state.table);
  }
  function mount(table, jq, api, settings, initializing) {
    var native = settings.ajax, form = table.closest('form'), filters = form && form.querySelector('.row');
    var def = definitions[table.id];
    if (!form || !filters || !native || typeof native.url !== 'string' || typeof native.data !== 'function') return;
    var summary = document.createElement('p'); summary.className = 'naxx-bulk-selection-summary text-muted';
    var scope = document.createElement('p'); scope.className = 'naxx-bulk-scope-help text-muted'; scope.hidden = true;
    scope.textContent = 'O filtro de fonte afeta a tabela e a seleção manual. A ação Deletar Tudo inclui todo o conteúdo, mesmo com esse filtro.';
    var status = document.createElement('p'); status.className = 'naxx-bulk-filter-status text-muted'; status.hidden = true; status.setAttribute('role', 'status');
    // Fora da row que contém a tabela: mantém o agrupamento e a rolagem nativos.
    filters.before(summary); summary.after(scope); scope.after(status);
    filters.classList.add('naxx-bulk-delete-filters');
    var state = {table:table, def:def, form:form, filters:filters, api:api, settings:settings, native:native, jq:jq,
      source:'', cache:null, request:null, summary:summary, scope:scope, status:status, list:new AbortController()};
    state.ajax = function (data, callback) { return runAjax(state, data, callback); };
    states.set(table, state);
    jq(table).on('length.dt.naxxBulkDelete', function (_event, eventSettings, length) {
      if (eventSettings !== settings) return;
      sizeControls(state, length); useAjax(state, length);
    });
    jq(table).on('draw.dt.naxxBulkDelete', function () { sizeControls(state, api.page.len()); sync(state); });
    jq(table).on('destroy.dt.naxxBulkDelete', function () { if (valid(state)) destroy(state); });
    // Selectable e o botão original mantêm os callbacks nativos; só atualizamos
    // o resumo após a seleção de linhas, sem interferir no envio do formulário.
    jq(table).on('selectablestop.naxxBulkDelete', function () { sync(state); });
    var nativeToggle = form.querySelector('button[onclick^="toggle"]');
    if (nativeToggle) {
      nativeToggle.title = 'Inverter seleção dos itens visíveis'; nativeToggle.setAttribute('aria-label', nativeToggle.title);
      state.nativeToggle = nativeToggle; state.toggleHandler = function () { sync(state); };
      nativeToggle.addEventListener('click', state.toggleHandler);
    }
    sizeControls(state, api.page.len()); useAjax(state, api.page.len()); sync(state);
    if (def.source) sourceControl(state);
    if (!initializing && api.page.len() > batch) api.ajax.reload(null, false);
  }
  function enhance(initializing) {
    var enabled = /\/mass_delete(?:\.php)?$/.test(window.location.pathname);
    states.forEach(function (state) { if (!enabled || !state.table.isConnected) destroy(state); });
    var jq = window.jQuery;
    if (!jq || !jq.fn || !jq.fn.dataTable) return;
    if (!bound) {
      bound = true;
      jq(document).on('preInit.dt.naxxBulkDelete', selector, function (_event, settings) { enhance(settings); });
      jq(document).on('init.dt.naxxBulkDelete', selector, function () { enhance(); });
    }
    if (!enabled) return;
    Object.keys(definitions).forEach(function (id) {
      var table = document.getElementById(id);
      if (!table || !jq.fn.dataTable.isDataTable(table)) return;
      var api = jq(table).DataTable(), settings = api.settings()[0], previous = states.get(table);
      if (previous && previous.settings !== settings) { destroy(previous); previous = null; }
      if (previous) { sizeControls(previous, api.page.len()); return; }
      if (settings && (settings._bInitComplete || settings === initializing)) mount(table, jq, api, settings, settings === initializing);
    });
  }
  window.NaxxBulkDelete = {enhance:enhance, filteredIds:filteredIds};
  enhance();
  var scheduled = false;
  new MutationObserver(function (changes) {
    if (scheduled || !changes.some(function (change) {
      return Array.prototype.some.call(Array.prototype.slice.call(change.addedNodes).concat(Array.prototype.slice.call(change.removedNodes)), function (node) {
        return node.nodeType === 1 && (node.matches(selector) || node.querySelector(selector));
      });
    })) return;
    scheduled = true;
    window.setTimeout(function () { scheduled = false; enhance(); }, 0);
  }).observe(document.documentElement, {childList:true, subtree:true});
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { enhance(); }, {once:true});
}());

/* Links e logos na edição em massa. Toda escrita exige uma prévia do servidor. */
(function () {
  'use strict';
  var active = null, observer = null, scheduled = false, parserPromise = null;
  var maxSelected = 50000, maxBytes = 256 * 1024 * 1024, maxRecords = 1000000;

  function element(tag, className, text) {
    var node = document.createElement(tag);
    if (className) node.className = className;
    if (text !== undefined) node.textContent = text;
    return node;
  }
  function field(parent, key, label, type) {
    var wrap = element('label', 'naxx-stream-link-edit__field');
    var control = element('input', 'form-control');
    control.type = type || 'text'; control.dataset.naxxLink = key;
    control.autocomplete = 'off'; control.spellcheck = false;
    wrap.appendChild(element('span', '', label)); wrap.appendChild(control); parent.appendChild(wrap);
    return control;
  }
  function checkbox(parent, key, text, checked) {
    var label = element('label', 'naxx-stream-link-edit__check'), input = element('input');
    input.type = 'checkbox'; input.checked = checked; input.dataset.naxxLink = key;
    label.appendChild(input); label.appendChild(document.createTextNode(' ' + text)); parent.appendChild(label);
    return input;
  }
  function button(parent, key, text, primary) {
    var node = element('button', 'btn ' + (primary ? 'btn-primary' : 'btn-light'), text);
    node.type = 'button'; node.dataset.naxxLink = key; parent.appendChild(node); return node;
  }
  function option(select, value, text) { var node = element('option', '', text); node.value = value; select.appendChild(node); }
  function ids() {
    if (!Array.isArray(window.rSelected)) throw new Error('selection_unavailable');
    var selected = Array.from(new Set(window.rSelected.map(String)));
    if (!selected.length) throw new Error('selection_empty');
    if (selected.length > maxSelected) throw new Error('selection_limit');
    if (selected.some(function (id) {return !/^[1-9]\d*$/.test(id) || !Number.isSafeInteger(Number(id));})) throw new Error('selection_invalid');
    return selected.sort(function (a, b) {return Number(a) - Number(b);});
  }
  function selectionKey() {try {return JSON.stringify(ids());} catch (_) {return '';}}
  function nameKey(name) {return String(name || '').replace(/[\u0009-\u000d\u0020\u0085\u00a0\u1680\u2000-\u200a\u2028\u2029\u202f\u205f\u3000\ufeff]+/g, ' ').replace(/^ +| +$/g, '').replace(/[A-Z]/g, function (letter) {return letter.toLowerCase();});}
  function loadParser() {
    if (window.NaxxImporter && typeof window.NaxxImporter.createM3UReader === 'function') return Promise.resolve();
    if (!parserPromise) parserPromise = new Promise(function (resolve, reject) {
      var script = document.createElement('script'); script.src = url('assets/js/naxx-importer.js'); script.async = true;
      script.onload = function () {if (window.NaxxImporter && typeof window.NaxxImporter.createM3UReader === 'function') resolve(); else {parserPromise = null; script.remove(); reject(new Error('importer_unavailable'));}};
      script.onerror = function () {parserPromise = null; script.remove(); reject(new Error('importer_unavailable'));};
      document.head.appendChild(script);
    });
    return parserPromise;
  }
  function current(state) {return active === state && state.box.isConnected && /\/stream_mass(?:\.php)?$/.test(window.location.pathname);}
  function status(state, message, error) {
    state.status.textContent = message; state.status.classList.toggle('text-danger', Boolean(error));
  }
  function errorText(error) {
    if (error && error.userMessage) return error.userMessage;
    var messages = {
      selection_unavailable: 'Aguarde a seleção de canais carregar.', selection_empty: 'Selecione os canais na primeira aba antes de gerar a prévia.',
      selection_limit: 'Selecione até 50.000 canais por operação.', selection_invalid: 'A seleção está inválida. Selecione os canais novamente.',
      operation_empty: 'Ative a alteração dos links, dos logos ou de ambos.', source_find: 'Preencha o texto a localizar nos links.',
      logo_find: 'Preencha o texto a localizar nos logos.', logo_url: 'Informe uma URL HTTP ou HTTPS válida para o logo.',
      file_missing: 'Escolha um arquivo M3U ou M3U8.', url_invalid: 'Informe uma URL HTTP ou HTTPS para a lista, sem usuário e senha antes do domínio.',
      importer_unavailable: 'O leitor M3U ainda não está disponível. Atualize a página e tente novamente.',
      list_empty: 'A lista não contém entradas M3U com nome e fonte.', list_limit: 'A lista ultrapassa o limite de 256 MB ou 1 milhão de entradas.',
      line_limit: 'Uma linha da lista é muito longa. Verifique o arquivo M3U.', list_incomplete: 'Não foi possível confirmar a lista completa. Carregue-a novamente.',
      invalid_response: 'O painel retornou uma resposta inválida. Atualize a página e gere outra prévia.',
      request_failed: 'Não foi possível concluir a solicitação. Verifique sua conexão e gere outra prévia.',
      request_limit: 'Os dados da atualização ultrapassam 8 MB. Selecione menos canais e gere outra prévia.',
      preview_changed: 'A seleção ou os campos mudaram. Gere uma nova prévia antes de aplicar.',
      preview_expired: 'A prévia expirou. Gere outra prévia antes de aplicar.',
      permission: 'A sessão expirou ou não tem permissão para esta operação. Entre novamente no painel.',
      conflict: 'Alguns canais mudaram desde a prévia. Gere outra prévia para revisar os valores atuais.'
    };
    return messages[error && error.message] || 'Não foi possível concluir. Gere outra prévia e tente novamente.';
  }
  function invalidate(state, message) {
    state.generation++;
    if (state.request && !state.applying) state.request.abort();
    state.request = null; state.preview = null; state.apply.disabled = true; state.apply.textContent = 'Aplicar alterações revisadas';
    state.applied = 0; state.cursor = 0; state.stopApply.hidden = true; state.fields.disabled = false;
    window.clearTimeout(state.expiryTimer); state.result.hidden = true; state.changes.replaceChildren();
    if (!state.applying) {state.previewButton.disabled = false; state.cancel.hidden = true;}
    if (message) status(state, message);
  }
  function url(path) {return new URL(path, window.location.href).href;}
  async function request(state, payload, signal) {
    var options = {credentials: 'same-origin', cache: 'no-store', signal: signal,
      headers: {'X-Requested-With': 'XMLHttpRequest', 'Accept': 'application/json'}};
    if (payload) {
      options.method = 'POST'; options.headers['Content-Type'] = 'application/json'; options.body = JSON.stringify(payload);
      if (new TextEncoder().encode(options.body).byteLength > state.requestBytes) throw new Error('request_limit');
    }
    var response = await window.fetch(url('naxx-update.php?feature=stream-link-edit'), options);
    if (response.redirected || response.status === 401 || response.status === 403) throw new Error('permission');
    var result;
    try {result = await response.json();} catch (_) {throw new Error('invalid_response');}
    if (!response.ok) {
      var failure = new Error(response.status === 409 ? 'conflict' : response.status === 410 ? 'preview_expired' : response.status === 413 ? 'request_limit' : 'request_failed');
      failure.status = response.status;
      if (result && Number.isSafeInteger(result.applied)) failure.applied = result.applied;
      if (result && typeof result.message === 'string') failure.userMessage = result.message.slice(0, 500);
      throw failure;
    }
    if (!result || result.ok !== true) throw new Error('request_failed');
    if (typeof result.csrf === 'string' && /^[a-f0-9]{64}$/.test(result.csrf)) state.csrf = result.csrf;
    if (result.limits && Number.isSafeInteger(result.limits.request_bytes) && result.limits.request_bytes > 0) state.requestBytes = Math.min(8388608, result.limits.request_bytes);
    return result;
  }
  function signature(state) {
    var c = state.controls, file = c.file.files && c.file.files[0];
    return JSON.stringify([selectionKey(), c.mode.value, c.source.checked, c.sourceFind.value, c.sourceReplace.value,
      c.logo.checked, c.logoMode.value, c.logoFind.value, c.logoReplace.value, c.logoURL.value,
      c.inputMode.value, c.url.value, file && [file.name, file.size, file.lastModified], c.importSource.checked, c.importLogo.checked]);
  }
  function operation(state) {
    var c = state.controls, result = {kind: 'replace'};
    if (c.mode.value === 'm3u') {
      if (!c.importSource.checked && !c.importLogo.checked) throw new Error('operation_empty');
      if (c.inputMode.value === 'file' && !(c.file.files && c.file.files[0])) throw new Error('file_missing');
      if (c.inputMode.value === 'url') {
        var address;
        try {address = new URL(c.url.value.trim());} catch (_) {throw new Error('url_invalid');}
        if (!/^https?:$/.test(address.protocol) || address.username || address.password) throw new Error('url_invalid');
      }
      return {kind: 'm3u', update_source: c.importSource.checked, update_logo: c.importLogo.checked};
    }
    if (c.source.checked) {
      if (!c.sourceFind.value) throw new Error('source_find');
      result.source = {find: c.sourceFind.value, replace: c.sourceReplace.value};
    }
    if (c.logo.checked) {
      if (c.logoMode.value === 'set') {
        var logo;
        try {logo = new URL(c.logoURL.value.trim());} catch (_) {throw new Error('logo_url');}
        if (!/^https?:$/.test(logo.protocol) || !logo.hostname) throw new Error('logo_url');
        result.logo = {mode: 'set', url: c.logoURL.value.trim()};
      } else {
        if (!c.logoFind.value) throw new Error('logo_find');
        result.logo = {mode: 'replace', find: c.logoFind.value, replace: c.logoReplace.value};
      }
    }
    if (!result.source && !result.logo) throw new Error('operation_empty');
    return result;
  }

  // Leitura incremental: retém no máximo duas entradas por nome selecionado.
  // A segunda mantém a evidência de ambiguidade, mesmo se a URL se repetir.
  function m3uReader(state, catalog, signal) {
    if (!window.NaxxImporter || typeof window.NaxxImporter.createM3UReader !== 'function') throw new Error('importer_unavailable');
    var keys = new Set(catalog.map(function (channel) {return channel.match_key;}).filter(function (key) {return typeof key === 'string';})), kept = new Map(), pending = '', bytes = 0, records = 0;
    var decoder = new TextDecoder('utf-8'), lastYield = 0;
    var readLine = window.NaxxImporter.createM3UReader(function (record) {
      records++; if (records > maxRecords) throw new Error('list_limit');
      var key = nameKey(record.name);
      if (!key || !keys.has(key)) return;
      var matches = kept.get(key); if (!matches) {matches = []; kept.set(key, matches);}
      if (matches.length < 2) matches.push({name: String(record.name), url: String(record.url || '').trim(), logo: String(record.logo || '').trim()});
    });
    async function consume(chunk, final) {
      if (signal.aborted) throw new DOMException('Cancelado', 'AbortError');
      bytes += chunk ? chunk.byteLength : 0; if (bytes > maxBytes) throw new Error('list_limit');
      pending += decoder.decode(chunk, {stream: !final});
      var start = 0, newline;
      while ((newline = pending.indexOf('\n', start)) >= 0) {
        if (newline - start > 65536) throw new Error('line_limit');
        readLine(pending.slice(start, newline)); start = newline + 1;
        if (Date.now() - lastYield > 12) {
          status(state, 'Lendo lista… ' + records.toLocaleString('pt-BR') + ' entradas; somente os nomes selecionados ficam na revisão.');
          await new Promise(function (resolve) {window.setTimeout(resolve, 0);}); lastYield = Date.now();
          if (signal.aborted) throw new DOMException('Cancelado', 'AbortError');
        }
      }
      pending = pending.slice(start); if (pending.length > 65536) throw new Error('line_limit');
      if (final && pending) {readLine(pending); pending = '';}
    }
    return {consume: consume, finish: function () {
      if (!records) throw new Error('list_empty');
      var items = []; kept.forEach(function (matches) {matches.forEach(function (item) {items.push(item);});});
      return {items: items, scanned: records, bytes: bytes};
    }};
  }
  async function readFile(file, parser, signal) {
    if (file.size > maxBytes) throw new Error('list_limit');
    for (var position = 0; position < file.size; position += 256 * 1024) {
      if (signal.aborted) throw new DOMException('Cancelado', 'AbortError');
      var blob = file.slice(position, position + 256 * 1024), buffer;
      if (typeof blob.arrayBuffer === 'function') buffer = await blob.arrayBuffer();
      else buffer = await new Promise(function (resolve, reject) {
        var reader = new FileReader(); reader.onload = function () {resolve(reader.result);};
        reader.onerror = function () {reject(new Error('request_failed'));}; reader.readAsArrayBuffer(blob);
      });
      await parser.consume(new Uint8Array(buffer), false);
    }
    await parser.consume(undefined, true);
  }
  async function readURL(address, parser, signal) {
    var response = await window.fetch(url('naxx-import-url.php'), {method: 'POST', credentials: 'same-origin', cache: 'no-store', signal: signal,
      headers: {'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8', 'X-Requested-With': 'XMLHttpRequest'}, body: new URLSearchParams({url: address})});
    if (response.redirected || response.status === 401 || response.status === 403) throw new Error('permission');
    if (!response.ok || response.headers.get('X-Naxx-Stream-Protocol') !== '1' || !response.body || !response.body.getReader) throw new Error('list_incomplete');
    var reader = response.body.getReader(), buffer = null, offset = 0, total = 0;
    async function take(length, content) {
      var output = content ? null : new Uint8Array(length), written = 0;
      while (written < length) {
        if (signal.aborted) throw new DOMException('Cancelado', 'AbortError');
        if (!buffer || offset === buffer.byteLength) {
          var incoming = await reader.read(); if (incoming.done) throw new Error('list_incomplete');
          buffer = incoming.value; offset = 0; if (!buffer.byteLength) continue;
        }
        var count = Math.min(length - written, buffer.byteLength - offset), piece = buffer.subarray(offset, offset + count);
        if (content) {total += count; await parser.consume(piece, false);} else output.set(piece, written);
        offset += count; written += count;
      }
      return output;
    }
    async function size() {var value = await take(4, false); return new DataView(value.buffer).getUint32(0, false);}
    try {
      while (true) {
        var length = await size();
        if (!length) {
          var finalLength = await size(); if (!finalLength || finalLength > 65536) throw new Error('list_incomplete');
          var complete;
          try {complete = JSON.parse(new TextDecoder('utf-8', {fatal: true}).decode(await take(finalLength, false)));} catch (_) {throw new Error('list_incomplete');}
          if (!complete || complete.ok !== true || complete.bytes !== total || (buffer && offset < buffer.byteLength)) throw new Error('list_incomplete');
          while (true) {var extra = await reader.read(); if (extra.done) break; if (extra.value.byteLength) throw new Error('list_incomplete');}
          break;
        }
        if (length > 16777216) throw new Error('list_incomplete');
        await take(length, true);
      }
      await parser.consume(undefined, true);
    } catch (error) {try {await reader.cancel();} catch (_) {} throw error;}
    finally {reader.releaseLock();}
  }
  function masked(value, show) {
    if (show) return String(value || '');
    try {var address = new URL(String(value)); return address.protocol + '//' + address.host + '/…' + (address.search ? '?…' : '');}
    catch (_) {return value ? '(valor oculto)' : '(vazio)';}
  }
  function render(state) {
    var preview = state.preview; if (!preview) return;
    state.changes.replaceChildren();
    var summary = preview.summary;
    state.summary.textContent = summary.selected + ' selecionados · ' + summary.changed + ' com alterações · ' +
      (summary.unchanged || 0) + ' sem alteração · ' + (summary.unmatched || 0) + ' sem correspondência · ' + (summary.ambiguous || 0) + ' ambíguos · ' + (summary.invalid || 0) + ' inválidos';
    (preview.changes || []).slice(0, 100).forEach(function (change) {
      var row = element('tr'); row.appendChild(element('td', '', String(change.id) + ' — ' + String(change.name || '')));
      [['old_sources', 'old_logo'], ['new_sources', 'new_logo']].forEach(function (keys) {
        var cell = element('td'), sources = change[keys[0]];
        if (Array.isArray(sources)) sources.forEach(function (source) {cell.appendChild(element('div', 'naxx-stream-link-edit__url', masked(source, state.show.checked)));});
        if (Object.prototype.hasOwnProperty.call(change, keys[1])) cell.appendChild(element('div', 'naxx-stream-link-edit__url', 'Logo: ' + masked(change[keys[1]], state.show.checked)));
        row.appendChild(cell);
      });
      state.changes.appendChild(row);
    });
    state.sample.textContent = preview.truncated ? 'Amostra de até 100 canais. A aplicação abrange os ' + summary.changed + ' canais com alterações da prévia.' : 'A prévia inclui todos os canais com alterações.';
    state.issues.replaceChildren();
    var reasons = {unmatched: 'Nome não encontrado na lista', ambiguous: 'Nome repetido no painel ou na lista', invalid: 'Fonte ou logo inválido',
      duplicate_existing: 'Nome repetido no painel', duplicate_import: 'Nome repetido na lista', invalid_source: 'Fonte inválida', invalid_logo: 'Logo inválido'};
    (preview.issues || []).slice(0, 100).forEach(function (issue) {state.issues.appendChild(element('li', '', String(issue.id) + ' — ' + String(issue.name || '') + ': ' + (reasons[issue.reason] || String(issue.reason || 'Entrada não aplicável').slice(0, 500))));});
    state.issueBox.hidden = !(preview.issues && preview.issues.length);
    state.issueNote.textContent = preview.issues_truncated ? 'Exibindo até 100 nomes; os totais acima incluem todos os canais.' : '';
    state.result.hidden = false;
  }
  function expires(value) {
    var timestamp = typeof value === 'number' ? value * (value < 100000000000 ? 1000 : 1) : Date.parse(value);
    return Number.isFinite(timestamp) ? timestamp : 0;
  }
  async function preview(state) {
    if (state.applying) return;
    invalidate(state);
    var selected, update;
    try {selected = ids(); update = operation(state);} catch (error) {status(state, errorText(error), true); return;}
    var controller = new AbortController(), generation = state.generation, key = signature(state);
    state.request = controller; state.previewButton.disabled = true; state.cancel.hidden = false;
    status(state, 'Preparando a prévia dos canais selecionados…');
    try {
      if (!state.csrf) await request(state, null, controller.signal);
      if (!state.csrf) throw new Error('invalid_response');
      if (update.kind === 'm3u') {
        var catalog = await request(state, {action: 'catalog', csrf: state.csrf, ids: selected}, controller.signal);
        if (!Array.isArray(catalog.channels) || catalog.channels.length !== selected.length || catalog.channels.some(function (channel) {return !channel || typeof channel.name !== 'string' || (channel.match_key !== null && typeof channel.match_key !== 'string');})) throw new Error('invalid_response');
        await loadParser();
        if (controller.signal.aborted || generation !== state.generation || key !== signature(state) || !current(state)) return;
        var parser = m3uReader(state, catalog.channels, controller.signal);
        if (state.controls.inputMode.value === 'file') await readFile(state.controls.file.files[0], parser, controller.signal);
        else await readURL(state.controls.url.value.trim(), parser, controller.signal);
        var parsed = parser.finish(); update.items = parsed.items;
      }
      if (controller.signal.aborted || generation !== state.generation || key !== signature(state) || !current(state)) return;
      var result = await request(state, {action: 'preview', csrf: state.csrf, ids: selected, operation: update}, controller.signal);
      if (controller.signal.aborted || generation !== state.generation || key !== signature(state) || !current(state)) return;
      if (!result.summary || !Number.isSafeInteger(result.summary.changed) || result.summary.changed < 0 || result.summary.changed > selected.length ||
          !Array.isArray(result.changes) || result.changes.length > 100 || !Number.isSafeInteger(result.summary.selected) || result.summary.selected !== selected.length ||
          (result.summary.changed && (typeof result.token !== 'string' || !result.token))) throw new Error('invalid_response');
      var expiration = result.summary.changed ? expires(result.expires_at) : Date.now() + 600000; if (expiration <= Date.now()) throw new Error('preview_expired');
      state.preview = result; state.previewKey = key; state.expires = expiration; state.apply.disabled = result.summary.changed === 0;
      state.show.checked = false; render(state);
      status(state, result.summary.changed ? 'Revise os valores abaixo e clique em Aplicar alterações revisadas.' : 'Nenhuma alteração aplicável. Os canais permanecem iguais.');
      if (result.summary.changed) state.expiryTimer = window.setTimeout(function () {if (state.preview === result) {invalidate(state); status(state, errorText(new Error('preview_expired')), true);}}, Math.min(2147483647, expiration - Date.now()));
    } catch (error) {
      if (generation !== state.generation || !current(state) || controller.signal.aborted) return;
      invalidate(state); status(state, errorText(error), true);
    } finally {
      if (state.request === controller) {state.request = null; state.previewButton.disabled = false; state.cancel.hidden = true;}
    }
  }
  async function apply(state) {
    if (state.applying || !state.preview || state.apply.disabled) return;
    if (state.previewKey !== signature(state)) {invalidate(state); status(state, errorText(new Error('preview_changed')), true); return;}
    if (Date.now() >= state.expires) {invalidate(state); status(state, errorText(new Error('preview_expired')), true); return;}
    var token = state.preview.token, controller = new AbortController();
    state.applying = true; state.stopRequested = false; state.request = controller; state.fields.disabled = true; state.apply.disabled = true; state.previewButton.disabled = true;
    state.stopApply.hidden = false; state.stopApply.disabled = false;
    window.clearTimeout(state.expiryTimer); status(state, 'Aplicando exatamente as alterações revisadas…');
    try {
      while (true) {
        if (!current(state)) return;
        if (state.previewKey !== signature(state)) {state.stopRequested = true; break;}
        var result = await request(state, {action: 'apply', csrf: state.csrf, token: token, cursor: state.cursor}, controller.signal);
        if (!current(state)) return;
        if (!Number.isSafeInteger(result.applied) || result.applied < state.applied || !Number.isSafeInteger(result.total) || result.total !== state.preview.summary.changed ||
            result.applied > result.total || typeof result.done !== 'boolean' || (!result.done && (!Number.isSafeInteger(result.next_cursor) || result.next_cursor <= state.cursor))) throw new Error('invalid_response');
        state.applied = result.applied; state.cursor = result.next_cursor;
        status(state, state.applied + ' de ' + result.total + ' canais atualizados…');
        if (result.done) {
          state.preview = null; state.result.hidden = true; state.changes.replaceChildren();
          status(state, result.applied + ' canais atualizados. Salvo. O painel atualizará os canais automaticamente nos próximos minutos.');
          var table = document.getElementById('datatable-mass'), jq = window.jQuery;
          if (table && jq && jq.fn && jq.fn.dataTable && jq.fn.dataTable.isDataTable(table)) jq(table).DataTable().ajax.reload(null, false);
          break;
        }
        if (state.stopRequested) break;
      }
      if (state.preview) status(state, state.applied + ' canais atualizados. Aplicação interrompida após o lote atual. Retome para continuar a mesma prévia.');
    } catch (error) {
      if (current(state)) {
        if (error.message === 'conflict' || error.message === 'permission' || error.message === 'preview_expired' || error.message === 'request_limit' || error.status === 422) {
          if (Number.isSafeInteger(error.applied)) state.applied = error.applied;
          state.preview = null; state.result.hidden = true; state.changes.replaceChildren();
          status(state, state.applied + ' canais já atualizados. ' + errorText(error), true);
        } else status(state, state.applied + ' canais confirmados. A conexão foi interrompida. Retome a mesma prévia para confirmar e continuar sem repetir alterações.', true);
      }
    } finally {
      state.applying = false; state.request = null; state.stopApply.hidden = true; state.fields.disabled = false; state.previewButton.disabled = false;
      state.apply.disabled = !state.preview || state.previewKey !== signature(state) || Date.now() >= state.expires;
      state.apply.textContent = state.preview ? 'Retomar aplicação revisada' : 'Aplicar alterações revisadas';
      if (state.preview && state.previewKey !== signature(state)) {state.preview = null; state.apply.disabled = true; state.result.hidden = true; status(state, state.applied + ' canais atualizados. A seleção mudou; gere outra prévia para continuar.');}
    }
  }
  function views(state) {
    var c = state.controls, importing = c.mode.value === 'm3u';
    state.replaceFields.hidden = importing; state.importFields.hidden = !importing;
    state.fileField.hidden = c.inputMode.value !== 'file'; state.urlField.hidden = c.inputMode.value !== 'url';
    state.logoReplaceFields.hidden = c.logoMode.value === 'set'; state.logoSetField.hidden = c.logoMode.value !== 'set';
    state.sourceFields.disabled = !c.source.checked; state.logoFields.disabled = !c.logo.checked;
  }
  function mount(target) {
    var box = element('section', 'naxx-stream-link-edit'); box.setAttribute('aria-label', 'Links e logos');
    box.appendChild(element('h3', '', 'Links e logos'));
    box.appendChild(element('p', 'naxx-stream-link-edit__notice', 'Atualize as fontes e os logos apenas dos canais selecionados. Confira a prévia antes de aplicar.'));
    var count = element('p', 'naxx-stream-link-edit__count'); box.appendChild(count);
    var fields = element('fieldset', 'naxx-stream-link-edit__fields'); box.appendChild(fields);
    var modeLabel = element('label', 'naxx-stream-link-edit__field'), mode = element('select', 'form-control'); mode.dataset.naxxLink = 'mode';
    modeLabel.appendChild(element('span', '', 'Como atualizar')); modeLabel.appendChild(mode); fields.appendChild(modeLabel);
    option(mode, 'replace', 'Localizar e substituir'); option(mode, 'm3u', 'Atualizar usando lista M3U');
    var replaceFields = element('div', 'naxx-stream-link-edit__replace'); fields.appendChild(replaceFields);
    var source = checkbox(replaceFields, 'source', 'Substituir texto nos links das fontes', true);
    var sourceFields = element('fieldset', 'naxx-stream-link-edit__pair'); replaceFields.appendChild(sourceFields);
    var sourceFind = field(sourceFields, 'source-find', 'Localizar nos links'), sourceReplace = field(sourceFields, 'source-replace', 'Substituir por');
    sourceFind.placeholder = 'Ex.: dominio-antigo.com'; sourceReplace.placeholder = 'Ex.: dominio-novo.com';
    replaceFields.appendChild(element('p', 'text-muted', 'Substituição literal de todas as ocorrências, com diferença entre maiúsculas e minúsculas. Os demais trechos da fonte são mantidos.'));
    var logo = checkbox(replaceFields, 'logo', 'Atualizar os logos', false), logoFields = element('fieldset'); replaceFields.appendChild(logoFields);
    var logoMode = element('select', 'form-control'); logoMode.dataset.naxxLink = 'logo-mode'; logoMode.setAttribute('aria-label', 'Como atualizar os logos');
    option(logoMode, 'replace', 'Localizar e substituir nos logos'); option(logoMode, 'set', 'Definir o mesmo logo para todos'); logoFields.appendChild(logoMode);
    var logoReplaceFields = element('div', 'naxx-stream-link-edit__pair'); logoFields.appendChild(logoReplaceFields);
    var logoFind = field(logoReplaceFields, 'logo-find', 'Localizar nos logos'), logoReplace = field(logoReplaceFields, 'logo-replace', 'Substituir por');
    var logoSetField = element('div'); logoFields.appendChild(logoSetField); var logoURL = field(logoSetField, 'logo-url', 'URL do logo', 'url');
    var importFields = element('div', 'naxx-stream-link-edit__import'); fields.appendChild(importFields);
    importFields.appendChild(element('p', '', 'A lista usa o nome completo de cada canal. Acentos e indicações como HD, SD e FHD precisam coincidir; nomes repetidos ou não encontrados ficam para revisão.'));
    var inputMode = element('select', 'form-control'); inputMode.dataset.naxxLink = 'input-mode'; inputMode.setAttribute('aria-label', 'Origem da lista M3U');
    option(inputMode, 'file', 'Arquivo M3U'); option(inputMode, 'url', 'URL da lista M3U'); importFields.appendChild(inputMode);
    var fileField = element('div'), urlField = element('div'); importFields.appendChild(fileField); importFields.appendChild(urlField);
    var file = field(fileField, 'file', 'Arquivo M3U / M3U8', 'file'); file.accept = '.m3u,.m3u8,audio/x-mpegurl,application/vnd.apple.mpegurl';
    var address = field(urlField, 'url', 'URL da lista M3U', 'url'); address.placeholder = 'https://provedor.exemplo/lista.m3u';
    var importSource = checkbox(importFields, 'import-source', 'Atualizar a primeira fonte e manter as fontes alternativas', true);
    var importLogo = checkbox(importFields, 'import-logo', 'Usar tvg-logo quando presente na lista', true);
    importFields.appendChild(element('p', 'text-muted', 'Nenhum canal novo será criado. A lista substitui a primeira fonte dos nomes únicos correspondentes; fontes alternativas e logos ausentes são mantidos.'));
    var actions = element('div', 'naxx-stream-link-edit__actions'); box.appendChild(actions);
    var previewButton = button(actions, 'preview', 'Gerar prévia', true), cancel = button(actions, 'cancel', 'Cancelar análise'); cancel.hidden = true;
    var message = element('p', 'naxx-stream-link-edit__status'); message.setAttribute('role', 'status'); message.setAttribute('aria-live', 'polite'); box.appendChild(message);
    var result = element('div', 'naxx-stream-link-edit__preview'); result.hidden = true; box.appendChild(result);
    var summary = element('p', 'naxx-stream-link-edit__summary'); result.appendChild(summary);
    var show = checkbox(result, 'show', 'Mostrar links completos nesta tela', false);
    var sample = element('p', 'text-muted'); result.appendChild(sample);
    var scroll = element('div', 'naxx-stream-link-edit__table'); result.appendChild(scroll);
    var table = element('table', 'table table-sm'), head = element('thead'), header = element('tr');
    ['Canal', 'Antes', 'Depois'].forEach(function (text) {header.appendChild(element('th', '', text));}); head.appendChild(header); table.appendChild(head);
    var changes = element('tbody'); table.appendChild(changes); scroll.appendChild(table);
    var issueBox = element('details', 'naxx-stream-link-edit__issues'); result.appendChild(issueBox);
    issueBox.appendChild(element('summary', '', 'Revisar não alterados')); var issueNote = element('p', 'text-muted'), issues = element('ul'); issueBox.appendChild(issueNote); issueBox.appendChild(issues);
    var applyButton = button(result, 'apply', 'Aplicar alterações revisadas', true); applyButton.disabled = true;
    var stopApply = button(result, 'stop-apply', 'Parar após o lote atual'); stopApply.hidden = true;
    var state = {target: target, box: box, count: count, fields: fields, status: message, previewButton: previewButton, cancel: cancel, apply: applyButton,
      result: result, summary: summary, sample: sample, changes: changes, show: show, generation: 0, request: null, preview: null, csrf: '', applying: false, requestBytes: 8388608,
      stopApply: stopApply, cursor: 0, applied: 0, issues: issues, issueBox: issueBox, issueNote: issueNote,
      replaceFields: replaceFields, importFields: importFields, fileField: fileField, urlField: urlField, logoReplaceFields: logoReplaceFields, logoSetField: logoSetField,
      sourceFields: sourceFields, logoFields: logoFields, controls: {mode: mode, source: source, sourceFind: sourceFind, sourceReplace: sourceReplace,
        logo: logo, logoMode: logoMode, logoFind: logoFind, logoReplace: logoReplace, logoURL: logoURL, inputMode: inputMode, file: file, url: address, importSource: importSource, importLogo: importLogo}};
    active = state; target.prepend(box); views(state);
    fields.addEventListener('input', function () {if (!state.applying) invalidate(state, 'Campos alterados. Gere a prévia para revisar.');});
    fields.addEventListener('change', function () {views(state); if (!state.applying) invalidate(state, 'Campos alterados. Gere a prévia para revisar.');});
    box.addEventListener('keydown', function (event) {if (event.key === 'Enter' && event.target.tagName === 'INPUT' && event.target.type !== 'checkbox' && event.target.type !== 'file') event.preventDefault();});
    previewButton.addEventListener('click', function () {preview(state);}); applyButton.addEventListener('click', function () {apply(state);});
    cancel.addEventListener('click', function () {invalidate(state, 'Análise cancelada. Os canais permanecem iguais.');});
    stopApply.addEventListener('click', function () {state.stopRequested = true; stopApply.disabled = true; status(state, 'Aguardando concluir o lote atual para interromper…');});
    show.addEventListener('change', function () {render(state);});
    state.selection = selectionKey();
    function sync() {
      if (!current(state)) {enhance(); return;}
      var next = selectionKey();
      if (next !== state.selection) {state.selection = next; if (state.applying) state.stopRequested = true; else invalidate(state, 'Seleção alterada. Gere uma nova prévia.');}
      var text = (Array.isArray(window.rSelected) ? new Set(window.rSelected.map(String)).size : 0).toLocaleString('pt-BR') + ' canais selecionados';
      if (count.textContent !== text) count.textContent = text;
    }
    state.timer = window.setInterval(sync, 250); sync();
  }
  function destroy(state) {
    state.generation++; if (state.request && !state.applying) state.request.abort();
    window.clearInterval(state.timer); window.clearTimeout(state.expiryTimer); state.preview = null; state.box.remove();
  }
  function enhance() {
    var target = /\/stream_mass(?:\.php)?$/.test(window.location.pathname) ? document.getElementById('stream-details') : null;
    if (target && !target.closest('form')) target = null;
    if (active && (active.target !== target || !active.box.isConnected)) {destroy(active); active = null;}
    if (target && !active && Array.isArray(window.rSelected)) mount(target);
  }
  function watch() {
    enhance();
    if (!observer && document.body) {
      observer = new MutationObserver(function (changes) {
        if (scheduled || !changes.some(function (change) {return Array.from(change.addedNodes).concat(Array.from(change.removedNodes)).some(function (node) {
          return node.nodeType === 1 && (!active || !active.box.contains(node));
        });})) return;
        scheduled = true; window.setTimeout(function () {scheduled = false; enhance();}, 0);
      });
      observer.observe(document.body, {childList: true, subtree: true});
    }
  }
  window.NaxxStreamLinkEdit = {enhance: enhance};
  window.addEventListener('popstate', enhance);
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', watch, {once: true}); else watch();
}());
