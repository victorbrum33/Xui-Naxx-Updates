<?php
if (($_GET['feature'] ?? '') === 'ondemand') {

// Política pura: não consulta fontes, banco, cache ou processos do painel.

/** Compatível com PHP 7.4: verifica uma lista com índices consecutivos. */
function naxxOdIsList(array $value) {
    return !$value || array_keys($value) === range(0, count($value) - 1);
}

/** Valida uma lista ou JSON de fontes, preservando URLs, ordem e duplicatas. */
function naxxOdNormalizeSources($input) {
    if (is_string($input)) {
        $json = trim($input);
        $input = json_decode($json, true);
        if (json_last_error() !== JSON_ERROR_NONE || substr($json, 0, 1) !== '[') {
            return ['sources' => [], 'valid' => false, 'reason' => 'A lista de fontes não contém um JSON de lista válido.'];
        }
    }
    if (!is_array($input) || !naxxOdIsList($input) || !$input) {
        return ['sources' => [], 'valid' => false, 'reason' => 'Informe ao menos uma fonte em uma lista válida.'];
    }
    $sources = [];
    foreach ($input as $index => $source) {
        $label = 'A fonte ' . ($index + 1);
        if (!is_string($source) || trim($source) === '') {
            return ['sources' => [], 'valid' => false, 'reason' => $label . ' está vazia ou não é um endereço de texto.'];
        }
        $source = trim($source);
        if (preg_match('/[\x00-\x20\x7f]/', $source)) {
            return ['sources' => [], 'valid' => false, 'reason' => $label . ' contém espaços ou caracteres de controle.'];
        }
        $parts = parse_url($source);
        if (!is_array($parts) || empty($parts['scheme']) || empty($parts['host'])) {
            return ['sources' => [], 'valid' => false, 'reason' => $label . ' não tem protocolo e servidor válidos.'];
        }
        if (!in_array(strtolower($parts['scheme']), ['http', 'https', 'rtsp', 'udp'], true)) {
            return ['sources' => [], 'valid' => false, 'reason' => $label . ' usa protocolo não permitido. Use HTTP, HTTPS, RTSP ou UDP.'];
        }
        $host = $parts['host'];
        if (strpos($host, '[') !== false || strpos($host, ']') !== false) {
            $validHost = substr($host, 0, 1) === '[' && substr($host, -1) === ']'
                && filter_var(substr($host, 1, -1), FILTER_VALIDATE_IP, FILTER_FLAG_IPV6) !== false;
        } else {
            $validHost = filter_var($host, FILTER_VALIDATE_IP) !== false
                || filter_var($host, FILTER_VALIDATE_DOMAIN, FILTER_FLAG_HOSTNAME) !== false;
        }
        if (!$validHost) {
            return ['sources' => [], 'valid' => false, 'reason' => $label . ' não tem um nome de servidor ou endereço IP válido.'];
        }
        if (isset($parts['port']) && ($parts['port'] < 1 || $parts['port'] > 65535)) {
            return ['sources' => [], 'valid' => false, 'reason' => $label . ' usa uma porta inválida.'];
        }
        $sources[] = $source;
    }
    return ['sources' => $sources, 'valid' => true, 'reason' => 'Lista de fontes válida; os endereços não foram acessados.'];
}

/** Ordena mapas recursivamente, mantendo listas e tipos para uma assinatura estável. */
function naxxOdCanonicalValue($value) {
    if (is_array($value)) {
        if (!naxxOdIsList($value)) ksort($value, SORT_STRING);
        foreach ($value as $key => $item) $value[$key] = naxxOdCanonicalValue($item);
        return $value;
    }
    if (is_scalar($value) || $value === null) return $value;
    throw new InvalidArgumentException('Os parâmetros da assinatura devem conter apenas arrays e valores escalares.');
}

/** SHA-256 das strings exatas e flags fornecidos; não devolve nem registra fontes. */
function naxxOdFingerprint(array $sources, array $flags = []) {
    if (!naxxOdIsList($sources)) throw new InvalidArgumentException('As fontes da assinatura devem formar uma lista.');
    foreach ($sources as $source) {
        if (!is_string($source)) throw new InvalidArgumentException('As fontes da assinatura devem ser textos.');
    }
    $json = json_encode(['sources' => $sources, 'flags' => naxxOdCanonicalValue($flags)],
        JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRESERVE_ZERO_FRACTION);
    if ($json === false) throw new InvalidArgumentException('Não foi possível serializar os parâmetros da assinatura.');
    return hash('sha256', $json);
}

/** Interpreta valores usuais de formulários; valores não vazios desconhecidos são ativos. */
function naxxOdFlagEnabled($value) {
    if ($value === null || $value === false) return false;
    if (is_string($value)) {
        $value = trim($value);
        if (in_array(strtolower($value), ['', 'false', 'off', 'no'], true)) return false;
        if (is_numeric($value)) return (float) $value != 0;
        return true;
    }
    if (is_int($value) || is_float($value)) return $value != 0;
    if (is_array($value)) return count($value) > 0;
    return (bool) $value;
}

/** Classifica o resultado real de ffprobe, sem usar a extensão da URL. */
function naxxOdClassifyObservation($observation) {
    $result = ['format' => null, 'verified' => false, 'reason' => '', 'video_codecs' => [], 'audio_codecs' => []];
    if (is_string($observation)) {
        $json = trim($observation);
        $observation = json_decode($json, true);
        if (json_last_error() !== JSON_ERROR_NONE || substr($json, 0, 1) !== '{') {
            $result['reason'] = 'A análise da fonte não contém um JSON de objeto válido.';
            return $result;
        }
    }
    if (!is_array($observation)) {
        $result['reason'] = 'A análise da fonte está ausente ou incompleta.';
        return $result;
    }
    if (naxxOdFlagEnabled($observation['timeout'] ?? false) || naxxOdFlagEnabled($observation['timed_out'] ?? false)) {
        $result['reason'] = 'A análise da fonte excedeu o tempo de espera.';
        return $result;
    }
    if (!empty($observation['error']) || (array_key_exists('ok', $observation) && $observation['ok'] !== true)
        || (isset($observation['exit_code']) && $observation['exit_code'] !== 0)) {
        $result['reason'] = 'A análise da fonte terminou com erro.';
        return $result;
    }
    $name = $observation['format']['format_name'] ?? null;
    if (!is_string($name) || trim($name) === '') {
        $result['reason'] = 'O formato real da fonte não foi identificado.';
        return $result;
    }
    $families = [
        'mpegts' => ['mpegts'], 'hls' => ['hls', 'applehttp'],
        'mp4' => ['mov', 'mp4', 'm4a', '3gp', '3g2', 'mj2'],
        'matroska' => ['matroska', 'webm'], 'flv' => ['flv'], 'avi' => ['avi'],
        'mpeg' => ['mpeg'], 'ogg' => ['ogg'], 'rtsp' => ['rtsp'], 'rtp' => ['rtp'], 'sdp' => ['sdp']
    ];
    $found = [];
    foreach (explode(',', strtolower($name)) as $alias) {
        $alias = trim($alias);
        $family = null;
        foreach ($families as $candidate => $aliases) {
            if (in_array($alias, $aliases, true)) { $family = $candidate; break; }
        }
        if ($family === null) {
            $result['reason'] = 'A análise retornou um formato desconhecido para esta política.';
            return $result;
        }
        $found[$family] = true;
    }
    if (count($found) !== 1) {
        $result['reason'] = 'A análise retornou formatos incompatíveis entre si.';
        return $result;
    }
    $result['format'] = key($found);
    if (!isset($observation['streams']) || !is_array($observation['streams']) || !naxxOdIsList($observation['streams'])) {
        $result['reason'] = 'A análise não identificou os codecs de vídeo e áudio.';
        return $result;
    }
    foreach ($observation['streams'] as $stream) {
        if (!is_array($stream)) {
            $result['reason'] = 'A análise contém informações de mídia incompletas.';
            return $result;
        }
        $type = $stream['codec_type'] ?? null;
        if ($type !== 'video' && $type !== 'audio') continue;
        $codec = $stream['codec_name'] ?? null;
        if (!is_string($codec) || !preg_match('/^[a-z0-9_]+$/i', $codec) || in_array(strtolower($codec), ['unknown', 'none', 'n_a'], true)) {
            $result['reason'] = 'A análise contém um codec de vídeo ou áudio desconhecido.';
            return $result;
        }
        $key = $type === 'video' ? 'video_codecs' : 'audio_codecs';
        $result[$key][] = strtolower($codec);
    }
    if (!$result['video_codecs'] || !$result['audio_codecs']) {
        $result['reason'] = 'A análise precisa identificar ao menos um codec de vídeo e um de áudio.';
        return $result;
    }
    $result['video_codecs'] = array_values(array_unique($result['video_codecs']));
    $result['audio_codecs'] = array_values(array_unique($result['audio_codecs']));
    $result['verified'] = true;
    $result['reason'] = 'Formato e codecs de vídeo e áudio identificados pela análise.';
    return $result;
}

/** Capacidades: lista de modos ou mapa modes/video_codecs/audio_codecs por formato. */
function naxxOdDecide(array $sources, array $observations, array $flags = [], array $capabilities = [], array $preference = [2, 1, 0]) {
    $result = ['mode' => 0, 'reason' => '', 'format' => null, 'verified' => false];
    $normalized = naxxOdNormalizeSources($sources);
    if (!$normalized['valid']) { $result['reason'] = $normalized['reason']; return $result; }
    $incompatible = [
        'direct_source' => 'fonte direta', 'transcode' => 'transcodificação', 'transcode_profile_id' => 'perfil de transcodificação',
        'custom_ffmpeg' => 'comando FFmpeg personalizado', 'delay' => 'atraso configurado', 'delay_minutes' => 'atraso configurado'
    ];
    foreach ($incompatible as $key => $label) {
        if (naxxOdFlagEnabled($flags[$key] ?? null)) {
            $result['reason'] = 'Mantido o modo convencional: ' . $label . ' é incompatível com a seleção automática.';
            return $result;
        }
    }
    if (!naxxOdIsList($observations) || count($observations) !== count($normalized['sources'])) {
        $result['reason'] = 'Falta uma análise completa para cada fonte, incluindo as reservas.';
        return $result;
    }
    $formats = []; $videoCodecs = []; $audioCodecs = [];
    foreach ($observations as $index => $observation) {
        $classified = naxxOdClassifyObservation($observation);
        if (!$classified['verified']) {
            $result['reason'] = 'Fonte ' . ($index + 1) . ': ' . $classified['reason'];
            return $result;
        }
        $formats[$classified['format']] = true;
        $videoCodecs = array_merge($videoCodecs, $classified['video_codecs']);
        $audioCodecs = array_merge($audioCodecs, $classified['audio_codecs']);
    }
    if (count($formats) !== 1) {
        $result['reason'] = 'As fontes principal e reservas usam formatos diferentes; mantido o modo convencional.';
        return $result;
    }
    $result['format'] = key($formats);
    $capability = $capabilities[$result['format']] ?? null;
    $modes = $capability;
    if (is_array($capability) && !naxxOdIsList($capability)) {
        $modes = $capability['modes'] ?? null;
        foreach (['video_codecs' => $videoCodecs, 'audio_codecs' => $audioCodecs] as $key => $observed) {
            $whitelist = $capability[$key] ?? null;
            if (!is_array($whitelist) || !$whitelist || !naxxOdIsList($whitelist)) {
                $result['reason'] = 'A lista de codecs validados está incompleta; mantido o modo convencional.';
                return $result;
            }
            $allowed = [];
            foreach ($whitelist as $codec) {
                if (!is_string($codec) || !preg_match('/^[a-z0-9_]+$/i', $codec) || in_array(strtolower($codec), ['unknown', 'none', 'n_a'], true)) {
                    $result['reason'] = 'A lista de codecs validados é inválida; mantido o modo convencional.';
                    return $result;
                }
                $allowed[] = strtolower($codec);
            }
            if (array_diff($observed, $allowed)) {
                $result['reason'] = 'Há codecs de vídeo ou áudio sem validação em uma das fontes; mantido o modo convencional.';
                return $result;
            }
        }
    }
    if (!is_array($modes) || !$modes || !naxxOdIsList($modes)) {
        $result['reason'] = 'Não há modos validados para o formato identificado; mantido o modo convencional.';
        return $result;
    }
    foreach ([$modes, $preference] as $list) {
        if (!$list || !naxxOdIsList($list)) {
            $result['reason'] = 'A configuração de capacidades ou preferência é inválida; mantido o modo convencional.';
            return $result;
        }
        foreach ($list as $mode) {
            if (!is_int($mode) || !in_array($mode, [0, 1, 2], true)) {
                $result['reason'] = 'A configuração contém um modo não suportado; mantido o modo convencional.';
                return $result;
            }
        }
    }
    foreach ($preference as $mode) {
        if (!in_array($mode, $modes, true)) continue;
        $result['mode'] = $mode;
        $result['verified'] = true;
        $result['reason'] = $mode === 0
            ? 'Todas as fontes foram analisadas; o modo convencional foi selecionado conforme as capacidades validadas.'
            : 'Todas as fontes têm o mesmo formato e codecs identificados; selecionado o modo nativo ' . $mode . ' entre as capacidades validadas.';
        return $result;
    }
    $result['reason'] = 'Nenhum modo validado coincide com a preferência informada; mantido o modo convencional.';
    return $result;
}


// Perfil automático por canal. Embutido no endpoint administrativo pelo build.
ini_set('display_errors', '0');
ini_set('zlib.output_compression', '0');
set_time_limit(25);
$naxxOdResponded = false;
$naxxOdAuthPhase = true;

function naxxOdReply($status, $payload) {
    $GLOBALS['naxxOdResponded'] = true;
    while (ob_get_level()) ob_end_clean();
    if (session_status() === PHP_SESSION_ACTIVE) session_write_close();
    header_remove('Location'); header_remove('Content-Length');
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store'); header('X-Content-Type-Options: nosniff');
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
}

function naxxOdOrigin($value) {
    $parts = parse_url((string) $value);
    if (!$parts || empty($parts['host']) || !in_array(strtolower($parts['scheme'] ?? ''), array('http', 'https'), true)) return '';
    $scheme = strtolower($parts['scheme']);
    return $scheme . '://' . strtolower($parts['host']) . ':' . ($parts['port'] ?? ($scheme === 'https' ? 443 : 80));
}

function naxxOdRow($pdo, $id, $lock = false) {
    $query = $pdo->prepare('SELECT id, uuid, stream_source, llod, enable_transcode, transcode_profile_id, custom_ffmpeg, direct_source, delay_minutes FROM streams WHERE id = ? AND type = 1' . ($lock ? ' FOR UPDATE' : ''));
    $query->execute(array($id));
    $row = $query->fetch(PDO::FETCH_ASSOC);
    if (!$row) throw new RuntimeException('missing_stream');
    return $row;
}

function naxxOdServers($pdo, $id) {
    $query = $pdo->prepare('SELECT DISTINCT server_id FROM streams_servers WHERE stream_id = ? AND on_demand = 1 ORDER BY server_id');
    $query->execute(array($id));
    return array_map('intval', $query->fetchAll(PDO::FETCH_COLUMN));
}

function naxxOdFlags($row, $servers) {
    return array('transcode' => !empty($row['enable_transcode']) || (int) ($row['transcode_profile_id'] ?? 0) > 0,
        'custom_ffmpeg' => trim((string) ($row['custom_ffmpeg'] ?? '')),
        'direct_source' => !empty($row['direct_source']),
        'delay' => (int) ($row['delay_minutes'] ?? 0), 'on_demand_servers' => $servers);
}

function naxxOdSnapshot($pdo, $row) {
    $sources = naxxOdNormalizeSources($row['stream_source']);
    $servers = naxxOdServers($pdo, (int) $row['id']);
    $flags = naxxOdFlags($row, $servers);
    return array('hash' => $sources['valid'] ? naxxOdFingerprint($sources['sources'], $flags) : '',
        'flags' => $flags, 'servers' => $servers);
}

function naxxOdLoadProfile($pdo, $id) {
    try {
        $query = $pdo->prepare('SELECT * FROM naxx_ondemand_profiles WHERE stream_id = ?');
        $query->execute(array($id));
        return $query->fetch(PDO::FETCH_ASSOC) ?: null;
    } catch (PDOException $error) {
        if ((string) $error->getCode() === '42S02') return null;
        throw $error;
    }
}

function naxxOdPublicProfile($profile, $row, $snapshot) {
    $active = $profile && (string) $profile['stream_uuid'] === (string) ($row['uuid'] ?? '') &&
        $snapshot['hash'] !== '' && hash_equals((string) $profile['source_hash'], $snapshot['hash']) &&
        (int) $profile['effective_mode'] === (int) $row['llod'];
    return array('active' => (bool) $active, 'mode' => (int) $row['llod'],
        'previous_mode' => $active ? (int) $profile['previous_mode'] : (int) $row['llod'],
        'reason' => $active ? (string) $profile['reason'] : '',
        'format' => $active ? (string) $profile['format_name'] : '',
        'verified' => $active && !empty($profile['verified']));
}

function naxxOdEnsureTable($pdo) {
    $pdo->exec("CREATE TABLE IF NOT EXISTS naxx_ondemand_profiles (
        stream_id INT NOT NULL PRIMARY KEY, stream_uuid VARCHAR(64) NOT NULL DEFAULT '',
        source_hash CHAR(64) NOT NULL, effective_mode TINYINT UNSIGNED NOT NULL,
        previous_mode TINYINT UNSIGNED NOT NULL, reason VARCHAR(255) NOT NULL,
        format_name VARCHAR(32) NOT NULL DEFAULT '', verified TINYINT NOT NULL DEFAULT 0,
        updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
}

/** Carrega capacidades validadas (formato => modos/codecs) de um arquivo local; vazio é o padrão seguro. */
function naxxOdLoadCapabilities() {
    $candidates = array();
    $env = getenv('NAXX_OD_CAPABILITIES');
    if (is_string($env) && $env !== '') $candidates[] = $env;
    $candidates[] = dirname(__DIR__) . '/includes/naxx-ondemand-capabilities.json';
    $candidates[] = __DIR__ . '/naxx-ondemand-capabilities.json';
    foreach ($candidates as $path) {
        if (!is_string($path) || $path === '' || !is_file($path) || !is_readable($path)) continue;
        $raw = @file_get_contents($path, false, null, 0, 65537);
        if (!is_string($raw) || $raw === '' || strlen($raw) > 65536) continue;
        $data = json_decode($raw, true);
        // Precisa ser um mapa (formato => configuração), nunca uma lista ou escalar.
        if (!is_array($data) || !$data || array_keys($data) === range(0, count($data) - 1)) continue;
        return $data;
    }
    return array();
}

register_shutdown_function(function () {
    if (empty($GLOBALS['naxxOdResponded'])) naxxOdReply(!empty($GLOBALS['naxxOdAuthPhase']) ? 403 : 500,
        array('ok' => false, 'message' => !empty($GLOBALS['naxxOdAuthPhase'])
            ? 'Entre com uma conta autorizada a editar este canal.'
            : 'Não foi possível concluir a configuração automática.'));
});

$naxxOdMethod = $_SERVER['REQUEST_METHOD'] ?? '';
if (!in_array($naxxOdMethod, array('GET', 'POST'), true)) {
    header('Allow: GET, POST'); naxxOdReply(405, array('ok' => false, 'message' => 'Método inválido.'));
}
$naxxOdRequest = array();
if ($naxxOdMethod === 'POST') {
    $naxxOdScheme = !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' ? 'https' : 'http';
    $naxxOdExpectedOrigin = naxxOdOrigin($naxxOdScheme . '://' . ($_SERVER['HTTP_HOST'] ?? ''));
    if (!$naxxOdExpectedOrigin || naxxOdOrigin($_SERVER['HTTP_ORIGIN'] ?? ($_SERVER['HTTP_REFERER'] ?? '')) !== $naxxOdExpectedOrigin ||
        strtolower($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '') !== 'xmlhttprequest' || ($_SERVER['HTTP_SEC_FETCH_SITE'] ?? '') === 'cross-site') {
        naxxOdReply(403, array('ok' => false, 'message' => 'Abra o canal no painel e tente novamente.'));
    }
    $naxxOdBody = file_get_contents('php://input', false, null, 0, 65537);
    $naxxOdRequest = json_decode($naxxOdBody, true);
    if (strlen((string) $naxxOdBody) > 65536 || !is_array($naxxOdRequest)) naxxOdReply(400, array('ok' => false, 'message' => 'Solicitação inválida.'));
}
$naxxOdIdValue = $naxxOdMethod === 'POST' ? ($naxxOdRequest['id'] ?? null) : ($_GET['id'] ?? null);
if ((!is_string($naxxOdIdValue) && !is_int($naxxOdIdValue)) || !preg_match('/^[1-9][0-9]{0,9}$/', (string) $naxxOdIdValue)) {
    naxxOdReply(400, array('ok' => false, 'message' => 'Salve o canal antes de configurar o modo automático.'));
}
$naxxOdId = (int) $naxxOdIdValue;

// O formulário nativo continua sendo a autoridade sobre acesso ao canal.
$naxxOdSavedGet = $_GET; $naxxOdSavedPost = $_POST; $naxxOdSavedRequest = $_REQUEST;
$_GET = array('id' => $naxxOdId); $_POST = array(); $_REQUEST = $_GET;
$_SERVER['REQUEST_METHOD'] = 'GET';
$naxxOdNativeTail = ''; $naxxOdNativeSelect = false; $naxxOdNativeId = false;
ob_start(function ($chunk) use (&$naxxOdNativeTail, &$naxxOdNativeSelect, &$naxxOdNativeId, $naxxOdId) {
    $sample = $naxxOdNativeTail . $chunk;
    if (preg_match('/<select\b[^>]*\bid\s*=\s*[\x22\x27]llod[\x22\x27]/i', $sample)) $naxxOdNativeSelect = true;
    if (preg_match('/<input\b[^>]*\bname\s*=\s*[\x22\x27]edit[\x22\x27][^>]*>/i', $sample, $match) &&
        preg_match('/\bvalue\s*=\s*[\x22\x27]([0-9]+)[\x22\x27]/i', $match[0], $value) && (int) $value[1] === $naxxOdId) $naxxOdNativeId = true;
    $naxxOdNativeTail = substr($sample, -2048);
    return '';
}, 8192);
require __DIR__ . '/stream.php';
ob_end_flush();
$_GET = $naxxOdSavedGet; $_POST = $naxxOdSavedPost; $_REQUEST = $naxxOdSavedRequest;
$_SERVER['REQUEST_METHOD'] = $naxxOdMethod;
$naxxOdRedirect = false;
foreach (headers_list() as $naxxOdHeader) if (stripos($naxxOdHeader, 'Location:') === 0) $naxxOdRedirect = true;
if (!$naxxOdNativeSelect || !$naxxOdNativeId || $naxxOdRedirect || http_response_code() >= 300) {
    naxxOdReply(403, array('ok' => false, 'message' => 'Entre com uma conta autorizada a editar este canal.'));
}
$naxxOdAuthPhase = false;
if (session_status() !== PHP_SESSION_ACTIVE && session_id() !== '') @session_start();
if (session_status() !== PHP_SESSION_ACTIVE) naxxOdReply(503, array('ok' => false, 'message' => 'Recarregue a página para validar sua sessão.'));
if (!isset($_SESSION['naxx_od_csrf']) || !is_string($_SESSION['naxx_od_csrf']) || strlen($_SESSION['naxx_od_csrf']) !== 64) $_SESSION['naxx_od_csrf'] = bin2hex(random_bytes(32));
$naxxOdCsrf = $_SESSION['naxx_od_csrf'];
if ($naxxOdMethod === 'POST' && (!is_string($naxxOdRequest['csrf'] ?? null) || !hash_equals($naxxOdCsrf, $naxxOdRequest['csrf']))) {
    naxxOdReply(403, array('ok' => false, 'message' => 'A sessão expirou. Recarregue o canal.'));
}
$naxxOdDatabase = null;
foreach (get_defined_vars() as $naxxOdVariable) {
    if (is_object($naxxOdVariable) && get_class($naxxOdVariable) === 'Database') { $naxxOdDatabase = $naxxOdVariable; break; }
}
if (!$naxxOdDatabase || !isset($naxxOdDatabase->dbh) || !($naxxOdDatabase->dbh instanceof PDO)) {
    naxxOdReply(503, array('ok' => false, 'message' => 'Não foi possível consultar o canal.'));
}
$naxxOdPdo = $naxxOdDatabase->dbh;
$naxxOdPdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
// Somente motores aprovados pelos ensaios desta versão. Não há valor nativo 3.
$naxxOdCapabilities = naxxOdLoadCapabilities(); // NAXX_OD_VALIDATED_CAPABILITIES
$naxxOdAction = $naxxOdMethod === 'GET' ? 'status' : ($naxxOdRequest['action'] ?? '');

try {
    $naxxOdRow = naxxOdRow($naxxOdPdo, $naxxOdId);
    if (!in_array((int) $naxxOdRow['llod'], array(0, 1, 2), true)) throw new RuntimeException('unsupported_mode');
    $naxxOdSnapshot = naxxOdSnapshot($naxxOdPdo, $naxxOdRow);
    $naxxOdStored = naxxOdLoadProfile($naxxOdPdo, $naxxOdId);
    $naxxOdProfile = naxxOdPublicProfile($naxxOdStored, $naxxOdRow, $naxxOdSnapshot);
    if ($naxxOdAction === 'status') {
        naxxOdReply(200, array('ok' => true, 'feature' => 'ondemand', 'csrf' => $naxxOdCsrf,
            'capabilities' => $naxxOdCapabilities, 'native' => array('mode' => (int) $naxxOdRow['llod'],
                'on_demand_servers' => $naxxOdSnapshot['servers']), 'profile' => $naxxOdProfile));
    }
    if ($naxxOdAction === 'plan') {
        $naxxOdDraft = $naxxOdRequest['draft'] ?? null;
        if (!is_array($naxxOdDraft) || !is_array($naxxOdDraft['flags'] ?? null) || !is_array($naxxOdDraft['on_demand_servers'] ?? null)) {
            naxxOdReply(400, array('ok' => false, 'message' => 'As opções do canal estão incompletas.'));
        }
        $naxxOdSources = naxxOdNormalizeSources($naxxOdDraft['sources'] ?? null);
        if (!$naxxOdSources['valid'] || count($naxxOdSources['sources']) > 32) naxxOdReply(400, array('ok' => false, 'message' => 'Revise as fontes do canal.'));
        $naxxOdServers = array();
        foreach ($naxxOdDraft['on_demand_servers'] as $naxxOdServer) {
            if ((!is_int($naxxOdServer) && !is_string($naxxOdServer)) || !preg_match('/^[1-9][0-9]{0,9}$/', (string) $naxxOdServer)) {
                naxxOdReply(400, array('ok' => false, 'message' => 'Revise os servidores sob demanda.'));
            }
            $naxxOdServers[] = (int) $naxxOdServer;
        }
        $naxxOdServers = array_values(array_unique($naxxOdServers)); sort($naxxOdServers, SORT_NUMERIC);
        if (!$naxxOdServers) naxxOdReply(400, array('ok' => false, 'message' => 'Escolha pelo menos um servidor sob demanda.'));
        $naxxOdFlags = $naxxOdDraft['flags'];
        if (!is_bool($naxxOdFlags['transcode'] ?? null) || !is_bool($naxxOdFlags['direct_source'] ?? null) ||
            !is_string($naxxOdFlags['custom_ffmpeg'] ?? null) || strlen($naxxOdFlags['custom_ffmpeg']) > 16384 ||
            !is_int($naxxOdFlags['delay'] ?? null) || $naxxOdFlags['delay'] < 0 || $naxxOdFlags['delay'] > 1440) {
            naxxOdReply(400, array('ok' => false, 'message' => 'As opções de processamento estão inválidas.'));
        }
        $naxxOdFlags = array('transcode' => $naxxOdFlags['transcode'], 'custom_ffmpeg' => trim($naxxOdFlags['custom_ffmpeg']),
            'direct_source' => $naxxOdFlags['direct_source'], 'delay' => $naxxOdFlags['delay'], 'on_demand_servers' => $naxxOdServers);
        if ($naxxOdFlags['direct_source']) naxxOdReply(400, array('ok' => false, 'message' => 'O modo automático requer retransmissão pelo servidor.'));
        $naxxOdObservations = $naxxOdRequest['observations'] ?? array();
        if (!is_array($naxxOdObservations) || count($naxxOdObservations) > 3) naxxOdReply(400, array('ok' => false, 'message' => 'A análise das fontes está inválida.'));
        $naxxOdDecision = naxxOdDecide($naxxOdSources['sources'], $naxxOdObservations, $naxxOdFlags, $naxxOdCapabilities);
        $naxxOdNonce = bin2hex(random_bytes(32));
        if (!isset($_SESSION['naxx_od_plans']) || !is_array($_SESSION['naxx_od_plans'])) $_SESSION['naxx_od_plans'] = array();
        foreach ($_SESSION['naxx_od_plans'] as $naxxOdKey => $naxxOdOld) if (!is_array($naxxOdOld) || ($naxxOdOld['created'] ?? 0) < time() - 300) unset($_SESSION['naxx_od_plans'][$naxxOdKey]);
        if (count($_SESSION['naxx_od_plans']) >= 8) {
            $naxxOdPlanKeys = array_keys($_SESSION['naxx_od_plans']);
            unset($_SESSION['naxx_od_plans'][$naxxOdPlanKeys[0]]);
        }
        $_SESSION['naxx_od_plans'][(string) $naxxOdId] = array('nonce' => $naxxOdNonce, 'created' => time(),
            'uuid' => (string) ($naxxOdRow['uuid'] ?? ''), 'hash' => naxxOdFingerprint($naxxOdSources['sources'], $naxxOdFlags),
            'mode' => (int) $naxxOdDecision['mode'], 'previous_mode' => $naxxOdProfile['previous_mode'],
            'reason' => $naxxOdDecision['reason'], 'format' => $naxxOdDecision['format'] ?? '', 'verified' => $naxxOdDecision['verified']);
        naxxOdReply(200, array('ok' => true, 'csrf' => $naxxOdCsrf, 'plan' => array('nonce' => $naxxOdNonce,
            'mode' => (int) $naxxOdDecision['mode'], 'reason' => $naxxOdDecision['reason'],
            'format' => $naxxOdDecision['format'], 'verified' => $naxxOdDecision['verified'])));
    }
    if ($naxxOdAction === 'commit') {
        $naxxOdPlan = $_SESSION['naxx_od_plans'][(string) $naxxOdId] ?? null;
        if (!is_array($naxxOdPlan) || ($naxxOdPlan['created'] ?? 0) < time() - 300 ||
            !is_string($naxxOdRequest['nonce'] ?? null) || !hash_equals($naxxOdPlan['nonce'], $naxxOdRequest['nonce'])) {
            naxxOdReply(409, array('ok' => false, 'message' => 'A análise expirou ou foi substituída. Analise o canal novamente.'));
        }
        naxxOdEnsureTable($naxxOdPdo);
        $naxxOdPdo->beginTransaction();
        $naxxOdRow = naxxOdRow($naxxOdPdo, $naxxOdId, true);
        $naxxOdSnapshot = naxxOdSnapshot($naxxOdPdo, $naxxOdRow);
        if ((string) ($naxxOdRow['uuid'] ?? '') !== $naxxOdPlan['uuid'] || !$naxxOdSnapshot['servers'] ||
            !hash_equals($naxxOdPlan['hash'], $naxxOdSnapshot['hash']) || (int) $naxxOdRow['llod'] !== $naxxOdPlan['mode']) {
            $naxxOdPdo->rollBack();
            naxxOdReply(409, array('ok' => false, 'message' => 'O canal salvo difere da análise. Confira as fontes e analise novamente.'));
        }
        $naxxOdWrite = $naxxOdPdo->prepare('INSERT INTO naxx_ondemand_profiles (stream_id, stream_uuid, source_hash, effective_mode, previous_mode, reason, format_name, verified) VALUES (?, ?, ?, ?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE stream_uuid=VALUES(stream_uuid), source_hash=VALUES(source_hash), effective_mode=VALUES(effective_mode), previous_mode=VALUES(previous_mode), reason=VALUES(reason), format_name=VALUES(format_name), verified=VALUES(verified)');
        $naxxOdWrite->execute(array($naxxOdId, $naxxOdPlan['uuid'], $naxxOdPlan['hash'], $naxxOdPlan['mode'], $naxxOdPlan['previous_mode'],
            $naxxOdPlan['reason'], $naxxOdPlan['format'], (int) $naxxOdPlan['verified']));
        $naxxOdPdo->commit();
        unset($_SESSION['naxx_od_plans'][(string) $naxxOdId]);
        $naxxOdProfile = naxxOdPublicProfile(naxxOdLoadProfile($naxxOdPdo, $naxxOdId), $naxxOdRow, $naxxOdSnapshot);
        naxxOdReply(200, array('ok' => true, 'csrf' => $naxxOdCsrf, 'profile' => $naxxOdProfile));
    }
    if ($naxxOdAction === 'deactivate') {
        if ($naxxOdStored) {
            $naxxOdRemove = $naxxOdPdo->prepare('DELETE FROM naxx_ondemand_profiles WHERE stream_id = ? AND stream_uuid = ?');
            $naxxOdRemove->execute(array($naxxOdId, (string) ($naxxOdRow['uuid'] ?? '')));
        }
        unset($_SESSION['naxx_od_plans'][(string) $naxxOdId]);
        naxxOdReply(200, array('ok' => true, 'csrf' => $naxxOdCsrf));
    }
    naxxOdReply(400, array('ok' => false, 'message' => 'Ação automática inválida.'));
} catch (Throwable $naxxOdError) {
    if ($naxxOdPdo->inTransaction()) $naxxOdPdo->rollBack();
    naxxOdReply(503, array('ok' => false, 'message' => 'Não foi possível confirmar o perfil automático. O modo do canal permanece sob controle do painel.'));
}

}

if (($_GET['feature'] ?? '') === 'cache') {

// Diagnóstico somente de leitura. Executado pelo endpoint administrativo já instalado.
ini_set('display_errors','0');set_time_limit(12);
$naxxCacheDone=false;
function naxxCacheReply($code,$value){
 $GLOBALS['naxxCacheDone']=true;while(ob_get_level())ob_end_clean();
 if(session_status()===PHP_SESSION_ACTIVE)session_write_close();
 header_remove('Location');header_remove('Content-Length');http_response_code($code);
 header('Content-Type: application/json; charset=utf-8');header('Cache-Control: no-store');header('X-Content-Type-Options: nosniff');
 echo json_encode($value,JSON_UNESCAPED_UNICODE|JSON_INVALID_UTF8_SUBSTITUTE);exit;
}
register_shutdown_function(function(){if(empty($GLOBALS['naxxCacheDone']))naxxCacheReply(403,['ok'=>false,'message'=>'Entre com uma conta autorizada a acessar as configurações de cache.']);});
if(($_SERVER['REQUEST_METHOD']??'GET')!=='GET'){header('Allow: GET');naxxCacheReply(405,['ok'=>false,'message'=>'O diagnóstico aceita somente consultas.']);}
$_GET=$_POST=$_REQUEST=[];
$naxxCacheHtml='';
ob_start(function($chunk)use(&$naxxCacheHtml){if(strlen($naxxCacheHtml)<2*1024*1024)$naxxCacheHtml.=$chunk;return '';},8192);
require __DIR__.'/cache.php';ob_end_flush();
$redirect=false;foreach(headers_list()as$line)if(stripos($line,'Location:')===0)$redirect=true;
if($redirect||http_response_code()>=300||!preg_match('/\bid\s*=\s*[\x22\x27](?:cache_thread_count|enable_cache|disable_cache|enable_handler|disable_handler)[\x22\x27]/',$naxxCacheHtml))naxxCacheReply(403,['ok'=>false,'message'=>'Entre com uma conta autorizada a acessar as configurações de cache.']);
if(session_status()===PHP_SESSION_ACTIVE)session_write_close();
$document=new DOMDocument();$previous=libxml_use_internal_errors(true);$document->loadHTML($naxxCacheHtml,LIBXML_NONET|LIBXML_NOERROR|LIBXML_NOWARNING);libxml_clear_errors();libxml_use_internal_errors($previous);
$cache=['enabled'=>(bool)$document->getElementById('disable_cache'),'handler_enabled'=>(bool)$document->getElementById('disable_handler'),'last_run'=>null,'counts'=>[]];
if(preg_match('/Your last cron execution was at\s*(?:<strong>)?([0-9-]+\s+[0-9:]+)/',$naxxCacheHtml,$date))$cache['last_run']=$date[1];
$table=$document->getElementById('datatable-cache');if($table)foreach($table->getElementsByTagName('button')as$button)$cache['counts'][]=trim($button->textContent);
$nativeRedis=$document->getElementById('datatable-redis');$cache['native_redis_warning']=$nativeRedis?(bool)preg_match('/OFFLINE|INVALID PASSWORD/i',$nativeRedis->textContent):false;
$redis=['status'=>'unavailable','message'=>'A extensão Redis não está disponível neste servidor.'];$client=null;
if(class_exists('Redis')){
 $connected=false;
 try{
  $config=@file_get_contents(dirname(__DIR__).'/bin/redis/redis.conf',false,null,0,1024*1024);
  if($config===false)throw new RuntimeException('configuration');
  $port=6379;if(preg_match('/^\s*port\s+(\d+)\s*$/m',$config,$match))$port=(int)$match[1];
  if($port<1||$port>65535)throw new RuntimeException('configuration');
  $password='';if(preg_match('/^\s*requirepass\s+(.+?)\s*$/m',$config,$match)){
   $value=trim($match[1]);
   if($value[0]==='"'&&substr($value,-1)==='"')$password=stripcslashes(substr($value,1,-1));
   elseif($value[0]==="'"&&substr($value,-1)==="'")$password=substr($value,1,-1);
   else{$parts=preg_split('/\s+/', $value);$password=$parts[0];}
  }
  $client=new Redis();$start=microtime(true);$connected=$client->connect('127.0.0.1',$port,0.8);
  if(!$connected)throw new RuntimeException('connection');$client->setOption(Redis::OPT_READ_TIMEOUT,1.0);
  if($password!==''&&!$client->auth($password))throw new RuntimeException('authentication');
  $client->ping();$latency=round((microtime(true)-$start)*1000,2);
  $memory=$client->info('memory');$stats=$client->info('stats');$clients=$client->info('clients');$server=$client->info('server');$keyspace=$client->info('keyspace');
  $keys=0;foreach($keyspace as$db=>$value){if(!preg_match('/^db\d+$/',$db))continue;if(is_array($value))$keys+=(int)($value['keys']??0);elseif(preg_match('/(?:^|,)keys=(\d+)/',$value,$match))$keys+=(int)$match[1];}
  $hits=(int)($stats['keyspace_hits']??0);$misses=(int)($stats['keyspace_misses']??0);
  $redis=['status'=>'online','message'=>'Redis respondeu ao diagnóstico local.','latency_ms'=>$latency,'used_memory'=>(int)($memory['used_memory']??0),'peak_memory'=>(int)($memory['used_memory_peak']??0),'max_memory'=>(int)($memory['maxmemory']??0),'clients'=>(int)($clients['connected_clients']??0),'keys'=>$keys,'hits'=>$hits,'misses'=>$misses,'hit_rate'=>$hits+$misses?round($hits/($hits+$misses)*100,1):null,'evictions'=>(int)($stats['evicted_keys']??0),'operations_per_second'=>(int)($stats['instantaneous_ops_per_sec']??0),'uptime_seconds'=>(int)($server['uptime_in_seconds']??0)];
 }catch(Throwable$error){$redis=['status'=>$connected?'authentication_error':'offline','message'=>$connected?'Não foi possível autenticar ou consultar o Redis com a configuração local.':'Não foi possível consultar o Redis local. Confira o serviço e sua configuração.'];}
 finally{if($client){try{$client->close();}catch(Throwable$error){}}}
}
naxxCacheReply(200,['ok'=>true,'checked_at'=>date('c'),'cache'=>$cache,'redis'=>$redis]);

}

// Interface autenticada do serviço local de atualização Xui Naxx.
ini_set('display_errors', '0');
ini_set('zlib.output_compression', '0');
set_time_limit(15);
$naxxUpdateResponded = false;

function naxxUpdateReply($status, $payload) {
    $GLOBALS['naxxUpdateResponded'] = true;
    while (ob_get_level()) ob_end_clean();
    if (session_status() === PHP_SESSION_ACTIVE) session_write_close();
    header_remove('Location');
    header_remove('Content-Length');
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    header('X-Content-Type-Options: nosniff');
    $json = json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE);
    echo $json !== false ? $json : '{"ok":false,"message":"Não foi possível preparar a resposta da atualização."}';
    exit;
}

function naxxUpdateOrigin($value) {
    $parts = parse_url((string) $value);
    if (!$parts || !isset($parts['scheme'], $parts['host'])) return '';
    $scheme = strtolower($parts['scheme']);
    if (!in_array($scheme, array('http', 'https'), true)) return '';
    return $scheme . '://' . strtolower($parts['host']) . ':' . ($parts['port'] ?? ($scheme === 'https' ? 443 : 80));
}

register_shutdown_function(function () {
    if (empty($GLOBALS['naxxUpdateResponded'])) {
        naxxUpdateReply(403, array('ok' => false, 'message' => 'Entre com uma conta autorizada para alterar as configurações do painel.'));
    }
});

$method = $_SERVER['REQUEST_METHOD'] ?? '';
if (!in_array($method, array('GET', 'POST'), true)) {
    header('Allow: GET, POST');
    naxxUpdateReply(405, array('ok' => false, 'message' => 'Método de atualização não permitido.'));
}
$request = array();
if ($method === 'POST') {
    $scheme = !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' ? 'https' : 'http';
    $expected = naxxUpdateOrigin($scheme . '://' . ($_SERVER['HTTP_HOST'] ?? ''));
    $origin = naxxUpdateOrigin($_SERVER['HTTP_ORIGIN'] ?? ($_SERVER['HTTP_REFERER'] ?? ''));
    if (!$expected || $origin !== $expected || strtolower($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '') !== 'xmlhttprequest' || ($_SERVER['HTTP_SEC_FETCH_SITE'] ?? '') === 'cross-site') {
        naxxUpdateReply(403, array('ok' => false, 'message' => 'Abra a aba Atualização do painel e tente novamente.'));
    }
    $input = file_get_contents('php://input', false, null, 0, 4097);
    $request = json_decode($input, true);
    if (!is_array($request) || strlen((string) $input) > 4096) {
        naxxUpdateReply(400, array('ok' => false, 'message' => 'A solicitação de atualização está inválida.'));
    }
}

// Carrega a mesma sessão e a mesma permissão da configuração nativa.
// A saída é descartada em blocos para evitar manter a página inteira na memória.
$savedGet = $_GET;
$savedPost = $_POST;
$savedRequest = $_REQUEST;
$_GET = $_POST = $_REQUEST = array();
$_SERVER['REQUEST_METHOD'] = 'GET';
$nativeAllowed = false;
$nativeTail = '';
ob_start(function ($chunk) use (&$nativeAllowed, &$nativeTail) {
    $sample = $nativeTail . $chunk;
    if (preg_match('/<input\b[^>]*\bid\s*=\s*[\x22\x27]server_name[\x22\x27][^>]*\bname\s*=\s*[\x22\x27]server_name[\x22\x27]/i', $sample)) $nativeAllowed = true;
    $nativeTail = substr($sample, -256);
    return '';
}, 8192);
require __DIR__ . '/settings.php';
ob_end_flush();
$_GET = $savedGet;
$_POST = $savedPost;
$_REQUEST = $savedRequest;
$_SERVER['REQUEST_METHOD'] = $method;
$redirect = false;
foreach (headers_list() as $header) if (stripos($header, 'Location:') === 0) $redirect = true;
if (!$nativeAllowed || $redirect || http_response_code() >= 300) {
    naxxUpdateReply(403, array('ok' => false, 'message' => 'Entre com uma conta autorizada para alterar as configurações do painel.'));
}
// O carregamento nativo libera a sessão ao terminar a página. Reabre somente
// a sessão já autenticada para guardar/verificar o token, fechando-a em seguida.
if (session_status() !== PHP_SESSION_ACTIVE && session_id() !== '') @session_start();
if (session_status() !== PHP_SESSION_ACTIVE) {
    naxxUpdateReply(503, array('ok' => false, 'message' => 'Não foi possível validar a sessão de atualização. Entre novamente no painel.'));
}
if (!isset($_SESSION['naxx_update_csrf']) || !is_string($_SESSION['naxx_update_csrf']) || strlen($_SESSION['naxx_update_csrf']) !== 64) {
    $_SESSION['naxx_update_csrf'] = bin2hex(random_bytes(32));
}
$csrf = $_SESSION['naxx_update_csrf'];
$action = $method === 'GET' ? 'status' : ($request['action'] ?? '');
if ($method === 'POST' && (!is_string($request['csrf'] ?? null) || !hash_equals($csrf, $request['csrf']))) {
    naxxUpdateReply(403, array('ok' => false, 'message' => 'A sessão de atualização expirou. Recarregue esta aba.'));
}
if (!in_array($action, array('status', 'check', 'install', 'automatic', 'rollback'), true) || ($method === 'POST' && $action === 'status')) {
    naxxUpdateReply(400, array('ok' => false, 'message' => 'Ação de atualização inválida.'));
}
$command = array('action' => $action);
if ($action === 'automatic') {
    if (!array_key_exists('enabled', $request) || !is_bool($request['enabled'])) {
        naxxUpdateReply(400, array('ok' => false, 'message' => 'Informe se as atualizações automáticas devem ser ativadas.'));
    }
    $command['enabled'] = $request['enabled'];
}
session_write_close();

// O PHP nunca chama shell/sudo e não recebe caminhos ou URLs do navegador.
$connection = @stream_socket_client('unix:///run/naxx-update/control.sock', $errorCode, $errorMessage, 2, STREAM_CLIENT_CONNECT);
if (!$connection) {
    naxxUpdateReply(503, array('ok' => false, 'csrf' => $csrf, 'message' => 'O serviço local de atualização ainda não está disponível.'));
}
stream_set_timeout($connection, 3);
$message = json_encode($command) . "\n";
if (fwrite($connection, $message) !== strlen($message)) {
    fclose($connection);
    naxxUpdateReply(503, array('ok' => false, 'csrf' => $csrf, 'message' => 'Não foi possível enviar a solicitação ao serviço local.'));
}
$raw = fgets($connection, 65537);
$metadata = stream_get_meta_data($connection);
fclose($connection);
$response = is_string($raw) && strlen($raw) <= 65536 ? json_decode($raw, true) : null;
if ($metadata['timed_out'] || !is_array($response) || !isset($response['ok'])) {
    naxxUpdateReply(503, array('ok' => false, 'csrf' => $csrf, 'message' => 'O serviço local não respondeu. Verifique o estado da atualização antes de tentar novamente.'));
}
$response['csrf'] = $csrf;
if (empty($response['ok'])) {
    $status = isset($response['status']) && in_array((int) $response['status'], array(400, 403, 409, 500, 502, 503), true) ? (int) $response['status'] : 500;
    unset($response['status']);
    naxxUpdateReply($status, $response);
}
naxxUpdateReply(in_array($action, array('check', 'install', 'rollback'), true) ? 202 : 200, $response);
